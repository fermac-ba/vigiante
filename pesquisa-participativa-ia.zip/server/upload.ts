/**
 * Endpoint de upload multipart para arquivos de áudio e imagem.
 * Substitui o upload base64 via tRPC, que era frágil em dispositivos móveis
 * por exceder limites de payload JSON e falhar silenciosamente.
 */
import { Router } from "express";
import multer from "multer";
import { storagePut } from "./storage";
import { sdk } from "./_core/sdk";

const router = Router();

// Armazena o arquivo em memória (limite de 16 MB conforme Whisper API)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 16 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = [
      "audio/webm", "audio/ogg", "audio/mp4", "audio/mpeg",
      "audio/wav", "audio/x-wav", "audio/wave",
      "image/jpeg", "image/png", "image/webp",
    ];
    if (allowed.includes(file.mimetype) || file.mimetype.startsWith("audio/") || file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error(`Tipo de arquivo não suportado: ${file.mimetype}`));
    }
  },
});

router.post("/api/upload", async (req, res, next) => {
  try {
    await sdk.authenticateRequest(req as any);
    next();
  } catch {
    res.status(401).json({ error: "Nao autenticado." });
  }
}, upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: "Nenhum arquivo enviado." });
      return;
    }
    const { originalname, mimetype, buffer } = req.file;
    const ext = originalname.split(".").pop() ?? "bin";
    const folder = mimetype.startsWith("audio/") ? "audio" : "images";
    const key = `field-files/${folder}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { url } = await storagePut(key, buffer, mimetype);
    res.json({ url, key, size: buffer.length, mimeType: mimetype });
  } catch (err: any) {
    console.error("[upload] Erro:", err?.message ?? err);
    res.status(500).json({ error: err?.message ?? "Erro interno no upload." });
  }
});

export function registerUploadRoute(app: import("express").Application) {
  app.use(router);
}
