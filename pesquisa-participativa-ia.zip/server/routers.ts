import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { notifyOwner } from "./_core/notification";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { transcribeAudio } from "./_core/voiceTranscription";
import { storagePut, storageGetSignedUrl } from "./storage";
import { generatePdfFromHtml, buildSessionReportHtml, buildProjectReportHtml } from "./pdf";
import * as db from "./db";

// ─── Middleware de perfis ─────────────────────────────────────────────────────
const facilitadorProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!["facilitador", "gestor", "admin"].includes(ctx.user.role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito a facilitadores e gestores." });
  }
  return next({ ctx });
});

const gestorProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!["gestor", "admin"].includes(ctx.user.role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito a gestores." });
  }
  return next({ ctx });
});

// ─── Router principal ─────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Usuários ───────────────────────────────────────────────────────────────
  users: router({
    list: gestorProcedure.query(async () => {
      return db.getAllUsers();
    }),
    updateRole: gestorProcedure.input(z.object({
      userId: z.number(),
      role: z.enum(["pesquisador_popular", "facilitador", "gestor"]),
    })).mutation(async ({ input }) => {
      await db.updateUserRole(input.userId, input.role);
      return { success: true };
    }),
  }),

  // ─── Projetos ───────────────────────────────────────────────────────────────
  projects: router({
    list: protectedProcedure.query(async () => {
      return db.getProjects();
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getProjectById(input.id);
    }),
    create: facilitadorProcedure.input(z.object({
      title: z.string().min(1),
      description: z.string().optional(),
      territory: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const result = await db.createProject({ ...input, createdBy: ctx.user.id, status: "ativo" });
      return result;
    }),
    update: facilitadorProcedure.input(z.object({
      id: z.number(),
      title: z.string().optional(),
      description: z.string().optional(),
      territory: z.string().optional(),
      status: z.enum(["ativo", "pausado", "concluido"]).optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateProject(id, data);
      return { success: true };
    }),
    getStats: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      const [entries, cycles, indicators] = await Promise.all([
        db.countFieldEntriesByProject(input.projectId),
        db.getCyclesByProject(input.projectId),
        db.getIndicatorsByProject(input.projectId),
      ]);
      return { totalEntries: entries, totalCycles: cycles.length, totalIndicators: indicators.length };
    }),
    generateReport: facilitadorProcedure.input(z.object({ projectId: z.number() })).mutation(async ({ input }) => {
      const [project, entries, cycles, indicators, analyses, epidData] = await Promise.all([
        db.getProjectById(input.projectId),
        db.getFieldEntriesByProject(input.projectId),
        db.getCyclesByProject(input.projectId),
        db.getIndicatorsByProject(input.projectId),
        db.getAnalysesByProject(input.projectId),
        db.getEpidemiologicalDataByProject(input.projectId),
      ]);
      const allCodes: string[] = [];
      analyses.forEach((a: {suggestedCodes: unknown}) => {
        if (Array.isArray(a.suggestedCodes)) {
          (a.suggestedCodes as Array<{codigo?: string}>).forEach(c => { if (c.codigo) allCodes.push(c.codigo); });
        }
      });
      const codeFreq: Record<string, number> = {};
      allCodes.forEach(c => { codeFreq[c] = (codeFreq[c] ?? 0) + 1; });
      const topCodes = Object.entries(codeFreq).sort((a, b) => b[1] - a[1]).slice(0, 10);
      const narratives = entries.filter((e: {narrativeText: string | null}) => e.narrativeText).map((e: {narrativeText: string | null; locationName: string | null; createdAt: Date}) => ({ text: e.narrativeText, location: e.locationName, date: e.createdAt }));
      return {
        project,
        summary: {
          totalEntries: entries.length,
          totalCycles: cycles.length,
          totalIndicators: indicators.length,
          totalAnalyses: analyses.length,
          totalEpidData: epidData.length,
          topThematicCodes: topCodes,
        },
        cycles,
        indicators,
        narratives: narratives.slice(0, 20),
        generatedAt: new Date(),
      };
    }),
  }),

  // ─── Ciclos de pesquisa ──────────────────────────────────────────────────────
  cycles: router({
    listByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getCyclesByProject(input.projectId);
    }),
    create: facilitadorProcedure.input(z.object({
      projectId: z.number(),
      title: z.string().min(1),
      description: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const result = await db.createResearchCycle({
        projectId: input.projectId,
        title: input.title,
        description: input.description,
        startDate: input.startDate ? new Date(input.startDate) : undefined,
        endDate: input.endDate ? new Date(input.endDate) : undefined,
        createdBy: ctx.user.id,
        status: "planejamento",
      });
      return result;
    }),
    updateStatus: facilitadorProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["planejamento", "coleta", "analise", "validacao", "concluido"]),
    })).mutation(async ({ input, ctx }) => {
      await db.updateCycleStatus(input.id, input.status);
      if (input.status === "concluido") {
        const allUsers = await db.getAllUsers();
        const facilitadoresGestores = allUsers.filter(u => ["facilitador", "gestor", "admin"].includes(u.role));
        for (const u of facilitadoresGestores) {
          await db.createNotification({
            userId: u.id,
            title: "Ciclo de pesquisa concluido",
            message: `Um ciclo de pesquisa foi marcado como concluido.`,
            notificationType: "ciclo_concluido",
          });
        }
      }
      return { success: true };
    }),
  }),

  // ─── Coleta de dados em campo ────────────────────────────────────────────────
  fieldEntries: router({
    listByCycle: protectedProcedure.input(z.object({ cycleId: z.number() })).query(async ({ input }) => {
      return db.getFieldEntriesByCycle(input.cycleId);
    }),
    listByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getFieldEntriesByProject(input.projectId);
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getFieldEntryById(input.id);
    }),
    create: protectedProcedure.input(z.object({
      cycleId: z.number(),
      projectId: z.number(),
      entryType: z.enum(["narrativa", "audio", "foto", "misto"]),
      narrativeText: z.string().optional(),
      audioUrl: z.string().optional(),
      audioKey: z.string().optional(),
      photoUrl: z.string().optional(),
      photoKey: z.string().optional(),
      latitude: z.number().optional(),
      longitude: z.number().optional(),
      geoPolygon: z.any().optional(),
      locationName: z.string().optional(),
      offlineId: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const result = await db.createFieldEntry({ ...input, collectedBy: ctx.user.id, syncStatus: "sincronizado" });
      // Notificar facilitadores e gestores
      const allUsers = await db.getAllUsers();
      const facilitadoresGestores = allUsers.filter(u => ["facilitador", "gestor", "admin"].includes(u.role));
      for (const u of facilitadoresGestores) {
        await db.createNotification({
          userId: u.id,
          projectId: input.projectId,
          title: "Nova coleta registrada",
          message: `${ctx.user.name ?? "Um pesquisador"} registrou uma nova coleta de dados.`,
          notificationType: "nova_coleta",
        });
      }
      return result;
    }),
    uploadFile: protectedProcedure.input(z.object({
      fileName: z.string(),
      fileType: z.string(),
      fileData: z.string(), // base64
    })).mutation(async ({ input }) => {
      const buffer = Buffer.from(input.fileData, "base64");
      const key = `field-files/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(key, buffer, input.fileType);
      return { url, key };
    }),
  }),

  // ─── Transcrição de áudio ────────────────────────────────────────────────────
  transcriptions: router({
    getByEntry: protectedProcedure.input(z.object({ fieldEntryId: z.number() })).query(async ({ input }) => {
      return db.getTranscriptionByEntry(input.fieldEntryId);
    }),
    transcribe: protectedProcedure.input(z.object({
      fieldEntryId: z.number(),
      audioUrl: z.string(),
    })).mutation(async ({ input }) => {
      // Criar registro pendente
      await db.createTranscription({ fieldEntryId: input.fieldEntryId, status: "processando", language: "pt" });
      const transcription = await db.getTranscriptionByEntry(input.fieldEntryId);
      if (!transcription) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      try {
        // Converter URL relativa /manus-storage/{key} para URL absoluta assinada do S3
        let resolvedAudioUrl = input.audioUrl;
        if (input.audioUrl.startsWith("/manus-storage/")) {
          const key = input.audioUrl.replace("/manus-storage/", "");
          resolvedAudioUrl = await storageGetSignedUrl(key);
        }
        const result = await transcribeAudio({ audioUrl: resolvedAudioUrl, language: "pt", prompt: "Transcreva o audio em portugues brasileiro, mantendo expressoes regionais e sotaques." });
        if ('error' in result) {
          await db.updateTranscription(transcription.id, { status: "erro" });
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: result.error });
        }
        await db.updateTranscription(transcription.id, {
          rawText: result.text,
          segments: result.segments ?? [],
          status: "concluido",
        });
        return { success: true, text: result.text, segments: result.segments };
      } catch (err) {
        if (err instanceof TRPCError) throw err;
        await db.updateTranscription(transcription.id, { status: "erro" });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro na transcricao do audio." });
      }
    }),
    review: protectedProcedure.input(z.object({
      id: z.number(),
      reviewedText: z.string(),
    })).mutation(async ({ input, ctx }) => {
      await db.updateTranscription(input.id, {
        reviewedText: input.reviewedText,
        status: "revisado",
        reviewedBy: ctx.user.id,
        reviewedAt: new Date(),
      });
      return { success: true };
    }),
  }),

  // ─── Análise de narrativas com IA ────────────────────────────────────────────
  aiAnalysis: router({
    getByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getAnalysesByProject(input.projectId);
    }),
    getByCycle: protectedProcedure.input(z.object({ cycleId: z.number() })).query(async ({ input }) => {
      return db.getAnalysesByCycle(input.cycleId);
    }),
    analyze: facilitadorProcedure.input(z.object({
      projectId: z.number(),
      cycleId: z.number().optional(),
      fieldEntryId: z.number().optional(),
      text: z.string().min(10),
      analysisType: z.enum(["codigos_tematicos", "sentimentos", "entidades", "topicos", "completa"]),
    })).mutation(async ({ input }) => {
      const systemPrompt = `Voce e um assistente especializado em pesquisa participativa em saude comunitaria no Brasil. 
Analise o texto fornecido e retorne um JSON estruturado com os resultados solicitados.
Mantenha linguagem acessivel e contextualizada para comunidades brasileiras.
Sempre preserve o controle humano: suas sugestoes sao pontos de partida, nao conclusoes definitivas.`;

      let userPrompt = "";
      if (input.analysisType === "codigos_tematicos" || input.analysisType === "completa") {
        userPrompt += `\n\nSUGIRA CODIGOS TEMATICOS: Identifique os principais temas presentes no texto. Para cada tema, forneça: codigo (nome curto), descricao, trechos_relevantes (array de citacoes do texto), frequencia_estimada.`;
      }
      if (input.analysisType === "sentimentos" || input.analysisType === "completa") {
        userPrompt += `\n\nANALISE DE SENTIMENTOS: Identifique o sentimento predominante (positivo, negativo, neutro, misto) e sentimentos especificos presentes (ex: esperanca, medo, indignacao, solidariedade). Inclua justificativa baseada no texto.`;
      }
      if (input.analysisType === "entidades" || input.analysisType === "completa") {
        userPrompt += `\n\nEXTRACAO DE ENTIDADES: Identifique: pessoas_mencionadas, lugares, organizacoes, problemas_de_saude, determinantes_sociais, recursos_comunitarios.`;
      }
      if (input.analysisType === "topicos" || input.analysisType === "completa") {
        userPrompt += `\n\nMODELAGEM DE TOPICOS: Identifique os 3 a 5 topicos principais com palavras-chave associadas e peso relativo (0 a 1).`;
      }

      const response = await invokeLLM({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Texto para analise:\n\n${input.text}\n\n${userPrompt}\n\nRetorne APENAS JSON valido com os campos solicitados.` },
        ],
        response_format: { type: "json_schema", json_schema: {
          name: "narrative_analysis",
          strict: false,
          schema: {
            type: "object",
            properties: {
              codigos_tematicos: { type: "array" },
              sentimentos: { type: "object" },
              entidades: { type: "object" },
              topicos: { type: "array" },
              frequencia_palavras: { type: "object" },
            },
            additionalProperties: true,
          },
        }},
      });

      let parsed: Record<string, unknown> = {};
      try {
        const content = response.choices[0]?.message?.content ?? "{}";
        parsed = JSON.parse(typeof content === "string" ? content : JSON.stringify(content));
      } catch {
        parsed = { raw: response.choices[0]?.message?.content };
      }

      // Calcular frequência de palavras
      const words = input.text.toLowerCase().split(/\s+/).filter(w => w.length > 3);
      const freq: Record<string, number> = {};
      words.forEach(w => { freq[w] = (freq[w] ?? 0) + 1; });
      const topWords = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 50);
      const wordFrequency = Object.fromEntries(topWords);

      const analysis = await db.createAiAnalysis({
        projectId: input.projectId,
        cycleId: input.cycleId,
        fieldEntryId: input.fieldEntryId,
        analysisType: input.analysisType,
        suggestedCodes: (parsed.codigos_tematicos as unknown) ?? null,
        sentimentResult: (parsed.sentimentos as unknown) ?? null,
        entities: (parsed.entidades as unknown) ?? null,
        topics: (parsed.topicos as unknown) ?? null,
        wordFrequency,
        humanValidated: false,
      });
      return { ...parsed, wordFrequency, analysisId: analysis.insertId };
    }),
    validate: protectedProcedure.input(z.object({
      id: z.number(),
      validated: z.boolean(),
      notes: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      await db.updateAiAnalysisValidation(input.id, input.validated, ctx.user.id, input.notes ?? "");
      return { success: true };
    }),
  }),

  // ─── Indicadores de monitoramento ────────────────────────────────────────────
  indicators: router({
    listByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getIndicatorsByProject(input.projectId);
    }),
    create: facilitadorProcedure.input(z.object({
      projectId: z.number(),
      cycleId: z.number().optional(),
      name: z.string().min(1),
      description: z.string().optional(),
      indicatorType: z.enum(["resultado", "processo", "aprendizagem"]),
      targetValue: z.number().optional(),
      currentValue: z.number().optional(),
      unit: z.string().optional(),
      threshold: z.number().optional(),
    })).mutation(async ({ input, ctx }) => {
      const result = await db.createIndicator({ ...input, createdBy: ctx.user.id });
      return result;
    }),
    updateValue: facilitadorProcedure.input(z.object({
      id: z.number(),
      currentValue: z.number(),
      projectId: z.number(),
    })).mutation(async ({ input }) => {
      await db.updateIndicatorValue(input.id, input.currentValue);
      // Verificar limiar
      const indicators = await db.getIndicatorsByProject(input.projectId);
      const indicator = indicators.find(i => i.id === input.id);
      if (indicator?.threshold !== null && indicator?.threshold !== undefined && input.currentValue >= (indicator.threshold ?? 0)) {
        const allUsers = await db.getAllUsers();
        const gestores = allUsers.filter(u => ["gestor", "admin"].includes(u.role));
        for (const u of gestores) {
          await db.createNotification({
            userId: u.id,
            projectId: input.projectId,
            title: "Limiar de indicador atingido",
            message: `O indicador "${indicator.name}" atingiu o valor ${input.currentValue} (limiar: ${indicator.threshold}).`,
            notificationType: "limiar_atingido",
          });
        }
      }
      return { success: true };
    }),
  }),

  // ─── Dados epidemiológicos ────────────────────────────────────────────────────
  epidemiologicalData: router({
    listByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getEpidemiologicalDataByProject(input.projectId);
    }),
    import: facilitadorProcedure.input(z.object({
      projectId: z.number(),
      datasetName: z.string().min(1),
      datasetType: z.enum(["epidemiologico", "social", "ambiental", "outro"]),
      source: z.string().optional(),
      referenceYear: z.number().optional(),
      territory: z.string().optional(),
      records: z.array(z.record(z.string(), z.unknown())),
      columns: z.array(z.string()),
    })).mutation(async ({ input, ctx }) => {
      const result = await db.importEpidemiologicalData({
        projectId: input.projectId,
        datasetName: input.datasetName,
        datasetType: input.datasetType,
        source: input.source,
        referenceYear: input.referenceYear,
        territory: input.territory,
        records: input.records as unknown,
        columns: input.columns as unknown,
        totalRecords: input.records.length,
        importedBy: ctx.user.id,
      });
      return result;
    }),
  }),

  // ─── Planos de incidência política ───────────────────────────────────────────
  actionPlans: router({
    listByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getActionPlansByProject(input.projectId);
    }),
    create: facilitadorProcedure.input(z.object({
      projectId: z.number(),
      title: z.string().min(1),
      objective: z.string().optional(),
      context: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const result = await db.createActionPlan({ ...input, createdBy: ctx.user.id, status: "rascunho" });
      return result;
    }),
    addActor: facilitadorProcedure.input(z.object({
      actionPlanId: z.number(),
      name: z.string().min(1),
      role: z.string().optional(),
      actorType: z.enum(["gestor", "profissional", "comunidade", "academia", "midia", "outro"]),
      strategy: z.string().optional(),
      contact: z.string().optional(),
    })).mutation(async ({ input }) => {
      const result = await db.createActionActor(input);
      return result;
    }),
    getActors: protectedProcedure.input(z.object({ actionPlanId: z.number() })).query(async ({ input }) => {
      return db.getActorsByPlan(input.actionPlanId);
    }),
    addStep: facilitadorProcedure.input(z.object({
      actionPlanId: z.number(),
      description: z.string().min(1),
      responsible: z.string().optional(),
      deadline: z.string().optional(),
    })).mutation(async ({ input }) => {
      const result = await db.createActionStep({
        actionPlanId: input.actionPlanId,
        description: input.description,
        responsible: input.responsible,
        deadline: input.deadline ? new Date(input.deadline) : undefined,
        status: "pendente",
      });
      return result;
    }),
    getSteps: protectedProcedure.input(z.object({ actionPlanId: z.number() })).query(async ({ input }) => {
      return db.getStepsByPlan(input.actionPlanId);
    }),
    updateStepStatus: facilitadorProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["pendente", "em_andamento", "concluido"]),
    })).mutation(async ({ input }) => {
      await db.updateActionStepStatus(input.id, input.status);
      return { success: true };
    }),
  }),

  // ─── Notificações ─────────────────────────────────────────────────────────────
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getNotificationsByUser(ctx.user.id);
    }),
    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      return db.getUnreadNotificationCount(ctx.user.id);
    }),
    markRead: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.markNotificationRead(input.id);
      return { success: true };
    }),
    markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
      await db.markAllNotificationsRead(ctx.user.id);
      return { success: true };
    }),
  }),

  // ─── Eixos Temáticos Geradores (PICAPS) ─────────────────────────────────────
  eixos: router({
    list: publicProcedure.query(async () => {
      await db.seedEixosIfEmpty();
      return db.getAllEixos();
    }),
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getEixoById(input.id);
    }),
    getFactores: publicProcedure.input(z.object({ eixoId: z.number() })).query(async ({ input }) => {
      return db.getFactoresByEixo(input.eixoId);
    }),
  }),
  // ─── Cartografia Social ───────────────────────────────────────────────────────
  socialMapping: router({
    // Sessões
    createSession: protectedProcedure.input(z.object({
      projectId: z.number(),
      cycleId: z.number().optional(),
      territory: z.string().min(1),
      monitorName: z.string().min(1),
      participants: z.number().optional(),
      notes: z.string().optional(),
      sessionDate: z.string().optional(), // ISO date string YYYY-MM-DD
    })).mutation(async ({ ctx, input }) => {
      const id = await db.createSocialMappingSession({
        projectId: input.projectId,
        cycleId: input.cycleId ?? null,
        territory: input.territory,
        monitorName: input.monitorName,
        participants: input.participants ?? 0,
        notes: input.notes ?? null,
        status: "em_andamento",
        createdBy: ctx.user.id,
        sessionDate: input.sessionDate ? new Date(input.sessionDate) : new Date(),
      });
      return { id };
    }),
    listSessions: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getSocialMappingSessionsByProject(input.projectId);
    }),
    getSession: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getSocialMappingSessionById(input.id);
    }),
    updateSession: protectedProcedure.input(z.object({
      id: z.number(),
      territory: z.string().optional(),
      monitorName: z.string().optional(),
      participants: z.number().optional(),
      notes: z.string().optional(),
      status: z.enum(["em_andamento", "concluida"]).optional(),
      sessionDate: z.string().optional(), // ISO date string YYYY-MM-DD
    })).mutation(async ({ ctx, input }) => {
      const session = await db.getSocialMappingSessionById(input.id);
      if (!session) throw new TRPCError({ code: 'NOT_FOUND', message: 'Sessão não encontrada.' });
      const isOwner = session.createdBy === ctx.user.id;
      const hasRole = ['facilitador', 'gestor', 'admin'].includes(ctx.user.role);
      if (!isOwner && !hasRole) {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Apenas o criador da sessão, facilitadores e gestores podem atualizá-la.' });
      }
      const { id, sessionDate, ...rest } = input;
      const data: Record<string, unknown> = { ...rest };
      if (sessionDate) data.sessionDate = new Date(sessionDate);
      await db.updateSocialMappingSession(id, data);
      return { success: true };
    }),
    // Registros de fatores georreferenciados
    createEntry: protectedProcedure.input(z.object({
      sessionId: z.number(),
      projectId: z.number(),
      eixoId: z.number(),
      factorId: z.number(),
      factorName: z.string(),
      characterization: z.string().optional(),
      riskClassification: z.enum(["ameaca", "resiliencia", "vulnerabilidade"]),
      importanceLevel: z.number().min(0).max(10),
      latitude: z.number().optional(),
      longitude: z.number().optional(),
      locationName: z.string().optional(),
      geoPolygon: z.any().optional(),
      photoUrl: z.string().optional(),
      photoKey: z.string().optional(),
      audioUrl: z.string().optional(),
      audioKey: z.string().optional(),
      entryNotes: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      const id = await db.createSocialMappingEntry({
        sessionId: input.sessionId,
        projectId: input.projectId,
        eixoId: input.eixoId,
        factorId: input.factorId,
        factorName: input.factorName,
        characterization: input.characterization ?? null,
        riskClassification: input.riskClassification,
        importanceLevel: input.importanceLevel,
        latitude: input.latitude ?? null,
        longitude: input.longitude ?? null,
        locationName: input.locationName ?? null,
        geoPolygon: input.geoPolygon ?? null,
        photoUrl: input.photoUrl ?? null,
        photoKey: input.photoKey ?? null,
        audioUrl: input.audioUrl ?? null,
        audioKey: input.audioKey ?? null,
        entryNotes: input.entryNotes ?? null,
        createdBy: ctx.user.id,
      });
      return { id };
    }),
    listEntries: protectedProcedure.input(z.object({ sessionId: z.number() })).query(async ({ input }) => {
      return db.getSocialMappingEntriesBySession(input.sessionId);
    }),
    listEntriesByProject: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getSocialMappingEntriesByProject(input.projectId);
    }),
    updateEntry: protectedProcedure.input(z.object({
      id: z.number(),
      characterization: z.string().optional(),
      riskClassification: z.enum(["ameaca", "resiliencia", "vulnerabilidade"]).optional(),
      importanceLevel: z.number().min(0).max(10).optional(),
      latitude: z.number().optional(),
      longitude: z.number().optional(),
      locationName: z.string().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateSocialMappingEntry(id, data);
      return { success: true };
    }),
    deleteEntry: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteSocialMappingEntry(input.id);
      return { success: true };
    }),
    // Encerrar sessão (apenas facilitador/gestor)
    closeSession: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const session = await db.getSocialMappingSessionById(input.id);
      if (!session) throw new TRPCError({ code: 'NOT_FOUND', message: 'Sessão não encontrada.' });
      const isOwner = session.createdBy === ctx.user.id;
      const hasRole = ['facilitador', 'gestor', 'admin'].includes(ctx.user.role);
      if (!isOwner && !hasRole) {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Apenas o criador da sessão, facilitadores e gestores podem encerrá-la.' });
      }
      await db.closeSocialMappingSession(input.id);
      // Notificar o gestor/owner com resumo da sessão
      try {
        const summary = await db.getSessionSummary(input.id);
        if (summary) {
          const { totalEntries, byRisk } = summary;
          const content = [
            `Território: ${session.territory}`,
            `Monitor: ${session.monitorName}`,
            `Data da sessão: ${new Date(session.sessionDate).toLocaleDateString('pt-BR')}`,
            `Encerrada por: ${ctx.user.name ?? ctx.user.email ?? 'usuário desconhecido'}`,
            `Total de fatores registrados: ${totalEntries}`,
            `Ameaças: ${byRisk.ameaca ?? 0} | Vulnerabilidades: ${byRisk.vulnerabilidade ?? 0} | Resiliências: ${byRisk.resiliencia ?? 0}`,
          ].join('\n');
          await notifyOwner({
            title: `Sessão de Cartografia Social encerrada - ${session.territory}`,
            content,
          });
        }
      } catch (_) {
        // Notificação é best-effort: não bloqueia o encerramento
      }
      return { success: true };
    }),
    // Resumo consolidado da sessão
    getSessionSummary: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const summary = await db.getSessionSummary(input.id);
      // Retorna estrutura vazia se sessão não existe (não lança erro)
      return summary ?? { session: null, totalEntries: 0, byRisk: { ameaca: 0, resiliencia: 0, vulnerabilidade: 0 }, byEixo: [], entries: [] };
    }),
    // Atualizar observação livre de um fator
    updateEntryNotes: protectedProcedure.input(z.object({
      id: z.number(),
      entryNotes: z.string().nullable(),
    })).mutation(async ({ ctx, input }) => {
      const entry = await db.getSocialMappingEntryById(input.id);
      if (!entry) throw new TRPCError({ code: 'NOT_FOUND', message: 'Registro não encontrado.' });
      const isOwner = entry.createdBy === ctx.user.id;
      const hasRole = ['facilitador', 'gestor', 'admin'].includes(ctx.user.role);
      if (!isOwner && !hasRole) {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Apenas o criador do registro, facilitadores e gestores podem editar observações.' });
      }
      await db.updateSocialMappingEntryNotes(input.id, input.entryNotes);
      return { success: true };
    }),
    // Dados de todos os fatores de um projeto para mapa agregado
    getProjectMapData: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getSocialMappingEntriesForMap(input.projectId);
    }),
    // Gerar PDF da sessão (server-side via puppeteer)
    generateSessionPdf: protectedProcedure.input(z.object({ sessionId: z.number() })).mutation(async ({ input }) => {
      const summary = await db.getSessionSummary(input.sessionId);
      if (!summary) throw new TRPCError({ code: "NOT_FOUND", message: "Sessão não encontrada." });
      const { session, totalEntries, byRisk, byEixo, entries } = summary;
      const html = buildSessionReportHtml({
        territory: session.territory,
        monitorName: session.monitorName,
        sessionDate: new Date(session.sessionDate).toLocaleDateString('pt-BR'),
        status: session.status,
        closedAt: session.closedAt ? new Date(session.closedAt).toLocaleDateString('pt-BR') : null,
        participants: session.participants,
        notes: session.notes,
        totalEntries,
        byRisk: { ameaca: byRisk.ameaca ?? 0, resiliencia: byRisk.resiliencia ?? 0, vulnerabilidade: byRisk.vulnerabilidade ?? 0 },
        byEixo,
        entries,
        analysisText: session.analysisText,
      });
      const pdfBuffer = await generatePdfFromHtml(html);
      return { pdfBase64: pdfBuffer.toString('base64'), filename: `cartografia-${session.territory.replace(/\s+/g, '-')}-${new Date(session.sessionDate).toISOString().split('T')[0]}.pdf` };
    }),
    // Análise de IA para os fatores de uma sessão
    // Linha do tempo: sessoes agrupadas por territorio
    getSessionsByTerritory: protectedProcedure.input(z.object({ projectId: z.number() })).query(async ({ input }) => {
      return db.getSessionsByTerritoryForProject(input.projectId);
    }),
    // Validacao humana da sintese LLM
    updateAnalysisReview: facilitadorProcedure.input(z.object({ sessionId: z.number(), analysisReview: z.string() })).mutation(async ({ input }) => {
      const session = await db.getSocialMappingSessionById(input.sessionId);
      if (!session) throw new TRPCError({ code: "NOT_FOUND", message: "Sessao nao encontrada." });
      await db.updateSessionAnalysisReview(input.sessionId, input.analysisReview);
      return { success: true };
    }),
    // Relatorio consolidado do projeto em PDF
    generateProjectReport: facilitadorProcedure.input(z.object({ projectId: z.number() })).mutation(async ({ input }) => {
      const { data: project } = await (async () => {
        const p = await db.getProjectById(input.projectId);
        return { data: p };
      })();
      const summaries = await db.getAllSessionSummariesForProject(input.projectId);
      if (!summaries.length) throw new TRPCError({ code: "NOT_FOUND", message: "Nenhuma sessao encontrada neste projeto." });
      const html = buildProjectReportHtml({ project: project ?? null, summaries });
      const pdfBuffer = await generatePdfFromHtml(html);
      const projectName = (project as any)?.name ?? `projeto-${input.projectId}`;
      return {
        pdfBase64: pdfBuffer.toString("base64"),
        filename: `relatorio-${projectName.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().split("T")[0]}.pdf`,
      };
    }),
    getEntryComments: protectedProcedure.input(z.object({ entryId: z.number() })).query(async ({ input }) => {
      return db.getEntryComments(input.entryId);
    }),
    addEntryComment: protectedProcedure.input(z.object({
      entryId: z.number(),
      sessionId: z.number(),
      projectId: z.number(),
      content: z.string().min(1).max(2000),
    })).mutation(async ({ input, ctx }) => {
      return db.createEntryComment({
        entryId: input.entryId,
        sessionId: input.sessionId,
        projectId: input.projectId,
        authorId: ctx.user.id,
        authorName: ctx.user.name ?? ctx.user.openId,
        content: input.content,
      });
    }),
    deleteEntryComment: protectedProcedure.input(z.object({ commentId: z.number() })).mutation(async ({ input, ctx }) => {
      await db.deleteEntryComment(input.commentId, ctx.user.id);
      return { success: true };
    }),
    getSessionEntriesWithComments: protectedProcedure.input(z.object({ sessionId: z.number() })).query(async ({ input }) => {
      return db.getSessionEntriesWithComments(input.sessionId);
    }),
    getSessionsTimelineForTerritory: protectedProcedure.input(z.object({
      projectId: z.number(),
      territory: z.string(),
    })).query(async ({ input }) => {
      return db.getSessionsTimelineForTerritory(input.projectId, input.territory);
    }),
    generateTimelinePdf: facilitadorProcedure.input(z.object({ projectId: z.number() })).mutation(async ({ input }) => {
      const summaries = await db.getAllSessionSummariesForProject(input.projectId);
      const projects = await db.getProjectById(input.projectId);
      const html = buildProjectReportHtml({ project: projects ?? null, summaries });
      const pdfBuffer = await generatePdfFromHtml(html);
      const projectName = projects?.title ?? `projeto-${input.projectId}`;
      return {
        pdfBase64: pdfBuffer.toString("base64"),
        filename: `linha-do-tempo-${projectName.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().split("T")[0]}.pdf`,
      };
    }),
    analyzeSession: facilitadorProcedure.input(z.object({ sessionId: z.number() })).mutation(async ({ input }) => {
      const entries = await db.getSocialMappingEntriesBySession(input.sessionId);
      if (!entries.length) throw new TRPCError({ code: "NOT_FOUND", message: "Nenhum fator registrado nesta sessão." });
      const factorSummary = entries.map(e =>
        `Eixo ${e.eixoData?.number} - ${e.eixoData?.title}: Fator "${e.entry.factorName}" | Risco: ${e.entry.riskClassification} | Importância: ${e.entry.importanceLevel}/10 | Caracterização: ${e.entry.characterization ?? "Não informada"}${e.entry.entryNotes ? ` | Observações: ${e.entry.entryNotes}` : ""}`
      ).join("\n");
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Você é um analista de pesquisa participativa em saúde comunitária e epidemiologia territorial. Analise os fatores de uma sessão de cartografia social e produza uma síntese crítica em português brasileiro, identificando padrões, convergências e divergências entre os fatores, destacando os mais críticos para o território. Seja preciso, técnico e orientado à tomada de decisão em saúde pública." },
          { role: "user", content: `Analise os seguintes fatores registrados em uma sessão de cartografia social:\n\n${factorSummary}\n\nProduz uma síntese analítica com: 1) Padrão geral identificado; 2) Fatores de maior criticidade; 3) Relações entre ameaças e vulnerabilidades; 4) Potenciais de resiliência; 5) Recomendações para o plano de ação territorial.` },
        ],
      });
      const rawContent = response.choices[0]?.message?.content ?? "";
      const analysis = typeof rawContent === "string" ? rawContent : "";
      // Persistir a análise na sessão para recuperação posterior
      if (analysis) {
        await db.updateSessionAnalysis(input.sessionId, analysis);
      }
      return { analysis };
    }),
  }),
  // ─── Endpoint para tarefas agendadas ─────────────────────────────────────────
  scheduled: router({
    syncData: publicProcedure.input(z.object({
      payload: z.any(),
    })).mutation(async ({ input }) => {
      return { success: true, received: input.payload };
    }),
  }),
});

export type AppRouter = typeof appRouter;
