import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function makeCtx(role: "pesquisador_popular" | "facilitador" | "gestor" | "admin" | "user" = "user"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      name: "Pesquisador Teste",
      email: "teste@pesquisa.org",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

function makeAnonCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("retorna null para usuario nao autenticado", async () => {
    const caller = appRouter.createCaller(makeAnonCtx());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("retorna usuario autenticado com perfil correto", async () => {
    const caller = appRouter.createCaller(makeCtx("facilitador"));
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.role).toBe("facilitador");
  });
});

// ─── Perfis de acesso ─────────────────────────────────────────────────────────

describe("controle de acesso por perfil", () => {
  it("pesquisador_popular nao pode criar projetos", async () => {
    const caller = appRouter.createCaller(makeCtx("pesquisador_popular"));
    await expect(
      caller.projects.create({ name: "Projeto Teste", description: "Desc" })
    ).rejects.toThrow();
  });

  it("facilitador pode criar projetos", async () => {
    // Este teste verifica que a procedure nao rejeita o perfil facilitador
    // (pode falhar por DB indisponivel, mas nao por permissao)
    const caller = appRouter.createCaller(makeCtx("facilitador"));
    try {
      await caller.projects.create({ name: "Projeto Teste", description: "Desc" });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      // Aceita erro de DB (sem conexao no ambiente de teste), mas nao de permissao
      expect(msg).not.toContain("FORBIDDEN");
      expect(msg).not.toContain("UNAUTHORIZED");
    }
  });

  it("pesquisador_popular pode registrar coleta em campo", async () => {
    const caller = appRouter.createCaller(makeCtx("pesquisador_popular"));
    try {
      await caller.fieldEntries.create({
        projectId: 1,
        cycleId: 1,
        entryType: "narrativa",
        narrativeText: "Relato de campo sobre acesso a saude",
        latitude: -15.7801,
        longitude: -47.9292,
        locationName: "Ceilandia Norte",
      });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      expect(msg).not.toContain("FORBIDDEN");
      expect(msg).not.toContain("UNAUTHORIZED");
    }
  });

  it("usuario nao autenticado nao pode criar coleta", async () => {
    const caller = appRouter.createCaller(makeAnonCtx());
    await expect(
      caller.fieldEntries.create({
        projectId: 1,
        cycleId: 1,
        entryType: "narrativa",
        narrativeText: "Teste",
        latitude: -15.7801,
        longitude: -47.9292,
        locationName: "Local",
      })
    ).rejects.toThrow();
  });
});

// ─── Analise de IA ────────────────────────────────────────────────────────────

describe("aiAnalysis.analyze - validacao de entrada", () => {
  it("rejeita texto vazio", async () => {
    const caller = appRouter.createCaller(makeCtx("facilitador"));
    await expect(
      caller.aiAnalysis.analyze({
        projectId: 1,
        text: "",
        analysisType: "completa",
      })
    ).rejects.toThrow();
  });

  it("rejeita tipo de analise invalido", async () => {
    const caller = appRouter.createCaller(makeCtx("facilitador"));
    await expect(
      caller.aiAnalysis.analyze({
        projectId: 1,
        text: "Narrativa de teste",
        // @ts-expect-error - testando valor invalido intencionalmente
        analysisType: "tipo_invalido",
      })
    ).rejects.toThrow();
  });
});

// ─── Indicadores ─────────────────────────────────────────────────────────────

describe("indicators.create - validacao de entrada", () => {
  it("rejeita nome vazio", async () => {
    const caller = appRouter.createCaller(makeCtx("facilitador"));
    await expect(
      caller.indicators.create({
        projectId: 1,
        name: "",
        indicatorType: "resultado",
      })
    ).rejects.toThrow();
  });

  it("pesquisador_popular nao pode criar indicadores", async () => {
    const caller = appRouter.createCaller(makeCtx("pesquisador_popular"));
    await expect(
      caller.indicators.create({
        projectId: 1,
        name: "Indicador Teste",
        indicatorType: "resultado",
      })
    ).rejects.toThrow();
  });
});

// ─── Planos de incidencia ─────────────────────────────────────────────────────

describe("actionPlans.create - validacao de entrada", () => {
  it("rejeita titulo vazio", async () => {
    const caller = appRouter.createCaller(makeCtx("facilitador"));
    await expect(
      caller.actionPlans.create({
        projectId: 1,
        title: "",
      })
    ).rejects.toThrow();
  });

  it("pesquisador_popular nao pode criar planos de incidencia", async () => {
    const caller = appRouter.createCaller(makeCtx("pesquisador_popular"));
    await expect(
      caller.actionPlans.create({
        projectId: 1,
        title: "Plano Teste",
      })
    ).rejects.toThrow();
  });
});

// ─── Logout ───────────────────────────────────────────────────────────────────

describe("auth.logout", () => {
  it("retorna sucesso e limpa cookie de sessao", async () => {
    const cleared: string[] = [];
    const ctx: TrpcContext = {
      user: {
        id: 1,
        openId: "test",
        name: "Teste",
        email: "t@t.com",
        loginMethod: "manus",
        role: "user",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: (name: string) => cleared.push(name) } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(cleared.length).toBeGreaterThan(0);
  });
});
