import puppeteer from "puppeteer-core";

/**
 * Gera um PDF a partir de HTML usando o Chromium do sistema.
 * Retorna o buffer do PDF.
 */
export async function generatePdfFromHtml(html: string): Promise<Buffer> {
  const executablePath =
    process.env.CHROMIUM_PATH ||
    "/usr/bin/chromium" ||
    "/usr/bin/chromium-browser" ||
    "/usr/bin/google-chrome";

  const browser = await puppeteer.launch({
    executablePath,
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--no-first-run",
      "--no-zygote",
      "--single-process",
    ],
  });

  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: "networkidle0" });
    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: { top: "20mm", right: "15mm", bottom: "20mm", left: "15mm" },
    });
    return Buffer.from(pdfBuffer);
  } finally {
    await browser.close();
  }
}

/**
 * Converte dados de resumo de sessão de cartografia social em HTML
 * para geração de PDF com cabeçalho institucional.
 */
export function buildSessionReportHtml(params: {
  territory: string;
  monitorName: string;
  sessionDate: string;
  status: string;
  closedAt?: string | null;
  participants?: number | null;
  notes?: string | null;
  totalEntries: number;
  byRisk: { ameaca: number; resiliencia: number; vulnerabilidade: number };
  byEixo: Array<{ number: number; title: string; color: string; count: number }>;
  entries: Array<{
    entry: {
      factorName: string;
      riskClassification: string;
      importanceLevel: number;
      characterization: string | null;
      entryNotes: string | null;
      latitude: number | null;
      longitude: number | null;
      locationName: string | null;
    };
    eixoData: { number: number; title: string; color: string } | null;
  }>;
  analysisText?: string | null;
}): string {
  const {
    territory, monitorName, sessionDate, status, closedAt, participants, notes,
    totalEntries, byRisk, byEixo, entries, analysisText,
  } = params;

  const riskLabel: Record<string, string> = {
    ameaca: "Ameaça",
    resiliencia: "Resiliência",
    vulnerabilidade: "Vulnerabilidade",
  };
  const riskColor: Record<string, string> = {
    ameaca: "#dc2626",
    resiliencia: "#16a34a",
    vulnerabilidade: "#d97706",
  };

  const entriesHtml = entries.map(({ entry, eixoData }: any) => `
    <div class="factor-card">
      <div class="factor-header">
        <span class="factor-name">${entry.factorName}</span>
        <span class="risk-badge" style="background:${riskColor[entry.riskClassification] ?? "#6b7280"}">
          ${riskLabel[entry.riskClassification] ?? entry.riskClassification}
        </span>
      </div>
      ${eixoData ? `<div class="ods-tag" style="border-left:4px solid ${eixoData.color}">Eixo ${eixoData.number} - ${eixoData.title}</div>` : ""}
      <div class="factor-meta">
        <span>Importância: <strong>${entry.importanceLevel}/10</strong></span>
        ${entry.locationName ? `<span>Local: ${entry.locationName}</span>` : ""}
        ${entry.latitude && entry.longitude ? `<span>Coord: ${entry.latitude.toFixed(5)}, ${entry.longitude.toFixed(5)}</span>` : ""}
      </div>
      ${entry.characterization ? `<div class="factor-text"><strong>Caracterização:</strong> ${entry.characterization}</div>` : ""}
      ${entry.entryNotes ? `<div class="factor-text"><strong>Observações:</strong> ${entry.entryNotes}</div>` : ""}
    </div>
  `).join("");

  const eixoByEixoHtml = byEixo.map((o: any) => `
    <tr>
      <td><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${o.color};margin-right:6px;"></span>ODS ${o.number}</td>
      <td>${o.title}</td>
      <td style="text-align:center"><strong>${o.count}</strong></td>
    </tr>
  `).join("");

  const analysisHtml = analysisText
    ? `<div class="section">
        <h2>Síntese Analítica (IA)</h2>
        <div class="analysis-text">${analysisText.replace(/\n/g, "<br>")}</div>
      </div>`
    : "";

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Relatório de Cartografia Social - ${territory}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 11pt; color: #1a1a1a; line-height: 1.5; }
    .header { background: #1a3a5c; color: white; padding: 20px 24px; margin-bottom: 24px; }
    .header h1 { font-size: 16pt; font-weight: 700; margin-bottom: 4px; }
    .header .subtitle { font-size: 10pt; opacity: 0.85; }
    .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 24px; padding: 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; }
    .meta-item { font-size: 10pt; }
    .meta-item strong { color: #1a3a5c; }
    .section { margin-bottom: 24px; }
    .section h2 { font-size: 13pt; color: #1a3a5c; border-bottom: 2px solid #1a3a5c; padding-bottom: 4px; margin-bottom: 12px; }
    table { width: 100%; border-collapse: collapse; font-size: 10pt; }
    th { background: #1a3a5c; color: white; padding: 8px 10px; text-align: left; }
    td { padding: 7px 10px; border-bottom: 1px solid #e2e8f0; }
    tr:nth-child(even) td { background: #f8fafc; }
    .factor-card { border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; margin-bottom: 10px; page-break-inside: avoid; }
    .factor-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px; }
    .factor-name { font-weight: 600; font-size: 11pt; color: #1a1a1a; flex: 1; }
    .risk-badge { color: white; font-size: 9pt; padding: 2px 8px; border-radius: 12px; white-space: nowrap; margin-left: 8px; }
    .ods-tag { font-size: 9pt; color: #4a5568; padding: 3px 8px; background: #f8fafc; margin-bottom: 6px; }
    .factor-meta { font-size: 9pt; color: #6b7280; display: flex; gap: 16px; margin-bottom: 6px; flex-wrap: wrap; }
    .factor-text { font-size: 10pt; color: #374151; margin-top: 4px; }
    .analysis-text { font-size: 10pt; color: #374151; line-height: 1.7; padding: 12px; background: #f0f4ff; border-left: 4px solid #4f46e5; border-radius: 4px; }
    .stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px; }
    .stat-card { text-align: center; padding: 12px; border-radius: 6px; }
    .stat-card .num { font-size: 22pt; font-weight: 700; }
    .stat-card .label { font-size: 9pt; margin-top: 2px; }
    .footer { margin-top: 32px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 9pt; color: #9ca3af; text-align: center; }
    @page { margin: 0; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Relatório de Cartografia Social</h1>
    <div class="subtitle">Plataforma de Pesquisa Participativa em Saúde Comunitária</div>
  </div>

  <div class="meta-grid">
    <div class="meta-item"><strong>Território:</strong> ${territory}</div>
    <div class="meta-item"><strong>Monitor:</strong> ${monitorName}</div>
    <div class="meta-item"><strong>Data da sessão:</strong> ${sessionDate}</div>
    <div class="meta-item"><strong>Status:</strong> ${status === "concluida" ? "Concluída" : "Em andamento"}</div>
    ${closedAt ? `<div class="meta-item"><strong>Encerrada em:</strong> ${closedAt}</div>` : ""}
    ${participants ? `<div class="meta-item"><strong>Participantes:</strong> ${participants}</div>` : ""}
    ${notes ? `<div class="meta-item" style="grid-column:1/-1"><strong>Observações gerais:</strong> ${notes}</div>` : ""}
  </div>

  <div class="stats-row">
    <div class="stat-card" style="background:#fef2f2;color:#dc2626">
      <div class="num">${byRisk.ameaca ?? 0}</div>
      <div class="label">Ameaças</div>
    </div>
    <div class="stat-card" style="background:#fefce8;color:#d97706">
      <div class="num">${byRisk.vulnerabilidade ?? 0}</div>
      <div class="label">Vulnerabilidades</div>
    </div>
    <div class="stat-card" style="background:#f0fdf4;color:#16a34a">
      <div class="num">${byRisk.resiliencia ?? 0}</div>
      <div class="label">Resiliências</div>
    </div>
  </div>

  ${byEixo.length > 0 ? `
  <div class="section">
    <h2>Distribuição por ODS</h2>
    <table>
      <thead><tr><th>Eixo</th><th>Título</th><th style="text-align:center">Registros</th></tr></thead>
      <tbody>${eixoByEixoHtml}</tbody>
    </table>
  </div>` : ""}

  ${analysisHtml}

  <div class="section">
    <h2>Fatores Registrados (${totalEntries})</h2>
    ${entriesHtml}
  </div>

  <div class="footer">
    Gerado em ${new Date().toLocaleString("pt-BR")} - Plataforma de Pesquisa Participativa com IA
  </div>
</body>
</html>`;
}

/**
 * Constrói o HTML do relatório consolidado de um projeto,
 * agregando todas as sessões com sumário executivo e distribuição por ODS/risco.
 */
export function buildProjectReportHtml(params: {
  project: { name?: string | null; description?: string | null; location?: string | null; status?: string | null; title?: string | null; territory?: string | null } | null;
  summaries: Array<{
    session: {
      territory: string;
      monitorName: string;
      sessionDate: Date | string;
      status: string;
      closedAt?: Date | string | null;
      participants?: number | null;
      notes?: string | null;
      analysisText?: string | null;
      analysisReview?: string | null;
    };
    totalEntries: number;
    byRisk: Record<string, number>;
    byEixo: Array<{ number: number; title: string; color: string; count: number }>;
    entries: Array<{
      entry: {
        factorName: string;
        riskClassification: string;
        importanceLevel: number;
        characterization: string | null;
        entryNotes: string | null;
        latitude: number | null;
        longitude: number | null;
        locationName: string | null;
      };
      eixoData: { number: number; title: string; color: string } | null;
    }>;
  }>;
}): string {
  const { project, summaries } = params;
  const projectName = project?.name ?? "Projeto";
  const projectLocation = project?.location ?? "";
  const totalSessions = summaries.length;
  const totalFactors = summaries.reduce((s, r) => s + r.totalEntries, 0);
  const totalAmeacas = summaries.reduce((s, r) => s + (r.byRisk.ameaca ?? 0), 0);
  const totalVulnerabilidades = summaries.reduce((s, r) => s + (r.byRisk.vulnerabilidade ?? 0), 0);
  const totalResiliencias = summaries.reduce((s, r) => s + (r.byRisk.resiliencia ?? 0), 0);
  // Agregar ODS globalmente
  const globalEixo: Record<number, { number: number; title: string; color: string; count: number }> = {};
  for (const r of summaries) {
    for (const o of (r.byEixo ?? [])) {
      if (!globalEixo[o.number]) globalEixo[o.number] = { ...o, count: 0 };
      globalEixo[o.number].count += o.count;
    }
  }
  const eixoRanking = Object.values(globalEixo).sort((a, b) => b.count - a.count);

  const riskColor: Record<string, string> = {
    ameaca: "#dc2626",
    resiliencia: "#16a34a",
    vulnerabilidade: "#d97706",
  };
  const riskLabel: Record<string, string> = {
    ameaca: "Ameaça",
    resiliencia: "Resiliência",
    vulnerabilidade: "Vulnerabilidade",
  };

  const sessionsHtml = summaries.map((r, idx) => {
    const { session, totalEntries, byRisk, byEixo: sessionByEixo, entries } = r as any;
    const dateStr = session.sessionDate ? new Date(session.sessionDate).toLocaleDateString("pt-BR") : "Não informada";
    const entriesHtml = entries.slice(0, 10).map(({ entry, eixoData }: any) => `
      <tr>
        <td>${entry.factorName}</td>
        <td>${eixoData ? `Eixo ${eixoData.number}` : "-"}</td>
        <td><span style="color:${riskColor[entry.riskClassification] ?? "#666"};font-weight:600">${riskLabel[entry.riskClassification] ?? entry.riskClassification}</span></td>
        <td style="text-align:center">${entry.importanceLevel}/10</td>
      </tr>
    `).join("");
    const moreEntries = totalEntries > 10 ? `<tr><td colspan="4" style="text-align:center;color:#6b7280;font-style:italic">... e mais ${totalEntries - 10} fatores</td></tr>` : "";
    return `
    <div class="session-block" style="page-break-inside:avoid">
      <div class="session-header">
        <span class="session-num">${idx + 1}</span>
        <div>
          <div class="session-title">${session.territory}</div>
          <div class="session-meta">Monitor: ${session.monitorName} | Data: ${dateStr} | ${session.participants ? `${session.participants} participantes | ` : ""}${totalEntries} fatores</div>
        </div>
        <span class="session-status ${session.status === "concluida" ? "concluida" : "andamento"}">${session.status === "concluida" ? "Concluída" : "Em andamento"}</span>
      </div>
      <div class="risk-mini">
        <span style="color:#dc2626">&#9679; ${byRisk.ameaca ?? 0} ameaças</span>
        <span style="color:#d97706">&#9679; ${byRisk.vulnerabilidade ?? 0} vulnerabilidades</span>
        <span style="color:#16a34a">&#9679; ${byRisk.resiliencia ?? 0} resiliências</span>
      </div>
      ${session.analysisText ? `<div class="analysis-block"><strong>Síntese analítica:</strong><br>${session.analysisText.replace(/\n/g, "<br>")}</div>` : ""}
      ${session.analysisReview ? `<div class="review-block"><strong>Revisão editorial:</strong><br>${session.analysisReview.replace(/\n/g, "<br>")}</div>` : ""}
      ${entries.length > 0 ? `
      <table class="factor-table">
        <thead><tr><th>Fator</th><th>Eixo</th><th>Risco</th><th>Importância</th></tr></thead>
        <tbody>${entriesHtml}${moreEntries}</tbody>
      </table>` : ""}
    </div>`;
  }).join("");

  const odsTableHtml = eixoRanking.map(o => `
    <tr>
      <td><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${o.color};margin-right:6px;"></span>ODS ${o.number}</td>
      <td>${o.title}</td>
      <td style="text-align:center"><strong>${o.count}</strong></td>
    </tr>
  `).join("");

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Relatório Consolidado - ${projectName}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 11pt; color: #1a1a1a; line-height: 1.5; }
    .header { background: #1a3a5c; color: white; padding: 20px 24px; margin-bottom: 24px; }
    .header h1 { font-size: 16pt; font-weight: 700; margin-bottom: 4px; }
    .header .subtitle { font-size: 10pt; opacity: 0.85; }
    .header .meta { font-size: 9pt; opacity: 0.7; margin-top: 6px; }
    .exec-summary { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin-bottom: 24px; }
    .exec-summary h2 { font-size: 13pt; color: #1a3a5c; margin-bottom: 10px; }
    .stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-bottom: 16px; }
    .stat-card { text-align: center; padding: 10px; border-radius: 6px; }
    .stat-card .num { font-size: 18pt; font-weight: 700; }
    .stat-card .label { font-size: 8pt; margin-top: 2px; }
    .section { margin-bottom: 24px; }
    .section h2 { font-size: 13pt; color: #1a3a5c; border-bottom: 2px solid #1a3a5c; padding-bottom: 4px; margin-bottom: 12px; }
    table { width: 100%; border-collapse: collapse; font-size: 10pt; }
    th { background: #1a3a5c; color: white; padding: 7px 10px; text-align: left; }
    td { padding: 6px 10px; border-bottom: 1px solid #e2e8f0; }
    tr:nth-child(even) td { background: #f8fafc; }
    .session-block { border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px; margin-bottom: 16px; }
    .session-header { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 8px; }
    .session-num { background: #1a3a5c; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11pt; font-weight: 700; flex-shrink: 0; }
    .session-title { font-size: 12pt; font-weight: 600; color: #1a1a1a; }
    .session-meta { font-size: 9pt; color: #6b7280; margin-top: 2px; }
    .session-status { margin-left: auto; font-size: 9pt; padding: 2px 10px; border-radius: 12px; white-space: nowrap; }
    .session-status.concluida { background: #dcfce7; color: #16a34a; }
    .session-status.andamento { background: #fef9c3; color: #ca8a04; }
    .risk-mini { font-size: 9pt; display: flex; gap: 16px; margin-bottom: 8px; flex-wrap: wrap; }
    .analysis-block { font-size: 9.5pt; color: #374151; padding: 8px 12px; background: #f0f4ff; border-left: 3px solid #4f46e5; border-radius: 3px; margin-bottom: 8px; line-height: 1.6; }
    .review-block { font-size: 9.5pt; color: #374151; padding: 8px 12px; background: #f0fdf4; border-left: 3px solid #16a34a; border-radius: 3px; margin-bottom: 8px; line-height: 1.6; }
    .factor-table { font-size: 9pt; margin-top: 8px; }
    .factor-table th { font-size: 9pt; padding: 5px 8px; }
    .factor-table td { padding: 4px 8px; }
    .footer { margin-top: 32px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 9pt; color: #9ca3af; text-align: center; }
    @page { margin: 0; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Relatório Consolidado de Cartografia Social</h1>
    <div class="subtitle">Plataforma de Pesquisa Participativa em Saúde Comunitária</div>
    <div class="meta">${projectName}${projectLocation ? ` | ${projectLocation}` : ""} | Gerado em ${new Date().toLocaleDateString("pt-BR")}</div>
  </div>

  <div class="exec-summary">
    <h2>Sumário Executivo</h2>
    <div class="stats-row">
      <div class="stat-card" style="background:#eff6ff;color:#1d4ed8">
        <div class="num">${totalSessions}</div>
        <div class="label">Sessões</div>
      </div>
      <div class="stat-card" style="background:#f5f3ff;color:#7c3aed">
        <div class="num">${totalFactors}</div>
        <div class="label">Fatores</div>
      </div>
      <div class="stat-card" style="background:#fef2f2;color:#dc2626">
        <div class="num">${totalAmeacas}</div>
        <div class="label">Ameaças</div>
      </div>
      <div class="stat-card" style="background:#fefce8;color:#d97706">
        <div class="num">${totalVulnerabilidades}</div>
        <div class="label">Vulnerabilidades</div>
      </div>
      <div class="stat-card" style="background:#f0fdf4;color:#16a34a">
        <div class="num">${totalResiliencias}</div>
        <div class="label">Resiliências</div>
      </div>
    </div>
  </div>

  ${eixoRanking.length > 0 ? `
  <div class="section">
    <h2>Distribuição Global por ODS</h2>
    <table>
      <thead><tr><th>Eixo</th><th>Título</th><th style="text-align:center">Total de Registros</th></tr></thead>
      <tbody>${odsTableHtml}</tbody>
    </table>
  </div>` : ""}

  <div class="section">
    <h2>Sessões de Cartografia (${totalSessions})</h2>
    ${sessionsHtml}
  </div>

  <div class="footer">
    Relatório gerado em ${new Date().toLocaleString("pt-BR")} - Plataforma de Pesquisa Participativa com IA - Fiocruz Brasília / CoLaboratório CTIS
  </div>
</body>
</html>`;
}
