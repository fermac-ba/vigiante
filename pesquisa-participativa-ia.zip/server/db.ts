import { eq, desc, and, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  projects, InsertProject,
  researchCycles, InsertResearchCycle,
  fieldEntries, InsertFieldEntry,
  transcriptions, InsertTranscription,
  aiAnalyses, InsertAiAnalysis,
  monitoringIndicators, InsertMonitoringIndicator,
  epidemiologicalData, InsertEpidemiologicalData,
  actionPlans, InsertActionPlan,
  actionActors, InsertActionActor,
  actionSteps, InsertActionStep,
  notifications, InsertNotification,
  projectMembers,
  eixosTematicos, InsertEixoTematico,
  eixosFatores, InsertEixoFator,
  socialMappingSessions, InsertSocialMappingSession,
  socialMappingEntries, InsertSocialMappingEntry,
  socialMappingEntryComments, InsertSocialMappingEntryComment,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    });
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "pesquisador_popular" | "facilitador" | "gestor" | "admin") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ─── Projects ─────────────────────────────────────────────────────────────────
export async function createProject(data: InsertProject) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(projects).values(data);
  return result;
}

export async function getProjects() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projects).orderBy(desc(projects.createdAt));
}

export async function getProjectById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  return result[0];
}

export async function updateProject(id: number, data: Partial<InsertProject>) {
  const db = await getDb();
  if (!db) return;
  await db.update(projects).set(data).where(eq(projects.id, id));
}

// ─── Research Cycles ──────────────────────────────────────────────────────────
export async function createResearchCycle(data: InsertResearchCycle) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(researchCycles).values(data);
  return result;
}

export async function getCyclesByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(researchCycles).where(eq(researchCycles.projectId, projectId)).orderBy(desc(researchCycles.createdAt));
}

export async function updateCycleStatus(id: number, status: "planejamento" | "coleta" | "analise" | "validacao" | "concluido") {
  const db = await getDb();
  if (!db) return;
  await db.update(researchCycles).set({ status }).where(eq(researchCycles.id, id));
}

// ─── Field Entries ────────────────────────────────────────────────────────────
export async function createFieldEntry(data: InsertFieldEntry) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(fieldEntries).values(data);
  return result;
}

export async function getFieldEntriesByCycle(cycleId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(fieldEntries).where(eq(fieldEntries.cycleId, cycleId)).orderBy(desc(fieldEntries.createdAt));
}

export async function getFieldEntriesByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(fieldEntries).where(eq(fieldEntries.projectId, projectId)).orderBy(desc(fieldEntries.createdAt));
}

export async function getFieldEntryById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(fieldEntries).where(eq(fieldEntries.id, id)).limit(1);
  return result[0];
}

export async function countFieldEntriesByProject(projectId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(fieldEntries).where(eq(fieldEntries.projectId, projectId));
  return Number(result[0]?.count ?? 0);
}

// ─── Transcriptions ───────────────────────────────────────────────────────────
export async function createTranscription(data: InsertTranscription) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(transcriptions).values(data);
  return result;
}

export async function getTranscriptionByEntry(fieldEntryId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(transcriptions).where(eq(transcriptions.fieldEntryId, fieldEntryId)).limit(1);
  return result[0];
}

export async function updateTranscription(id: number, data: Partial<InsertTranscription>) {
  const db = await getDb();
  if (!db) return;
  await db.update(transcriptions).set(data).where(eq(transcriptions.id, id));
}

export async function getPendingTranscriptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(transcriptions).where(eq(transcriptions.status, "pendente"));
}

// ─── AI Analyses ──────────────────────────────────────────────────────────────
export async function createAiAnalysis(data: InsertAiAnalysis) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(aiAnalyses).values(data);
  return result;
}

export async function getAnalysesByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(aiAnalyses).where(eq(aiAnalyses.projectId, projectId)).orderBy(desc(aiAnalyses.createdAt));
}

export async function getAnalysesByCycle(cycleId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(aiAnalyses).where(eq(aiAnalyses.cycleId, cycleId)).orderBy(desc(aiAnalyses.createdAt));
}

export async function updateAiAnalysisValidation(id: number, validated: boolean, validatedBy: number, notes: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(aiAnalyses).set({
    humanValidated: validated,
    validatedBy,
    validatedAt: new Date(),
    humanNotes: notes,
  }).where(eq(aiAnalyses.id, id));
}

// ─── Monitoring Indicators ────────────────────────────────────────────────────
export async function createIndicator(data: InsertMonitoringIndicator) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(monitoringIndicators).values(data);
  return result;
}

export async function getIndicatorsByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(monitoringIndicators).where(eq(monitoringIndicators.projectId, projectId));
}

export async function updateIndicatorValue(id: number, currentValue: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(monitoringIndicators).set({ currentValue }).where(eq(monitoringIndicators.id, id));
}

// ─── Epidemiological Data ─────────────────────────────────────────────────────
export async function importEpidemiologicalData(data: InsertEpidemiologicalData) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(epidemiologicalData).values(data);
  return result;
}

export async function getEpidemiologicalDataByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(epidemiologicalData).where(eq(epidemiologicalData.projectId, projectId)).orderBy(desc(epidemiologicalData.createdAt));
}

// ─── Action Plans ─────────────────────────────────────────────────────────────
export async function createActionPlan(data: InsertActionPlan) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(actionPlans).values(data);
  return result;
}

export async function getActionPlansByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(actionPlans).where(eq(actionPlans.projectId, projectId)).orderBy(desc(actionPlans.createdAt));
}

export async function createActionActor(data: InsertActionActor) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(actionActors).values(data);
  return result;
}

export async function getActorsByPlan(actionPlanId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(actionActors).where(eq(actionActors.actionPlanId, actionPlanId));
}

export async function createActionStep(data: InsertActionStep) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(actionSteps).values(data);
  return result;
}

export async function getStepsByPlan(actionPlanId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(actionSteps).where(eq(actionSteps.actionPlanId, actionPlanId));
}

export async function updateActionStepStatus(id: number, status: "pendente" | "em_andamento" | "concluido") {
  const db = await getDb();
  if (!db) return;
  await db.update(actionSteps).set({ status }).where(eq(actionSteps.id, id));
}

// ─── Notifications ────────────────────────────────────────────────────────────
export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values(data);
}

export async function getNotificationsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(50);
}

export async function markNotificationRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ read: true }).where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
}

export async function getUnreadNotificationCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
  return Number(result[0]?.count ?? 0);
}

// ─── Project Members ──────────────────────────────────────────────────────────
export async function addProjectMember(projectId: number, userId: number, role: "pesquisador_popular" | "facilitador" | "gestor") {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectMembers).values({ projectId, userId, role }).onDuplicateKeyUpdate({ set: { role } });
}

export async function getProjectMembers(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ member: projectMembers, user: users }).from(projectMembers).innerJoin(users, eq(projectMembers.userId, users.id)).where(eq(projectMembers.projectId, projectId));
}

// ─── Eixos Temáticos ──────────────────────────────────────────────────────────
export async function getAllEixos() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eixosTematicos).orderBy(eixosTematicos.number);
}
export async function getEixoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(eixosTematicos).where(eq(eixosTematicos.id, id)).limit(1);
  return result[0];
}
export async function seedEixosIfEmpty() {
  const db = await getDb();
  if (!db) return;
  const { EIXOS_DATA } = await import("./eixos-seed.js");
  const existingEixos = await db.select({ number: eixosTematicos.number }).from(eixosTematicos);
  const existingNumbers = new Set(existingEixos.map(e => e.number));
  for (const item of EIXOS_DATA) {
    if (existingNumbers.has(item.number)) continue;
    const [inserted] = await db.insert(eixosTematicos).values({
      number: item.number,
      slug: item.slug,
      title: item.title,
      contradicaoCentral: item.contradicaoCentral,
      focoPedagogico: item.focoPedagogico,
      color: item.color,
      iconEmoji: item.iconEmoji,
    });
    const eixoId = (inserted as any).insertId as number;
    for (const factorName of item.factors) {
      await db.insert(eixosFatores).values({ eixoId, name: factorName });
    }
  }
}
// ─── Eixos Fatores ────────────────────────────────────────────────────────────
export async function getFactoresByEixo(eixoId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eixosFatores).where(and(eq(eixosFatores.eixoId, eixoId), eq(eixosFatores.active, true))).orderBy(eixosFatores.name);
}
export async function getEixoFatorById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(eixosFatores).where(eq(eixosFatores.id, id)).limit(1);
  return result[0];
}

// ─── Social Mapping Sessions ──────────────────────────────────────────────────
export async function createSocialMappingSession(data: InsertSocialMappingSession) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(socialMappingSessions).values(data);
  return (result as any).insertId as number;
}
export async function getSocialMappingSessionsByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(socialMappingSessions).where(eq(socialMappingSessions.projectId, projectId)).orderBy(desc(socialMappingSessions.createdAt));
}
export async function getSocialMappingSessionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(socialMappingSessions).where(eq(socialMappingSessions.id, id)).limit(1);
  return result[0];
}
export async function updateSocialMappingSession(id: number, data: Partial<InsertSocialMappingSession>) {
  const db = await getDb();
  if (!db) return;
  await db.update(socialMappingSessions).set(data).where(eq(socialMappingSessions.id, id));
}

// ─── Social Mapping Entries ───────────────────────────────────────────────────
export async function createSocialMappingEntry(data: InsertSocialMappingEntry) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(socialMappingEntries).values(data);
  return (result as any).insertId as number;
}
export async function getSocialMappingEntriesBySession(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    entry: socialMappingEntries,
    eixoData: eixosTematicos,
    factor: eixosFatores,
  })
    .from(socialMappingEntries)
    .leftJoin(eixosTematicos, eq(socialMappingEntries.eixoId, eixosTematicos.id))
    .leftJoin(eixosFatores, eq(socialMappingEntries.factorId, eixosFatores.id))
    .where(eq(socialMappingEntries.sessionId, sessionId))
    .orderBy(socialMappingEntries.createdAt);
}
export async function getSocialMappingEntriesByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    entry: socialMappingEntries,
    eixoData: eixosTematicos,
    factor: eixosFatores,
  })
    .from(socialMappingEntries)
    .leftJoin(eixosTematicos, eq(socialMappingEntries.eixoId, eixosTematicos.id))
    .leftJoin(eixosFatores, eq(socialMappingEntries.factorId, eixosFatores.id))
    .where(eq(socialMappingEntries.projectId, projectId))
    .orderBy(desc(socialMappingEntries.createdAt));
}
export async function getSocialMappingEntryById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(socialMappingEntries).where(eq(socialMappingEntries.id, id)).limit(1);
  return rows[0] ?? null;
}
export async function updateSocialMappingEntry(id: number, data: Partial<InsertSocialMappingEntry>) {
  const db = await getDb();
  if (!db) return;
  await db.update(socialMappingEntries).set(data).where(eq(socialMappingEntries.id, id));
}
export async function deleteSocialMappingEntry(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(socialMappingEntries).where(eq(socialMappingEntries.id, id));
}

// ─── Cartografia Social - Helpers Adicionais ──────────────────────────────────

export async function closeSocialMappingSession(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(socialMappingSessions)
    .set({ status: "concluida", closedAt: new Date() })
    .where(eq(socialMappingSessions.id, id));
}

export async function getSessionSummary(sessionId: number) {
  const db = await getDb();
  if (!db) return null;
  const session = await getSocialMappingSessionById(sessionId);
  if (!session) return null;
  const entries = await getSocialMappingEntriesBySession(sessionId);
  const byRisk: Record<string, number> = { ameaca: 0, resiliencia: 0, vulnerabilidade: 0 };
  const byEixo: Record<number, { number: number; title: string; color: string; count: number }> = {};
  for (const { entry, eixoData } of entries) {
    byRisk[entry.riskClassification] = (byRisk[entry.riskClassification] ?? 0) + 1;
    if (eixoData) {
      if (!byEixo[eixoData.number]) {
        byEixo[eixoData.number] = { number: eixoData.number, title: eixoData.title, color: eixoData.color, count: 0 };
      }
      byEixo[eixoData.number].count += 1;
    }
  }
  return {
    session,
    totalEntries: entries.length,
    byRisk,
    byEixo: Object.values(byEixo).sort((a, b) => b.count - a.count),
    entries,
  };
}

export async function updateSocialMappingEntryNotes(id: number, entryNotes: string | null) {
  const db = await getDb();
  if (!db) return;
  await db.update(socialMappingEntries)
    .set({ entryNotes })
    .where(eq(socialMappingEntries.id, id));
}

export async function getSocialMappingEntriesForMap(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      entry: socialMappingEntries,
      eixoData: eixosTematicos,
      sessionData: socialMappingSessions,
    })
    .from(socialMappingEntries)
    .leftJoin(eixosTematicos, eq(socialMappingEntries.eixoId, eixosTematicos.id))
    .leftJoin(socialMappingSessions, eq(socialMappingEntries.sessionId, socialMappingSessions.id))
    .where(eq(socialMappingEntries.projectId, projectId))
    .orderBy(desc(socialMappingEntries.createdAt));
}

export async function updateSessionAnalysis(id: number, analysisText: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(socialMappingSessions)
    .set({ analysisText })
    .where(eq(socialMappingSessions.id, id));
}

export async function getSessionsByTerritoryForProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  const sessions = await db
    .select()
    .from(socialMappingSessions)
    .where(eq(socialMappingSessions.projectId, projectId))
    .orderBy(socialMappingSessions.territory, socialMappingSessions.sessionDate);
  // Agrupar por território
  const grouped: Record<string, typeof sessions> = {};
  for (const s of sessions) {
    if (!grouped[s.territory]) grouped[s.territory] = [];
    grouped[s.territory].push(s);
  }
  return Object.entries(grouped).map(([territory, items]) => ({ territory, sessions: items }));
}

export async function updateSessionAnalysisReview(id: number, analysisReview: string | null) {
  const db = await getDb();
  if (!db) return;
  await db.update(socialMappingSessions)
    .set({ analysisReview } as any)
    .where(eq(socialMappingSessions.id, id));
}

export async function getAllSessionSummariesForProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  const sessions = await db
    .select()
    .from(socialMappingSessions)
    .where(eq(socialMappingSessions.projectId, projectId))
    .orderBy(socialMappingSessions.sessionDate);
  const results = [];
  for (const session of sessions) {
    const summary = await getSessionSummary(session.id);
    if (summary) results.push(summary);
  }
  return results;
}

// ─── Entry Comments ────────────────────────────────────────────────────────────
export async function getEntryComments(entryId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(socialMappingEntryComments)
    .where(eq(socialMappingEntryComments.entryId, entryId))
    .orderBy(socialMappingEntryComments.createdAt);
}

export async function createEntryComment(data: InsertSocialMappingEntryComment) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(socialMappingEntryComments).values(data);
  const id = (result as any).insertId as number;
  const rows = await db.select().from(socialMappingEntryComments).where(eq(socialMappingEntryComments.id, id));
  return rows[0] ?? null;
}

export async function deleteEntryComment(id: number, authorId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(socialMappingEntryComments)
    .where(and(eq(socialMappingEntryComments.id, id), eq(socialMappingEntryComments.authorId, authorId)));
}

export async function getSessionEntriesWithComments(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  const entries = await db
    .select()
    .from(socialMappingEntries)
    .where(eq(socialMappingEntries.sessionId, sessionId))
    .orderBy(socialMappingEntries.createdAt);
  const withComments = await Promise.all(entries.map(async (entry) => {
    const comments = await getEntryComments(entry.id);
    return { ...entry, comments };
  }));
  return withComments;
}

export async function getSessionsTimelineForTerritory(projectId: number, territory: string) {
  const db = await getDb();
  if (!db) return [];
  const sessions = await db
    .select()
    .from(socialMappingSessions)
    .where(and(
      eq(socialMappingSessions.projectId, projectId),
      eq(socialMappingSessions.territory, territory)
    ))
    .orderBy(socialMappingSessions.sessionDate);
  const result = [];
  for (const session of sessions) {
    const entries = await db
      .select()
      .from(socialMappingEntries)
      .where(eq(socialMappingEntries.sessionId, session.id));
    const byRisk = { ameaca: 0, vulnerabilidade: 0, resiliencia: 0 };
    const byEixo: Record<number, number> = {};
    for (const e of entries) {
      byRisk[e.riskClassification]++;
      byEixo[e.eixoId] = (byEixo[e.eixoId] ?? 0) + 1;
    }
    result.push({ session, totalEntries: entries.length, byRisk, byEixo });
  }
  return result;
}
