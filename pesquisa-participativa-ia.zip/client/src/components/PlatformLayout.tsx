import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LayoutDashboard, FolderOpen, MapPin, Mic, Brain,
  BarChart3, FileText, Target, Bell, Users, LogOut,
  Leaf, Menu, X, ChevronRight, WifiOff, Map
} from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

const roleLabels: Record<string, string> = {
  pesquisador_popular: "Pesquisador Popular",
  facilitador: "Facilitador",
  gestor: "Gestor",
  admin: "Administrador",
};

const roleColors: Record<string, string> = {
  pesquisador_popular: "bg-blue-100 text-blue-800 border-blue-300",
  facilitador: "bg-amber-100 text-amber-800 border-amber-300",
  gestor: "bg-green-100 text-green-800 border-green-300",
  admin: "bg-purple-100 text-purple-800 border-purple-300",
};

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  roles?: string[];
  projectBased?: boolean;
}

const navItems: NavItem[] = [
  { href: "/dashboard", label: "Inicio", icon: LayoutDashboard },
  { href: "/projetos", label: "Projetos", icon: FolderOpen },
  { href: "/notificacoes", label: "Notificacoes", icon: Bell },
  { href: "/usuarios", label: "Gerenciar Usuarios", icon: Users, roles: ["gestor", "admin"] },
];

interface PlatformLayoutProps {
  children: React.ReactNode;
  projectId?: number;
  projectName?: string;
}

export default function PlatformLayout({ children, projectId, projectName }: PlatformLayoutProps) {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [location, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  const { data: unreadCount } = trpc.notifications.unreadCount.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 30000,
  });

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => { window.removeEventListener("online", handleOnline); window.removeEventListener("offline", handleOffline); };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
          <p className="text-muted-foreground font-medium text-lg">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-6 max-w-sm mx-auto px-4">
          <div className="w-20 h-20 rounded-2xl bg-primary flex items-center justify-center mx-auto">
            <Leaf className="w-10 h-10 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">PesquisaViva</h2>
            <p className="text-muted-foreground">Faca login para acessar a plataforma de pesquisa participativa.</p>
          </div>
          <a href={getLoginUrl()}>
            <Button size="lg" className="w-full text-base font-semibold py-6">
              Entrar na plataforma
            </Button>
          </a>
        </div>
      </div>
    );
  }

  const userRole = user?.role ?? "pesquisador_popular";

  const projectNavItems: NavItem[] = projectId ? [
    { href: `/projetos/${projectId}`, label: "Visao Geral", icon: FolderOpen, projectBased: true },
    { href: `/projetos/${projectId}/coleta`, label: "Coletar Dados", icon: MapPin, projectBased: true },
    { href: `/projetos/${projectId}/cartografia`, label: "Cartografia Social", icon: Map, projectBased: true },
    { href: `/projetos/${projectId}/transcricoes`, label: "Transcricoes", icon: Mic, projectBased: true },
    { href: `/projetos/${projectId}/analise`, label: "Analise com IA", icon: Brain, projectBased: true, roles: ["facilitador", "gestor", "admin"] },
    { href: `/projetos/${projectId}/monitoramento`, label: "Monitoramento", icon: BarChart3, projectBased: true },
    { href: `/projetos/${projectId}/dados-epidemiologicos`, label: "Dados Epidemiol.", icon: FileText, projectBased: true, roles: ["facilitador", "gestor", "admin"] },
    { href: `/projetos/${projectId}/incidencia`, label: "Incidencia Politica", icon: Target, projectBased: true, roles: ["facilitador", "gestor", "admin"] },
    { href: `/projetos/${projectId}/relatorio`, label: "Relatorio", icon: FileText, projectBased: true, roles: ["facilitador", "gestor", "admin"] },
  ] : [];

  const visibleProjectItems = projectNavItems.filter(item => !item.roles || item.roles.includes(userRole));
  const visibleNavItems = navItems.filter(item => !item.roles || item.roles.includes(userRole));

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-5 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
            <Leaf className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="min-w-0">
            <p className="font-bold text-sidebar-foreground text-base leading-tight">PesquisaViva</p>
            <p className="text-xs text-sidebar-foreground/60 truncate">Pesquisa Participativa</p>
          </div>
        </div>
      </div>

      {/* Nav principal */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {visibleNavItems.map((item) => {
          const isActive = location === item.href;
          return (
            <button
              key={item.href}
              onClick={() => { navigate(item.href); setSidebarOpen(false); }}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all text-base font-medium",
                isActive
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 truncate">{item.label}</span>
              {item.label === "Notificacoes" && (unreadCount ?? 0) > 0 && (
                <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                  {(unreadCount ?? 0) > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>
          );
        })}

        {/* Navegacao do projeto */}
        {projectId && visibleProjectItems.length > 0 && (
          <div className="mt-4">
            <div className="px-3 py-2 flex items-center gap-2">
              <div className="h-px flex-1 bg-sidebar-border" />
              <p className="text-xs text-sidebar-foreground/50 font-medium uppercase tracking-wider whitespace-nowrap">
                {projectName ? projectName.substring(0, 20) : "Projeto"}
              </p>
              <div className="h-px flex-1 bg-sidebar-border" />
            </div>
            {visibleProjectItems.map((item) => {
              const isActive = location === item.href;
              return (
                <button
                  key={item.href}
                  onClick={() => { navigate(item.href); setSidebarOpen(false); }}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all text-sm font-medium mt-1",
                    isActive
                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  <span className="flex-1 truncate">{item.label}</span>
                  {isActive && <ChevronRight className="w-3 h-3 flex-shrink-0" />}
                </button>
              );
            })}
          </div>
        )}
      </nav>

      {/* Perfil do usuario */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-sidebar-accent flex items-center justify-center flex-shrink-0">
            <span className="text-sidebar-accent-foreground font-bold text-base">
              {(user?.name ?? "U").charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sidebar-foreground font-semibold text-sm truncate">{user?.name ?? "Usuario"}</p>
            <span className={cn("text-xs px-2 py-0.5 rounded-full border font-medium", roleColors[userRole])}>
              {roleLabels[userRole] ?? userRole}
            </span>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={logout}
          className="w-full gap-2 text-sidebar-foreground border-sidebar-border hover:bg-sidebar-accent text-sm"
        >
          <LogOut className="w-4 h-4" />
          Sair
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-sidebar border-r border-sidebar-border fixed inset-y-0 left-0 z-40">
        <SidebarContent />
      </aside>

      {/* Sidebar mobile overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="relative flex flex-col w-72 bg-sidebar h-full">
            <button
              onClick={() => setSidebarOpen(false)}
              className="absolute top-4 right-4 text-sidebar-foreground/60 hover:text-sidebar-foreground"
            >
              <X className="w-6 h-6" />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Conteudo principal */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Banner offline */}
        {isOffline && (
          <div className="bg-amber-100 border-b border-amber-300 text-amber-800 text-sm font-medium px-4 py-2 flex items-center gap-2">
            <WifiOff className="w-4 h-4 flex-shrink-0" />
            <span>Voce esta sem conexao. Os dados coletados serao sincronizados automaticamente ao reconectar.</span>
          </div>
        )}

        {/* Header mobile */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-white border-b border-border sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-muted">
            <Menu className="w-6 h-6 text-foreground" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <Leaf className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-bold text-foreground">PesquisaViva</span>
          </div>
          <button onClick={() => navigate("/notificacoes")} className="relative p-2 rounded-lg hover:bg-muted">
            <Bell className="w-5 h-5 text-foreground" />
            {(unreadCount ?? 0) > 0 && (
              <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                {(unreadCount ?? 0) > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>
        </header>

        {/* Conteudo da pagina */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
