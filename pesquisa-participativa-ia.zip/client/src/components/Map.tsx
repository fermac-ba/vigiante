/**
 * GOOGLE MAPS FRONTEND INTEGRATION
 * Versão robusta com tratamento de falha de carregamento, fallback visual e suporte a múltiplas instâncias.
 */
/// <reference types="@types/google.maps" />
import { useEffect, useRef, useState } from "react";
import { usePersistFn } from "@/hooks/usePersistFn";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    google?: typeof google;
    __mapsScriptState?: "loading" | "ready" | "error";
    __mapsScriptCallbacks?: Array<(ok: boolean) => void>;
  }
}

const API_KEY = import.meta.env.VITE_FRONTEND_FORGE_API_KEY;
const FORGE_BASE_URL =
  import.meta.env.VITE_FRONTEND_FORGE_API_URL ||
  "https://forge.butterfly-effect.dev";
const MAPS_PROXY_URL = `${FORGE_BASE_URL}/v1/maps/proxy`;
const SCRIPT_TIMEOUT_MS = 15000;

function loadMapScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.__mapsScriptState === "ready" && window.google?.maps) {
      resolve(true);
      return;
    }
    if (window.__mapsScriptState === "error") {
      resolve(false);
      return;
    }
    if (window.__mapsScriptState === "loading") {
      window.__mapsScriptCallbacks = window.__mapsScriptCallbacks ?? [];
      window.__mapsScriptCallbacks.push(resolve);
      return;
    }

    window.__mapsScriptState = "loading";
    window.__mapsScriptCallbacks = [resolve];

    const notify = (ok: boolean) => {
      window.__mapsScriptState = ok ? "ready" : "error";
      const cbs = window.__mapsScriptCallbacks ?? [];
      window.__mapsScriptCallbacks = [];
      cbs.forEach(cb => cb(ok));
    };

    const timer = setTimeout(() => {
      console.error("[Maps] Timeout ao carregar script do Google Maps");
      notify(false);
    }, SCRIPT_TIMEOUT_MS);

    const script = document.createElement("script");
    script.src = `${MAPS_PROXY_URL}/maps/api/js?key=${API_KEY}&v=weekly&libraries=marker,places,geocoding,geometry`;
    script.async = true;
    script.crossOrigin = "anonymous";
    script.onload = () => {
      clearTimeout(timer);
      notify(true);
    };
    script.onerror = () => {
      clearTimeout(timer);
      console.error("[Maps] Falha ao carregar script do Google Maps");
      notify(false);
    };
    document.head.appendChild(script);
  });
}

interface MapViewProps {
  className?: string;
  initialCenter?: google.maps.LatLngLiteral;
  initialZoom?: number;
  onMapReady?: (map: google.maps.Map) => void;
  onMapError?: (msg: string) => void;
}

export function MapView({
  className,
  initialCenter = { lat: -15.7801, lng: -47.9292 },
  initialZoom = 12,
  onMapReady,
  onMapError,
}: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<google.maps.Map | null>(null);
  const [mapState, setMapState] = useState<"loading" | "ready" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [retryKey, setRetryKey] = useState(0);

  const init = usePersistFn(async () => {
    setMapState("loading");
    setErrorMsg("");

    const ok = await loadMapScript();
    if (!ok) {
      const msg = "Nao foi possivel carregar o mapa. Verifique sua conexao e tente novamente.";
      setMapState("error");
      setErrorMsg(msg);
      onMapError?.(msg);
      return;
    }

    if (!mapContainer.current) {
      const msg = "Container do mapa nao encontrado.";
      setMapState("error");
      setErrorMsg(msg);
      onMapError?.(msg);
      return;
    }

    try {
      map.current = new window.google!.maps.Map(mapContainer.current, {
        zoom: initialZoom,
        center: initialCenter,
        mapTypeControl: true,
        fullscreenControl: true,
        zoomControl: true,
        streetViewControl: false,
        mapId: "DEMO_MAP_ID",
      });
      setMapState("ready");
      if (onMapReady) {
        onMapReady(map.current);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao inicializar o mapa.";
      console.error("[Maps] Erro ao inicializar:", msg);
      setMapState("error");
      setErrorMsg(msg);
      onMapError?.(msg);
    }
  });

  useEffect(() => {
    init();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [retryKey]);

  const handleRetry = () => {
    if (window.__mapsScriptState === "error") {
      window.__mapsScriptState = undefined as any;
      document.querySelectorAll("script[src*='maps/api/js']").forEach(s => s.remove());
    }
    setRetryKey(k => k + 1);
  };

  return (
    <div className={cn("relative w-full h-[500px]", className)}>
      <div
        ref={mapContainer}
        className="w-full h-full"
        style={{ display: mapState === "error" ? "none" : "block" }}
      />
      {mapState === "loading" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/60 rounded-xl gap-3">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground font-medium">Carregando mapa...</p>
        </div>
      )}
      {mapState === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/80 rounded-xl gap-3 p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
            <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <div>
            <p className="font-semibold text-foreground text-sm">Mapa indisponivel</p>
            <p className="text-xs text-muted-foreground mt-1">{errorMsg}</p>
          </div>
          <button
            onClick={handleRetry}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            Tentar novamente
          </button>
          <p className="text-xs text-muted-foreground">
            Voce ainda pode registrar o fator sem georreferenciamento.
          </p>
        </div>
      )}
    </div>
  );
}
