import PlatformLayout from "@/components/PlatformLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useLocation } from "wouter";
import { useState } from "react";
import { Plus, MapPin, Clock, FolderOpen, ArrowRight } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

const statusColors: Record<string, string> = {
  ativo: "bg-green-100 text-green-800 border-green-300",
  pausado: "bg-amber-100 text-amber-800 border-amber-300",
  concluido: "bg-gray-100 text-gray-600 border-gray-300",
};
const statusLabels: Record<string, string> = { ativo: "Ativo", pausado: "Pausado", concluido: "Concluido" };

export default function Projects() {
  const notify = useNotification();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [territory, setTerritory] = useState("");
  const utils = trpc.useUtils();
  const { data: projects, isLoading } = trpc.projects.list.useQuery();
  const createProject = trpc.projects.create.useMutation({
    onSuccess: () => { utils.projects.list.invalidate(); setOpen(false); setTitle(""); setDescription(""); setTerritory(""); notify.success("Projeto criado com sucesso!"); },
    onError: () => notify.error("Erro ao criar projeto."),
  });
  const userRole = user?.role ?? "pesquisador_popular";
  const canCreate = ["facilitador","gestor","admin"].includes(userRole);

  return (
    <PlatformLayout>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Projetos de Pesquisa</h1>
            <p className="text-muted-foreground mt-1">Gerencie e acesse seus projetos de investigacao participativa.</p>
          </div>
          {canCreate && (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2"><Plus className="w-4 h-4" />Novo Projeto</Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader><DialogTitle className="text-xl">Criar novo projeto</DialogTitle></DialogHeader>
                <div className="space-y-4 pt-2">
                  <div><Label className="text-base font-semibold">Nome do projeto *</Label><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Saude Mental na Comunidade" className="mt-1 text-base" /></div>
                  <div><Label className="text-base font-semibold">Territorio</Label><Input value={territory} onChange={e => setTerritory(e.target.value)} placeholder="Ex: Bairro Sol Nascente, Brasilia" className="mt-1 text-base" /></div>
                  <div><Label className="text-base font-semibold">Descricao</Label><Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Descreva o objetivo do projeto..." className="mt-1 text-base" rows={3} /></div>
                  <Button className="w-full text-base py-5" disabled={!title || createProject.isPending} onClick={() => createProject.mutate({ title, description, territory })}>
                    {createProject.isPending ? "Criando..." : "Criar projeto"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{[1,2,3].map(i => <div key={i} className="h-40 bg-muted rounded-2xl animate-pulse" />)}</div>
        ) : !projects?.length ? (
          <Card className="border-2 border-dashed border-border">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4"><FolderOpen className="w-10 h-10 text-muted-foreground" /></div>
              <p className="text-xl font-semibold text-foreground mb-2">Nenhum projeto encontrado</p>
              <p className="text-muted-foreground mb-6">Inicie seu primeiro projeto de pesquisa participativa em saude comunitaria.</p>
              {canCreate && <Button onClick={() => setOpen(true)} className="gap-2 text-base px-6 py-5"><Plus className="w-5 h-5" />Criar primeiro projeto</Button>}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {projects.map(project => (
              <button key={project.id} onClick={() => navigate(`/projetos/${project.id}`)} className="text-left p-6 bg-white border-2 border-border rounded-2xl hover:border-primary hover:shadow-md transition-all group">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <h3 className="font-bold text-foreground text-lg leading-tight group-hover:text-primary transition-colors">{project.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full border font-medium flex-shrink-0 ${statusColors[project.status]}`}>{statusLabels[project.status]}</span>
                </div>
                {project.territory && <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2"><MapPin className="w-4 h-4" /><span>{project.territory}</span></div>}
                {project.description && <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{project.description}</p>}
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground"><Clock className="w-3 h-3" /><span>{new Date(project.createdAt).toLocaleDateString("pt-BR")}</span></div>
                  <span className="text-xs text-primary font-medium flex items-center gap-1">Acessar <ArrowRight className="w-3 h-3" /></span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </PlatformLayout>
  );
}
