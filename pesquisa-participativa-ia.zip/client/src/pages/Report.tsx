import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useParams } from "wouter";
import { useState } from "react";
import { FileText, Download, BarChart3, MapPin, Brain, Database, Target, Loader2, CheckCircle2 } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

type ReportData = {
  project: { id: number; title: string; description: string | null; territory: string | null; status: string; createdAt: Date } | undefined;
  summary: {
    totalEntries: number;
    totalCycles: number;
    totalIndicators: number;
    totalAnalyses: number;
    totalEpidData: number;
    topThematicCodes: Array<[string, number]>;
  };
  cycles: Array<{ id: number; title: string; status: string; startDate: Date | null; endDate: Date | null }>;
  indicators: Array<{ id: number; name: string; indicatorType: string; currentValue: number | null; targetValue: number | null; unit: string | null }>;
  narratives: Array<{ text: string | null; location: string | null; date: Date }>;
  generatedAt: Date;
};

function exportToPDF(report: ReportData) {
  const content = `
RELATÓRIO DE DIAGNÓSTICO SITUACIONAL INTEGRADO
Plataforma PesquisaViva - Pesquisa Participativa em Saúde Comunitária

Projeto: ${report.project?.title ?? "Sem título"}
Território: ${report.project?.territory ?? "Não informado"}
Status: ${report.project?.status ?? ""}
Gerado em: ${new Date(report.generatedAt).toLocaleDateString("pt-BR")} às ${new Date(report.generatedAt).toLocaleTimeString("pt-BR")}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RESUMO EXECUTIVO
${report.project?.description ?? "Sem descrição disponível."}

INDICADORES GERAIS
- Total de coletas em campo: ${report.summary.totalEntries}
- Ciclos de pesquisa: ${report.summary.totalCycles}
- Indicadores de monitoramento: ${report.summary.totalIndicators}
- Análises realizadas com IA: ${report.summary.totalAnalyses}
- Registros epidemiológicos importados: ${report.summary.totalEpidData}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PRINCIPAIS CÓDIGOS TEMÁTICOS IDENTIFICADOS
${report.summary.topThematicCodes.map(([code, freq], i) => `${i + 1}. ${code} (${freq} ocorrência${freq > 1 ? "s" : ""})`).join("\n") || "Nenhuma análise realizada ainda."}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CICLOS DE PESQUISA
${report.cycles.map(c => `- ${c.title} [${c.status}]${c.startDate ? ` | Início: ${new Date(c.startDate).toLocaleDateString("pt-BR")}` : ""}`).join("\n") || "Nenhum ciclo registrado."}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INDICADORES DE MONITORAMENTO
${report.indicators.map(ind => `- ${ind.name} [${ind.indicatorType}]: ${ind.currentValue ?? 0}${ind.unit ? " " + ind.unit : ""}${ind.targetValue ? " / Meta: " + ind.targetValue : ""}`).join("\n") || "Nenhum indicador registrado."}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

NARRATIVAS COLETADAS (primeiras ${Math.min(report.narratives.length, 20)})
${report.narratives.slice(0, 20).map((n, i) => `[${i + 1}] ${n.location ? `(${n.location}) ` : ""}${n.text ?? ""}`).join("\n\n") || "Nenhuma narrativa registrada."}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Documento gerado pela Plataforma PesquisaViva
Pesquisa Participativa em Saúde Comunitária
  `.trim();

  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `relatorio_${report.project?.title?.replace(/\s+/g, "_") ?? "projeto"}_${new Date().toISOString().split("T")[0]}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function Report() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [report, setReport] = useState<ReportData | null>(null);
  const { data: project } = trpc.projects.getById.useQuery({ id: projectId });

  const generateReport = trpc.projects.generateReport.useMutation({
    onSuccess: (data) => {
      setReport(data as ReportData);
      notify.success("Relatorio gerado com sucesso!");
    },
    onError: () => notify.error("Erro ao gerar relatorio."),
  });

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Relatorio de Diagnostico Situacional</h1>
            <p className="text-muted-foreground mt-1">Gere um relatorio integrado com dados coletados, analises de IA, indicadores e narrativas do territorio.</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => generateReport.mutate({ projectId })} disabled={generateReport.isPending} className="gap-2">
              {generateReport.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              {generateReport.isPending ? "Gerando..." : "Gerar relatorio"}
            </Button>
            {report && (
              <Button variant="outline" onClick={() => exportToPDF(report)} className="gap-2 border-2">
                <Download className="w-4 h-4" />Exportar
              </Button>
            )}
          </div>
        </div>

        {!report && !generateReport.isPending && (
          <Card className="border-2 border-dashed border-border">
            <CardContent className="p-12 text-center">
              <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="font-semibold text-foreground text-lg">Nenhum relatorio gerado</p>
              <p className="text-muted-foreground mt-2 max-w-md mx-auto">Clique em "Gerar relatorio" para criar um diagnostico situacional integrado com todos os dados do projeto.</p>
              <Button onClick={() => generateReport.mutate({ projectId })} className="mt-6 gap-2">
                <FileText className="w-4 h-4" />Gerar relatorio agora
              </Button>
            </CardContent>
          </Card>
        )}

        {generateReport.isPending && (
          <Card className="border-2 border-green-200 bg-green-50">
            <CardContent className="p-8 text-center">
              <Loader2 className="w-10 h-10 text-green-600 mx-auto mb-3 animate-spin" />
              <p className="font-semibold text-green-900">Gerando relatorio...</p>
              <p className="text-sm text-green-700 mt-1">Consolidando dados coletados, analises de IA e indicadores.</p>
            </CardContent>
          </Card>
        )}

        {report && (
          <div className="space-y-6">
            {/* Cabeçalho do relatório */}
            <Card className="border-2 border-green-200 bg-green-50">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-3">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-bold text-green-900 text-lg">{report.project?.title}</p>
                    <p className="text-xs text-green-700">Relatorio gerado em {new Date(report.generatedAt).toLocaleDateString("pt-BR")} às {new Date(report.generatedAt).toLocaleTimeString("pt-BR")}</p>
                  </div>
                </div>
                {report.project?.description && <p className="text-sm text-green-800">{report.project.description}</p>}
                {report.project?.territory && <p className="text-xs text-green-700 mt-1">Territorio: {report.project.territory}</p>}
              </CardContent>
            </Card>

            {/* Indicadores gerais */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {[
                { label: "Coletas", value: report.summary.totalEntries, icon: MapPin, color: "green" },
                { label: "Ciclos", value: report.summary.totalCycles, icon: Target, color: "blue" },
                { label: "Indicadores", value: report.summary.totalIndicators, icon: BarChart3, color: "purple" },
                { label: "Analises IA", value: report.summary.totalAnalyses, icon: Brain, color: "rose" },
                { label: "Dados Epidem.", value: report.summary.totalEpidData, icon: Database, color: "amber" },
              ].map((s, i) => (
                <Card key={i} className={`border-2 border-${s.color}-200 bg-${s.color}-50/50`}>
                  <CardContent className="p-3 text-center">
                    <s.icon className={`w-5 h-5 text-${s.color}-600 mx-auto mb-1`} />
                    <p className={`text-2xl font-bold text-${s.color}-900`}>{s.value}</p>
                    <p className={`text-xs text-${s.color}-700`}>{s.label}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Códigos temáticos */}
            {report.summary.topThematicCodes.length > 0 && (
              <Card className="border-2 border-border">
                <CardHeader><CardTitle className="flex items-center gap-2"><Brain className="w-5 h-5 text-purple-600" />Principais Codigos Tematicos Identificados</CardTitle></CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {report.summary.topThematicCodes.map(([code, freq], i) => (
                      <Badge key={i} className="bg-purple-100 text-purple-800 border-purple-300 border text-sm px-3 py-1">
                        {code} <span className="ml-1 text-purple-600 font-normal">({freq}x)</span>
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Ciclos */}
            {report.cycles.length > 0 && (
              <Card className="border-2 border-border">
                <CardHeader><CardTitle className="flex items-center gap-2"><Target className="w-5 h-5 text-blue-600" />Ciclos de Pesquisa</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  {report.cycles.map(c => (
                    <div key={c.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-xl">
                      <p className="font-medium text-foreground">{c.title}</p>
                      <div className="flex items-center gap-2">
                        {c.startDate && <span className="text-xs text-muted-foreground">{new Date(c.startDate).toLocaleDateString("pt-BR")}</span>}
                        <Badge variant="outline" className="text-xs">{c.status}</Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Indicadores */}
            {report.indicators.length > 0 && (
              <Card className="border-2 border-border">
                <CardHeader><CardTitle className="flex items-center gap-2"><BarChart3 className="w-5 h-5 text-green-600" />Indicadores de Monitoramento</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  {report.indicators.map(ind => {
                    const progress = ind.targetValue && ind.currentValue ? Math.round((ind.currentValue / ind.targetValue) * 100) : null;
                    return (
                      <div key={ind.id} className="p-3 bg-muted/50 rounded-xl">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-medium text-foreground text-sm">{ind.name}</p>
                          <Badge variant="outline" className="text-xs">{ind.indicatorType}</Badge>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-lg font-bold text-foreground">{ind.currentValue ?? 0} {ind.unit ?? ""}</span>
                          {ind.targetValue && <><div className="flex-1 bg-muted rounded-full h-1.5"><div className="bg-primary rounded-full h-1.5" style={{ width: Math.min(progress ?? 0, 100) + "%" }} /></div><span className="text-xs text-muted-foreground">{progress}%</span></>}
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            )}

            {/* Narrativas */}
            {report.narratives.length > 0 && (
              <Card className="border-2 border-border">
                <CardHeader><CardTitle className="flex items-center gap-2"><MapPin className="w-5 h-5 text-teal-600" />Narrativas Coletadas ({report.narratives.length})</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {report.narratives.slice(0, 10).map((n, i) => (
                    <div key={i} className="p-3 bg-muted/50 rounded-xl border-l-4 border-l-teal-400">
                      {n.location && <p className="text-xs font-medium text-teal-700 mb-1">{n.location}</p>}
                      <p className="text-sm text-foreground">{n.text}</p>
                      <p className="text-xs text-muted-foreground mt-1">{new Date(n.date).toLocaleDateString("pt-BR")}</p>
                    </div>
                  ))}
                  {report.narratives.length > 10 && (
                    <p className="text-sm text-muted-foreground text-center">... e mais {report.narratives.length - 10} narrativas. Exporte o relatorio para visualizar todas.</p>
                  )}
                </CardContent>
              </Card>
            )}

            <div className="flex justify-center pt-2">
              <Button onClick={() => exportToPDF(report)} className="gap-2 py-6 px-8 text-base">
                <Download className="w-5 h-5" />Exportar relatorio completo
              </Button>
            </div>
          </div>
        )}
      </div>
    </PlatformLayout>
  );
}
