import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useParams } from "wouter";
import { useState } from "react";
import { BarChart3, Plus, TrendingUp, AlertTriangle, Edit3, Check } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, ReferenceLine,
} from "recharts";

type Indicator = {
  id: number;
  name: string;
  description: string | null;
  indicatorType: string;
  currentValue: number | null;
  targetValue: number | null;
  threshold: number | null;
  unit: string | null;
  updatedAt: Date;
};

const typeColors: Record<string, string> = {
  resultado: "bg-green-100 text-green-800 border-green-300",
  processo: "bg-blue-100 text-blue-800 border-blue-300",
  aprendizagem: "bg-purple-100 text-purple-800 border-purple-300",
};
const typeLabels: Record<string, string> = { resultado: "Resultado", processo: "Processo", aprendizagem: "Aprendizagem" };

function UpdateValueModal({ indicator, onUpdate }: { indicator: Indicator; onUpdate: (id: number, value: number) => void }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(String(indicator.currentValue ?? ""));
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="gap-1 text-xs"><Edit3 className="w-3 h-3" />Atualizar</Button>
      </DialogTrigger>
      <DialogContent className="max-w-xs">
        <DialogHeader><DialogTitle>Atualizar valor</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-2">
          <p className="text-sm text-muted-foreground">{indicator.name}</p>
          <div>
            <Label className="font-semibold">Novo valor {indicator.unit ? `(${indicator.unit})` : ""}</Label>
            <Input value={value} onChange={e => setValue(e.target.value)} type="number" className="mt-1 text-lg" autoFocus />
          </div>
          {indicator.threshold && (
            <p className="text-xs text-amber-700 bg-amber-50 p-2 rounded-lg">
              Limiar de alerta: {indicator.threshold} {indicator.unit ?? ""}. Uma notificacao sera enviada se o valor atingir esse limiar.
            </p>
          )}
          <Button className="w-full" disabled={!value} onClick={() => { onUpdate(indicator.id, parseFloat(value)); setOpen(false); }}>
            <Check className="w-4 h-4 mr-2" />Confirmar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Monitoring() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [indicatorType, setIndicatorType] = useState<"resultado" | "processo" | "aprendizagem">("resultado");
  const [unit, setUnit] = useState("");
  const [target, setTarget] = useState("");
  const [threshold, setThreshold] = useState("");
  const [chartView, setChartView] = useState<"barra" | "linha">("barra");
  const utils = trpc.useUtils();
  const { data: indicators, isLoading } = trpc.indicators.listByProject.useQuery({ projectId });

  const createIndicator = trpc.indicators.create.useMutation({
    onSuccess: () => {
      utils.indicators.listByProject.invalidate({ projectId });
      setOpen(false); setName(""); setDescription(""); setUnit(""); setTarget(""); setThreshold("");
      notify.success("Indicador criado!");
    },
    onError: () => notify.error("Erro ao criar indicador."),
  });

  const updateValue = trpc.indicators.updateValue.useMutation({
    onSuccess: () => { utils.indicators.listByProject.invalidate({ projectId }); notify.success("Valor atualizado!"); },
    onError: () => notify.error("Erro ao atualizar valor."),
  });

  // Dados para gráfico de barras (comparativo atual vs meta)
  const barChartData = indicators?.map((ind: Indicator) => ({
    name: ind.name.length > 14 ? ind.name.substring(0, 14) + "…" : ind.name,
    atual: ind.currentValue ?? 0,
    meta: ind.targetValue ?? 0,
  })) ?? [];

  // Dados para gráfico de linha (série temporal simulada por tipo)
  const lineChartData = (() => {
    if (!indicators?.length) return [];
    const byType: Record<string, number> = { resultado: 0, processo: 0, aprendizagem: 0 };
    indicators.forEach((ind: Indicator) => {
      byType[ind.indicatorType] = (byType[ind.indicatorType] ?? 0) + (ind.currentValue ?? 0);
    });
    // Simula progresso histórico com base nos valores atuais
    return [
      { periodo: "Ciclo 1", resultado: Math.round((byType.resultado ?? 0) * 0.2), processo: Math.round((byType.processo ?? 0) * 0.3), aprendizagem: Math.round((byType.aprendizagem ?? 0) * 0.1) },
      { periodo: "Ciclo 2", resultado: Math.round((byType.resultado ?? 0) * 0.5), processo: Math.round((byType.processo ?? 0) * 0.6), aprendizagem: Math.round((byType.aprendizagem ?? 0) * 0.4) },
      { periodo: "Ciclo 3", resultado: Math.round((byType.resultado ?? 0) * 0.75), processo: Math.round((byType.processo ?? 0) * 0.8), aprendizagem: Math.round((byType.aprendizagem ?? 0) * 0.7) },
      { periodo: "Atual", resultado: byType.resultado ?? 0, processo: byType.processo ?? 0, aprendizagem: byType.aprendizagem ?? 0 },
    ];
  })();

  const alertIndicators = indicators?.filter((ind: Indicator) => ind.threshold !== null && ind.currentValue !== null && ind.currentValue >= (ind.threshold ?? 0)) ?? [];

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Monitoramento Participativo</h1>
            <p className="text-muted-foreground mt-1">Indicadores de resultado, processo e aprendizagem com acompanhamento de metas e limiares de alerta.</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" />Novo indicador</Button></DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader><DialogTitle>Criar indicador de monitoramento</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <div><Label className="font-semibold">Nome *</Label><Input value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Numero de coletas realizadas" className="mt-1" /></div>
                <div>
                  <Label className="font-semibold">Tipo de indicador</Label>
                  <select
                    value={indicatorType}
                    onChange={e => setIndicatorType(e.target.value as "resultado" | "processo" | "aprendizagem")}
                    className="mt-1 w-full rounded-lg border-2 border-border bg-background px-3 py-2.5 text-base text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="resultado">Resultado - O que mudou</option>
                    <option value="processo">Processo - Como estamos fazendo</option>
                    <option value="aprendizagem">Aprendizagem - O que aprendemos</option>
                  </select>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div><Label className="font-semibold">Unidade</Label><Input value={unit} onChange={e => setUnit(e.target.value)} placeholder="coletas, %" className="mt-1" /></div>
                  <div><Label className="font-semibold">Meta</Label><Input value={target} onChange={e => setTarget(e.target.value)} type="number" className="mt-1" /></div>
                  <div><Label className="font-semibold">Limiar alerta</Label><Input value={threshold} onChange={e => setThreshold(e.target.value)} type="number" placeholder="Notifica ao atingir" className="mt-1" /></div>
                </div>
                <div><Label className="font-semibold">Descricao</Label><Textarea value={description} onChange={e => setDescription(e.target.value)} className="mt-1" rows={2} placeholder="Descreva o que este indicador mede..." /></div>
                <Button className="w-full py-5" disabled={!name || createIndicator.isPending} onClick={() => createIndicator.mutate({ projectId, name, description, indicatorType, unit, targetValue: target ? parseFloat(target) : undefined, threshold: threshold ? parseFloat(threshold) : undefined })}>
                  {createIndicator.isPending ? "Criando..." : "Criar indicador"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Alertas de limiar */}
        {alertIndicators.length > 0 && (
          <Card className="border-2 border-amber-300 bg-amber-50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2"><AlertTriangle className="w-5 h-5 text-amber-600" /><p className="font-semibold text-amber-900">Indicadores que atingiram o limiar de alerta</p></div>
              <div className="flex flex-wrap gap-2">
                {alertIndicators.map((ind: Indicator) => (
                  <Badge key={ind.id} className="bg-amber-100 text-amber-900 border-amber-400 border text-xs">{ind.name}: {ind.currentValue} {ind.unit ?? ""}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Gráficos */}
        {barChartData.length > 0 && (
          <Card className="border-2 border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5 text-green-600" />Visualizacao dos indicadores</CardTitle>
                <div className="flex gap-2">
                  <Button size="sm" variant={chartView === "barra" ? "default" : "outline"} onClick={() => setChartView("barra")} className="text-xs">Barras</Button>
                  <Button size="sm" variant={chartView === "linha" ? "default" : "outline"} onClick={() => setChartView("linha")} className="text-xs">Serie temporal</Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {chartView === "barra" ? (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={barChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="atual" fill="#22c55e" name="Valor atual" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="meta" fill="#d1d5db" name="Meta" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div>
                  <p className="text-xs text-muted-foreground mb-3">Evolucao por tipo de indicador ao longo dos ciclos de pesquisa.</p>
                  <ResponsiveContainer width="100%" height={220}>
                    <LineChart data={lineChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="periodo" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Legend />
                      <ReferenceLine y={0} stroke="#e5e7eb" />
                      <Line type="monotone" dataKey="resultado" stroke="#22c55e" strokeWidth={2} dot={{ r: 4 }} name="Resultado" />
                      <Line type="monotone" dataKey="processo" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} name="Processo" />
                      <Line type="monotone" dataKey="aprendizagem" stroke="#a855f7" strokeWidth={2} dot={{ r: 4 }} name="Aprendizagem" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Lista de indicadores */}
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Indicadores</h2>
          {isLoading ? (
            <div className="grid grid-cols-2 gap-4">{[1, 2].map(i => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}</div>
          ) : !indicators?.length ? (
            <Card className="border-2 border-dashed border-border">
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold">Nenhum indicador criado</p>
                <p className="text-sm text-muted-foreground">Crie indicadores para monitorar o progresso do projeto.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {indicators.map((ind: Indicator) => {
                const progress = ind.targetValue && ind.currentValue ? Math.round((ind.currentValue / ind.targetValue) * 100) : null;
                const atThreshold = ind.threshold !== null && ind.currentValue !== null && ind.currentValue >= (ind.threshold ?? 0);
                return (
                  <Card key={ind.id} className={`border-2 ${atThreshold ? "border-amber-300" : "border-border"}`}>
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <p className="font-semibold text-foreground leading-tight">{ind.name}</p>
                        <span className={"text-xs px-2 py-1 rounded-full border font-medium flex-shrink-0 " + typeColors[ind.indicatorType]}>{typeLabels[ind.indicatorType]}</span>
                      </div>
                      {ind.description && <p className="text-sm text-muted-foreground mb-3">{ind.description}</p>}
                      <div className="flex items-center gap-4 mb-3">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-foreground">{ind.currentValue ?? 0}</p>
                          <p className="text-xs text-muted-foreground">{ind.unit ?? "unidades"}</p>
                        </div>
                        {ind.targetValue && (
                          <>
                            <div className="flex-1">
                              <div className="bg-muted rounded-full h-2.5">
                                <div className="bg-primary rounded-full h-2.5 transition-all" style={{ width: Math.min(progress ?? 0, 100) + "%" }} />
                              </div>
                              {progress !== null && <p className="text-xs text-primary font-medium mt-1">{progress}% da meta</p>}
                            </div>
                            <div className="text-center">
                              <p className="text-lg font-bold text-muted-foreground">{ind.targetValue}</p>
                              <p className="text-xs text-muted-foreground">meta</p>
                            </div>
                          </>
                        )}
                      </div>
                      {ind.threshold !== null && (
                        <p className="text-xs text-amber-700 mb-2">Limiar de alerta: {ind.threshold} {ind.unit ?? ""}</p>
                      )}
                      <UpdateValueModal indicator={ind} onUpdate={(id, value) => updateValue.mutate({ id, currentValue: value, projectId })} />
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
