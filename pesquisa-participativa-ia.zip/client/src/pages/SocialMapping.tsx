import { useState } from "react";
import { useParams, useLocation } from "wouter";
import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useNotification } from "@/contexts/NotificationContext";
import {
  Map, Plus, Users, Calendar, CheckCircle2, Clock,
  ChevronRight, Globe, AlertTriangle, Shield, TrendingUp, Layers, GitBranch
} from "lucide-react";

const riskColors: Record<string, { bg: string; text: string; icon: React.ElementType; label: string }> = {
  ameaca: { bg: "bg-red-100", text: "text-red-800", icon: AlertTriangle, label: "Ameaca" },
  vulnerabilidade: { bg: "bg-amber-100", text: "text-amber-800", icon: Shield, label: "Vulnerabilidade" },
  resiliencia: { bg: "bg-green-100", text: "text-green-800", icon: TrendingUp, label: "Resiliencia" },
};

export default function SocialMapping() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [, navigate] = useLocation();
  const [createOpen, setCreateOpen] = useState(false);
  const today = new Date().toISOString().split("T")[0];
  const [form, setForm] = useState({ territory: "", monitorName: "", participants: "", notes: "", sessionDate: today });

  const { data: project } = trpc.projects.getById.useQuery({ id: projectId }, { enabled: !!projectId });
  const { data: sessions, refetch } = trpc.socialMapping.listSessions.useQuery({ projectId }, { enabled: !!projectId });
  const { data: allEntries } = trpc.socialMapping.listEntriesByProject.useQuery({ projectId }, { enabled: !!projectId });

  const createSession = trpc.socialMapping.createSession.useMutation({
    onSuccess: (data) => {
      notify.success("Sessao de cartografia criada!");
      setCreateOpen(false);
      setForm({ territory: "", monitorName: "", participants: "", notes: "", sessionDate: today });
      refetch();
      navigate(`/projetos/${projectId}/cartografia/${data.id}`);
    },
    onError: () => notify.error("Erro ao criar sessao."),
  });

  const handleCreate = () => {
    if (!form.territory.trim() || !form.monitorName.trim()) {
      notify.error("Preencha o territorio e o nome do monitor.");
      return;
    }
    createSession.mutate({
      projectId,
      territory: form.territory,
      monitorName: form.monitorName,
      participants: form.participants ? parseInt(form.participants) : undefined,
      notes: form.notes || undefined,
      sessionDate: form.sessionDate || undefined,
    });
  };

  // Contagens por tipo de risco
  const riskCounts = (allEntries ?? []).reduce((acc, e) => {
    const r = e.entry.riskClassification;
    acc[r] = (acc[r] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Eixos mais frequentes
  const eixoCounts = (allEntries ?? []).reduce((acc: Record<string, number>, e: any) => {
    const key = `Eixo ${e.eixoData?.number} - ${e.eixoData?.title}`;
    acc[key] = (acc[key] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const topOds = Object.entries(eixoCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);

  return (
    <PlatformLayout projectId={projectId} projectName={project?.title}>
      <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
        {/* Cabecalho */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                <Map className="w-5 h-5 text-emerald-700" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Cartografia Social</h1>
                <p className="text-sm text-muted-foreground">Mapeamento participativo por Eixos Tematicos e fatores territoriais</p>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2" onClick={() => navigate(`/projetos/${projectId}/cartografia-mapa`)}>
              <Layers className="w-4 h-4" />
              Mapa Agregado
            </Button>
            <Button variant="outline" className="gap-2" onClick={() => navigate(`/projetos/${projectId}/cartografia-territorio`)}>
              <GitBranch className="w-4 h-4" />
              Linha do Tempo
            </Button>
            <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 font-semibold">
                <Plus className="w-4 h-4" />
                Nova Sessao
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Map className="w-5 h-5 text-primary" />
                  Nova Sessao de Cartografia
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <Label htmlFor="territory" className="font-semibold">Nome do Territorio *</Label>
                  <Input
                    id="territory"
                    placeholder="Ex: Comunidade Vila Nova, Bairro Sao Jose..."
                    value={form.territory}
                    onChange={e => setForm(f => ({ ...f, territory: e.target.value }))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="monitor" className="font-semibold">Nome do Monitor *</Label>
                  <Input
                    id="monitor"
                    placeholder="Nome do pesquisador popular responsavel"
                    value={form.monitorName}
                    onChange={e => setForm(f => ({ ...f, monitorName: e.target.value }))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="participants" className="font-semibold">Numero de Participantes</Label>
                  <Input
                    id="participants"
                    type="number"
                    placeholder="Quantas pessoas participaram?"
                    value={form.participants}
                    onChange={e => setForm(f => ({ ...f, participants: e.target.value }))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="sessionDate" className="font-semibold">Data da Sessao</Label>
                  <Input
                    id="sessionDate"
                    type="date"
                    value={form.sessionDate}
                    onChange={e => setForm(f => ({ ...f, sessionDate: e.target.value }))}
                    max={today}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="notes" className="font-semibold">Observacoes</Label>
                  <Textarea
                    id="notes"
                    placeholder="Contexto da sessao, local, data..."
                    value={form.notes}
                    onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                    rows={3}
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <Button variant="outline" className="flex-1" onClick={() => setCreateOpen(false)}>Cancelar</Button>
                  <Button className="flex-1 font-semibold" onClick={handleCreate} disabled={createSession.isPending}>
                    {createSession.isPending ? "Criando..." : "Iniciar Sessao"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          </div>
        </div>

        {/* Cards de resumo */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="border-0 shadow-sm bg-blue-50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-blue-700">{sessions?.length ?? 0}</p>
              <p className="text-xs text-blue-600 font-medium mt-1">Sessoes Realizadas</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm bg-emerald-50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-emerald-700">{allEntries?.length ?? 0}</p>
              <p className="text-xs text-emerald-600 font-medium mt-1">Fatores Mapeados</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm bg-red-50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-red-700">{riskCounts["ameaca"] ?? 0}</p>
              <p className="text-xs text-red-600 font-medium mt-1">Ameacas</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm bg-amber-50">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-amber-700">{riskCounts["vulnerabilidade"] ?? 0}</p>
              <p className="text-xs text-amber-600 font-medium mt-1">Vulnerabilidades</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lista de sessoes */}
          <div className="lg:col-span-2 space-y-3">
            <h2 className="text-lg font-bold text-foreground">Sessoes de Cartografia</h2>
            {!sessions?.length ? (
              <Card className="border-dashed border-2 border-muted">
                <CardContent className="py-12 text-center">
                  <Map className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground font-medium">Nenhuma sessao realizada ainda.</p>
                  <p className="text-sm text-muted-foreground mt-1">Clique em "Nova Sessao" para iniciar o mapeamento participativo.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {sessions.map(session => (
                  <Card
                    key={session.id}
                    className="border shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => navigate(`/projetos/${projectId}/cartografia/${session.id}`)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Globe className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                            <p className="font-bold text-foreground truncate">{session.territory}</p>
                            <Badge
                              className={session.status === "concluida"
                                ? "bg-green-100 text-green-800 border-green-300 text-xs"
                                : "bg-blue-100 text-blue-800 border-blue-300 text-xs"}
                            >
                              {session.status === "concluida" ? (
                                <><CheckCircle2 className="w-3 h-3 mr-1" />Concluida</>
                              ) : (
                                <><Clock className="w-3 h-3 mr-1" />Em andamento</>
                              )}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Users className="w-3.5 h-3.5" />
                              Monitor: {session.monitorName}
                            </span>
                            {session.participants ? (
                              <span>{session.participants} participantes</span>
                            ) : null}
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5" />
                              {session.sessionDate ? new Date(session.sessionDate).toLocaleDateString("pt-BR") : ""}
                            </span>
                          </div>
                          {session.notes && (
                            <p className="text-xs text-muted-foreground mt-1.5 line-clamp-1">{session.notes}</p>
                          )}
                        </div>
                        <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Painel lateral: Eixos mais frequentes */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-foreground">Eixos Mais Mapeados</h2>
            {!topOds.length ? (
              <Card className="border-dashed border-2 border-muted">
                <CardContent className="py-8 text-center">
                  <Globe className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Nenhum fator registrado ainda.</p>
                </CardContent>
              </Card>
            ) : (
              <Card className="border shadow-sm">
                <CardContent className="p-4 space-y-3">
                  {topOds.map(([label, count]) => (
                    <div key={label} className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium text-foreground truncate flex-1">{label}</p>
                      <Badge variant="secondary" className="text-xs font-bold">{count}</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Distribuicao de risco */}
            <h2 className="text-lg font-bold text-foreground mt-4">Distribuicao de Risco</h2>
            <Card className="border shadow-sm">
              <CardContent className="p-4 space-y-3">
                {Object.entries(riskColors).map(([key, config]) => {
                  const count = riskCounts[key] ?? 0;
                  const total = allEntries?.length ?? 0;
                  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                  const Icon = config.icon;
                  return (
                    <div key={key}>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          <Icon className={`w-3.5 h-3.5 ${config.text}`} />
                          <span className="text-sm font-medium text-foreground">{config.label}</span>
                        </div>
                        <span className="text-sm font-bold text-foreground">{count} ({pct}%)</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${key === "ameaca" ? "bg-red-500" : key === "vulnerabilidade" ? "bg-amber-500" : "bg-green-500"}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}
