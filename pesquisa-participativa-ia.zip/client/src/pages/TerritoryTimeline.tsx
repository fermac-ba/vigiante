import { useState, useMemo } from "react";
import { useParams, useLocation } from "wouter";
import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNotification } from "@/contexts/NotificationContext";
import {
  MapPin, Calendar, Users, CheckCircle2, Clock,
  AlertTriangle, Shield, TrendingUp, ChevronRight,
  ArrowLeft, Globe, BarChart2, FileText, Loader2,
} from "lucide-react";

const RISK_COLORS: Record<string, string> = {
  ameaca: "bg-red-100 text-red-800",
  vulnerabilidade: "bg-amber-100 text-amber-800",
  resiliencia: "bg-green-100 text-green-800",
};
const RISK_LABELS: Record<string, string> = {
  ameaca: "Ameaças",
  vulnerabilidade: "Vulnerabilidades",
  resiliencia: "Resiliências",
};
const RISK_ICONS: Record<string, React.ElementType> = {
  ameaca: AlertTriangle,
  vulnerabilidade: Shield,
  resiliencia: TrendingUp,
};

const EIXO_COLORS: Record<number, string> = {
  1: "#1A6B4A", 2: "#2563EB", 3: "#7C3AED", 4: "#DC2626", 5: "#D97706", 6: "#0891B2",
};

export default function TerritoryTimeline() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [, navigate] = useLocation();
  const [filterRisk, setFilterRisk] = useState<string | null>(null);
  const [filterEixo, setFilterOds] = useState<number | null>(null);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [expandedSession, setExpandedSession] = useState<number | null>(null);

  const { data: project } = trpc.projects.getById.useQuery({ id: projectId }, { enabled: !!projectId });
  const { data: territories, isLoading } = trpc.socialMapping.getSessionsByTerritory.useQuery(
    { projectId },
    { enabled: !!projectId }
  );
  const { data: allEntries } = trpc.socialMapping.listEntriesByProject.useQuery(
    { projectId },
    { enabled: !!projectId }
  );

  const generateTimelinePdfMutation = trpc.socialMapping.generateTimelinePdf.useMutation({
    onSuccess: (data) => {
      const bytes = Uint8Array.from(atob(data.pdfBase64), c => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
      setGeneratingPdf(false);
    },
    onError: () => {
      notify.error("Erro ao gerar linha do tempo em PDF.");
      setGeneratingPdf(false);
    },
  });
  const generateProjectReportMutation = trpc.socialMapping.generateProjectReport.useMutation({
    onSuccess: (data) => {
      const bytes = Uint8Array.from(atob(data.pdfBase64), c => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
      setGeneratingPdf(false);
    },
    onError: () => {
      notify.error("Erro ao gerar relatorio consolidado.");
      setGeneratingPdf(false);
    },
  });

  // Coletar todos os ODS presentes nas entradas do projeto
  const odsPresentes = useMemo(() => {
    if (!allEntries) return [];
    const map: Record<number, { number: number; shortTitle: string; color: string }> = {};
    for (const e of allEntries) {
      if (e.eixoData && !map[e.eixoData.number]) {
        map[e.eixoData.number] = {
          number: e.eixoData.number,
          shortTitle: e.eixoData.title,
          color: EIXO_COLORS[e.eixoData.number] ?? "#666",
        };
      }
    }
    return Object.values(map).sort((a, b) => a.number - b.number);
  }, [allEntries]);

  // Filtrar entradas por risco e ODS para cada sessão
  const getFilteredEntries = (sessionId: number) => {
    if (!allEntries) return [];
    return allEntries.filter(e => {
      if (e.entry.sessionId !== sessionId) return false;
      if (filterRisk && e.entry.riskClassification !== filterRisk) return false;
      if (filterEixo && e.eixoData?.number !== filterEixo) return false;
      return true;
    });
  };

  if (isLoading) {
    return (
      <PlatformLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </PlatformLayout>
    );
  }

  const totalTerritories = territories?.length ?? 0;
  const totalSessions = territories?.reduce((s, t) => s + t.sessions.length, 0) ?? 0;

  return (
    <PlatformLayout>
      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Cabeçalho */}
        <div className="flex items-center gap-3 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate(`/projetos/${projectId}/cartografia`)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Globe className="w-5 h-5 text-primary" />
              Linha do Tempo por Território
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {(project as any)?.name ?? (project as any)?.title ?? "Projeto"} - {totalTerritories} território{totalTerritories !== 1 ? "s" : ""}, {totalSessions} sessão{totalSessions !== 1 ? "ões" : ""}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={generatingPdf || !territories?.length}
              onClick={() => {
                setGeneratingPdf(true);
                generateTimelinePdfMutation.mutate({ projectId });
              }}
            >
              {generatingPdf ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Gerando...</>
              ) : (
                <><BarChart2 className="w-4 h-4 mr-2" />Exportar Linha do Tempo</>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={generatingPdf || !territories?.length}
              onClick={() => {
                setGeneratingPdf(true);
                generateProjectReportMutation.mutate({ projectId });
              }}
            >
              {generatingPdf ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Gerando PDF...</>
              ) : (
                <><FileText className="w-4 h-4 mr-2" />Relatório Consolidado</>
              )}
            </Button>
          </div>
        </div>

        {/* Filtros */}
        <div className="flex flex-wrap gap-2 mb-6">
          <span className="text-sm font-medium text-muted-foreground self-center">Filtrar:</span>
          {["ameaca", "vulnerabilidade", "resiliencia"].map(risk => {
            const Icon = RISK_ICONS[risk];
            return (
              <button
                key={risk}
                onClick={() => setFilterRisk(filterRisk === risk ? null : risk)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  filterRisk === risk
                    ? RISK_COLORS[risk] + " border-current"
                    : "bg-background text-muted-foreground border-border hover:border-primary"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {RISK_LABELS[risk]}
              </button>
            );
          })}
          {odsPresentes.map(o => (
            <button
              key={o.number}
              onClick={() => setFilterOds(filterEixo === o.number ? null : o.number)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                filterEixo === o.number
                  ? "text-white border-transparent"
                  : "bg-background text-muted-foreground border-border hover:border-primary"
              }`}
              style={filterEixo === o.number ? { backgroundColor: o.color, borderColor: o.color } : {}}
            >
              ODS {o.number}
            </button>
          ))}
          {(filterRisk || filterEixo) && (
            <button
              onClick={() => { setFilterRisk(null); setFilterOds(null); }}
              className="px-3 py-1.5 rounded-full text-xs font-medium text-muted-foreground border border-dashed border-border hover:border-destructive hover:text-destructive transition-all"
            >
              Limpar filtros
            </button>
          )}
        </div>

        {/* Sem dados */}
        {!territories?.length && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <Globe className="w-12 h-12 text-muted-foreground mb-3" />
              <p className="text-muted-foreground">Nenhuma sessão de cartografia registrada neste projeto.</p>
              <Button variant="outline" className="mt-4" onClick={() => navigate(`/projetos/${projectId}/cartografia`)}>
                Criar primeira sessão
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Linha do tempo por território */}
        {territories?.map(({ territory, sessions }) => (
          <div key={territory} className="mb-8">
            {/* Cabeçalho do território */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-foreground">{territory}</h2>
                <p className="text-xs text-muted-foreground">{sessions.length} sessão{sessions.length !== 1 ? "ões" : ""}</p>
              </div>
            </div>

            {/* Gráfico de evolução temporal */}
            {sessions.length > 1 && (() => {
              const maxFactors = Math.max(...sessions.map(s => {
                const e = allEntries?.filter(e => e.entry.sessionId === s.id) ?? [];
                return e.length;
              }), 1);
              return (
                <div className="mb-4 bg-muted/20 rounded-xl p-3 border border-border/50">
                  <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1">
                    <BarChart2 className="w-3.5 h-3.5" />
                    Evolução de fatores por sessão
                  </p>
                  <div className="flex items-end gap-2 h-16">
                    {sessions.map((s, i) => {
                      const sessionEntries = allEntries?.filter(e => e.entry.sessionId === s.id) ?? [];
                      const byRisk = { ameaca: 0, vulnerabilidade: 0, resiliencia: 0 };
                      for (const e of sessionEntries) { byRisk[e.entry.riskClassification as keyof typeof byRisk]++; }
                      const total = sessionEntries.length;
                      const heightPct = total === 0 ? 4 : Math.max(8, (total / maxFactors) * 100);
                      return (
                        <div key={s.id} className="flex-1 flex flex-col items-center gap-1 min-w-0">
                          <span className="text-[10px] font-bold text-foreground">{total}</span>
                          <div className="w-full flex flex-col-reverse rounded overflow-hidden" style={{ height: `${heightPct}%` }}>
                            {byRisk.resiliencia > 0 && (
                              <div className="bg-green-400" style={{ flex: byRisk.resiliencia }} />
                            )}
                            {byRisk.vulnerabilidade > 0 && (
                              <div className="bg-amber-400" style={{ flex: byRisk.vulnerabilidade }} />
                            )}
                            {byRisk.ameaca > 0 && (
                              <div className="bg-red-400" style={{ flex: byRisk.ameaca }} />
                            )}
                            {total === 0 && <div className="bg-muted flex-1" />}
                          </div>
                          <span className="text-[9px] text-muted-foreground truncate w-full text-center">
                            {s.sessionDate ? new Date(s.sessionDate).toLocaleDateString("pt-BR", { month: "short", day: "numeric" }) : `S${i + 1}`}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="flex items-center gap-1 text-[10px] text-red-700"><span className="w-2.5 h-2.5 rounded-sm bg-red-400 inline-block" />Ameaças</span>
                    <span className="flex items-center gap-1 text-[10px] text-amber-700"><span className="w-2.5 h-2.5 rounded-sm bg-amber-400 inline-block" />Vulnerabilidades</span>
                    <span className="flex items-center gap-1 text-[10px] text-green-700"><span className="w-2.5 h-2.5 rounded-sm bg-green-400 inline-block" />Resiliências</span>
                  </div>
                </div>
              );
            })()}
            {/* Linha do tempo */}
            <div className="ml-4 pl-6 border-l-2 border-primary/20 space-y-4">
              {sessions.map((session, idx) => {
                const filteredEntries = getFilteredEntries(session.id);
                const isExpanded = expandedSession === session.id;
                const dateStr = session.sessionDate
                  ? new Date(session.sessionDate).toLocaleDateString("pt-BR")
                  : "Sem data";
                // Contagem de risco para esta sessão (usando allEntries)
                const sessionEntries = allEntries?.filter(e => e.entry.sessionId === session.id) ?? [];
                const byRisk = { ameaca: 0, vulnerabilidade: 0, resiliencia: 0 };
                for (const e of sessionEntries) {
                  if (e.entry.riskClassification in byRisk) {
                    byRisk[e.entry.riskClassification as keyof typeof byRisk]++;
                  }
                }
                const hasFilteredContent = !filterRisk && !filterEixo || filteredEntries.length > 0;

                return (
                  <div
                    key={session.id}
                    className={`relative transition-opacity ${!hasFilteredContent ? "opacity-40" : ""}`}
                  >
                    {/* Marcador da linha do tempo */}
                    <div className="absolute -left-[33px] top-3 w-4 h-4 rounded-full border-2 border-primary bg-background flex items-center justify-center">
                      {session.status === "concluida"
                        ? <CheckCircle2 className="w-2.5 h-2.5 text-primary" />
                        : <Clock className="w-2.5 h-2.5 text-amber-500" />}
                    </div>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2 pt-3 px-4">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {dateStr}
                              </span>
                              <Badge
                                variant="outline"
                                className={session.status === "concluida"
                                  ? "text-green-700 border-green-300 bg-green-50 text-xs"
                                  : "text-amber-700 border-amber-300 bg-amber-50 text-xs"}
                              >
                                {session.status === "concluida" ? "Concluída" : "Em andamento"}
                              </Badge>
                              {session.participants ? (
                                <span className="text-xs text-muted-foreground flex items-center gap-1">
                                  <Users className="w-3 h-3" />
                                  {session.participants} participantes
                                </span>
                              ) : null}
                            </div>
                            <p className="text-sm font-medium text-foreground mt-1">
                              Monitor: {session.monitorName}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs flex-shrink-0"
                            onClick={() => navigate(`/projetos/${projectId}/cartografia/${session.id}`)}
                          >
                            Abrir <ChevronRight className="w-3 h-3 ml-1" />
                          </Button>
                        </div>
                      </CardHeader>

                      <CardContent className="px-4 pb-3">
                        {/* Minigráfico de risco */}
                        <div className="flex gap-3 mb-2 flex-wrap">
                          {byRisk.ameaca > 0 && (
                            <span className="flex items-center gap-1 text-xs text-red-700 bg-red-50 px-2 py-0.5 rounded-full">
                              <AlertTriangle className="w-3 h-3" />
                              {byRisk.ameaca} ameaça{byRisk.ameaca !== 1 ? "s" : ""}
                            </span>
                          )}
                          {byRisk.vulnerabilidade > 0 && (
                            <span className="flex items-center gap-1 text-xs text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                              <Shield className="w-3 h-3" />
                              {byRisk.vulnerabilidade} vulnerabilidade{byRisk.vulnerabilidade !== 1 ? "s" : ""}
                            </span>
                          )}
                          {byRisk.resiliencia > 0 && (
                            <span className="flex items-center gap-1 text-xs text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                              <TrendingUp className="w-3 h-3" />
                              {byRisk.resiliencia} resiliência{byRisk.resiliencia !== 1 ? "s" : ""}
                            </span>
                          )}
                          {sessionEntries.length === 0 && (
                            <span className="text-xs text-muted-foreground italic">Nenhum fator registrado</span>
                          )}
                        </div>

                        {/* ODS presentes na sessão */}
                        {(() => {
                          const eixoSet: Record<number, string> = {};
                          for (const e of sessionEntries) {
                            if (e.eixoData) eixoSet[e.eixoData.number] = EIXO_COLORS[e.eixoData.number] ?? "#666";
                          }
                          const odsNums = Object.entries(eixoSet);
                          if (!odsNums.length) return null;
                          return (
                            <div className="flex flex-wrap gap-1 mb-2">
                              {odsNums.map(([num, color]) => (
                                <span
                                  key={num}
                                  className="text-white text-xs px-1.5 py-0.5 rounded font-medium"
                                  style={{ backgroundColor: color }}
                                >
                                  ODS {num}
                                </span>
                              ))}
                            </div>
                          );
                        })()}

                        {/* Síntese analítica (colapsável) */}
                        {session.analysisText && (
                          <div>
                            <button
                              className="text-xs text-primary flex items-center gap-1 mt-1 hover:underline"
                              onClick={() => setExpandedSession(isExpanded ? null : session.id)}
                            >
                              <BarChart2 className="w-3 h-3" />
                              {isExpanded ? "Ocultar síntese analítica" : "Ver síntese analítica"}
                            </button>
                            {isExpanded && (
                              <div className="mt-2 text-xs text-foreground/80 bg-indigo-50 border-l-2 border-indigo-400 p-2 rounded whitespace-pre-wrap leading-relaxed">
                                {session.analysisText}
                              </div>
                            )}
                          </div>
                        )}

                        {/* Fatores filtrados */}
                        {(filterRisk || filterEixo) && filteredEntries.length > 0 && (
                          <div className="mt-2 space-y-1">
                            <p className="text-xs font-medium text-muted-foreground">
                              {filteredEntries.length} fator{filteredEntries.length !== 1 ? "es" : ""} correspondente{filteredEntries.length !== 1 ? "s" : ""}:
                            </p>
                            {filteredEntries.slice(0, 5).map(e => (
                              <div key={e.entry.id} className="flex items-center gap-2 text-xs">
                                {e.eixoData && (
                                  <span
                                    className="text-white px-1.5 py-0.5 rounded font-medium flex-shrink-0"
                                    style={{ backgroundColor: EIXO_COLORS[e.eixoData.number] ?? "#666" }}
                                  >
                                    Eixo {e.eixoData.number}
                                  </span>
                                )}
                                <span className="text-foreground">{e.entry.factorName}</span>
                                <span className="text-muted-foreground ml-auto flex-shrink-0">{e.entry.importanceLevel}/10</span>
                              </div>
                            ))}
                            {filteredEntries.length > 5 && (
                              <p className="text-xs text-muted-foreground italic">... e mais {filteredEntries.length - 5}</p>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </PlatformLayout>
  );
}
