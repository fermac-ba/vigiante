import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useParams } from "wouter";
import { useState, useMemo } from "react";
import { Brain, Tag, Heart, User, Hash, Loader2, CheckCircle2, AlertCircle, RefreshCw, ThumbsUp, ThumbsDown, MessageSquare, Cloud } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

// Componente simples de nuvem de palavras sem biblioteca externa
function WordCloud({ wordFrequency }: { wordFrequency: Record<string, number> }) {
  const words = Object.entries(wordFrequency).sort((a, b) => b[1] - a[1]).slice(0, 40);
  if (!words.length) return null;
  const maxFreq = words[0]?.[1] ?? 1;
  const colors = ["text-green-700", "text-blue-700", "text-purple-700", "text-teal-700", "text-emerald-700", "text-indigo-700"];
  return (
    <div className="flex flex-wrap gap-2 items-center justify-center p-4 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl border-2 border-green-200 min-h-[120px]">
      {words.map(([word, freq], i) => {
        const ratio = freq / maxFreq;
        const size = ratio > 0.7 ? "text-2xl font-bold" : ratio > 0.4 ? "text-lg font-semibold" : ratio > 0.2 ? "text-base font-medium" : "text-sm";
        const color = colors[i % colors.length];
        return (
          <span key={word} className={`${size} ${color} cursor-default hover:opacity-80 transition-opacity`} title={`${freq} ocorrencia(s)`}>
            {word}
          </span>
        );
      })}
    </div>
  );
}

// Painel de validação humana
function ValidationPanel({ analysisId, validated, onValidate }: { analysisId: number; validated: boolean | null; onValidate: (id: number, v: boolean, notes: string) => void }) {
  const [notes, setNotes] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [pendingValidation, setPendingValidation] = useState<boolean | null>(null);

  const handleSubmit = () => {
    if (pendingValidation === null) return;
    onValidate(analysisId, pendingValidation, notes);
    setShowForm(false);
    setNotes("");
    setPendingValidation(null);
  };

  if (validated !== null) {
    return (
      <div className={`flex items-center gap-2 p-2 rounded-lg text-xs font-medium ${validated ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
        {validated ? <ThumbsUp className="w-3 h-3" /> : <ThumbsDown className="w-3 h-3" />}
        {validated ? "Analise validada pelo pesquisador" : "Analise revisada - interpretacao divergente registrada"}
      </div>
    );
  }

  return (
    <div className="border-t border-border pt-3 mt-3">
      {!showForm ? (
        <div className="flex items-center gap-2">
          <p className="text-xs text-muted-foreground flex-1">Valide a interpretacao da IA:</p>
          <Button size="sm" variant="outline" className="gap-1 text-xs border-green-300 text-green-700 hover:bg-green-50" onClick={() => { setPendingValidation(true); setShowForm(true); }}>
            <ThumbsUp className="w-3 h-3" />Confirmar
          </Button>
          <Button size="sm" variant="outline" className="gap-1 text-xs border-red-300 text-red-700 hover:bg-red-50" onClick={() => { setPendingValidation(false); setShowForm(true); }}>
            <ThumbsDown className="w-3 h-3" />Divergir
          </Button>
        </div>
      ) : (
        <div className="space-y-2">
          <div className={`flex items-center gap-2 text-xs font-medium ${pendingValidation ? "text-green-700" : "text-red-700"}`}>
            {pendingValidation ? <ThumbsUp className="w-3 h-3" /> : <ThumbsDown className="w-3 h-3" />}
            {pendingValidation ? "Confirmando analise" : "Registrando divergencia"}
          </div>
          <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder={pendingValidation ? "Observacoes adicionais (opcional)..." : "Descreva sua interpretacao divergente..."} rows={2} className="text-xs" />
          <div className="flex gap-2">
            <Button size="sm" onClick={handleSubmit} className="text-xs gap-1"><MessageSquare className="w-3 h-3" />Registrar</Button>
            <Button size="sm" variant="outline" onClick={() => { setShowForm(false); setPendingValidation(null); setNotes(""); }} className="text-xs">Cancelar</Button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AiAnalysis() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const utils = trpc.useUtils();
  const { data: entries } = trpc.fieldEntries.listByProject.useQuery({ projectId });
  const { data: analyses, isLoading } = trpc.aiAnalysis.getByProject.useQuery({ projectId });

  const analyzeEntry = trpc.aiAnalysis.analyze.useMutation({
    onSuccess: () => { utils.aiAnalysis.getByProject.invalidate({ projectId }); notify.success("Analise concluida!"); },
    onError: (e) => notify.error(`Erro: ${e.message}`),
  });

  const validateAnalysis = trpc.aiAnalysis.validate.useMutation({
    onSuccess: () => { utils.aiAnalysis.getByProject.invalidate({ projectId }); notify.success("Validacao registrada!"); },
    onError: () => notify.error("Erro ao registrar validacao."),
  });

  const entriesWithText = entries?.filter(e => e.narrativeText && e.narrativeText.length > 20) ?? [];
  const analyzedIds = new Set(analyses?.map((a: { fieldEntryId: number | null }) => a.fieldEntryId));

  // Nuvem de palavras agregada de todas as análises
  const aggregatedWordFrequency = useMemo(() => {
    if (!analyses?.length) return {};
    const combined: Record<string, number> = {};
    analyses.forEach((a: { wordFrequency: unknown }) => {
      if (a.wordFrequency && typeof a.wordFrequency === "object") {
        Object.entries(a.wordFrequency as Record<string, number>).forEach(([word, freq]) => {
          combined[word] = (combined[word] ?? 0) + freq;
        });
      }
    });
    return combined;
  }, [analyses]);

  const hasWordCloud = Object.keys(aggregatedWordFrequency).length > 0;

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Analise com Inteligencia Artificial</h1>
            <p className="text-muted-foreground mt-1">Processamento de narrativas com sugestao de codigos tematicos, analise de sentimentos e extracao de entidades. O controle interpretativo permanece com o pesquisador.</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {[
            { label: "Coletas com texto", value: entriesWithText.length, icon: Hash, color: "blue" },
            { label: "Analises realizadas", value: analyses?.length ?? 0, icon: Brain, color: "purple" },
            { label: "Aguardando analise", value: entriesWithText.filter(e => !analyzedIds.has(e.id)).length, icon: AlertCircle, color: "amber" },
          ].map((s, i) => (
            <Card key={i} className={`border-2 border-${s.color}-200 bg-${s.color}-50/50`}>
              <CardContent className="p-4 text-center">
                <div className={`w-10 h-10 rounded-xl bg-${s.color}-100 flex items-center justify-center mx-auto mb-2`}><s.icon className={`w-5 h-5 text-${s.color}-600`} /></div>
                <p className={`text-2xl font-bold text-${s.color}-900`}>{s.value}</p>
                <p className={`text-xs text-${s.color}-700 font-medium`}>{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Nuvem de palavras agregada */}
        {hasWordCloud && (
          <Card className="border-2 border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2"><Cloud className="w-5 h-5 text-green-600" />Nuvem de Palavras - Todas as Narrativas</CardTitle>
              <p className="text-xs text-muted-foreground">Frequencia agregada de termos em todas as analises realizadas. Palavras maiores aparecem com maior frequencia.</p>
            </CardHeader>
            <CardContent>
              <WordCloud wordFrequency={aggregatedWordFrequency} />
            </CardContent>
          </Card>
        )}

        {entriesWithText.filter(e => !analyzedIds.has(e.id)).length > 0 && (
          <Card className="border-2 border-amber-200 bg-amber-50/50">
            <CardHeader><CardTitle className="text-lg text-amber-900">Coletas aguardando analise</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {entriesWithText.filter(e => !analyzedIds.has(e.id)).map(entry => (
                <div key={entry.id} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-amber-200">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{entry.locationName ?? `Coleta #${entry.id}`}</p>
                    <p className="text-xs text-muted-foreground line-clamp-1">{entry.narrativeText}</p>
                  </div>
                  <Button size="sm" onClick={() => analyzeEntry.mutate({ projectId, text: entry.narrativeText ?? "", analysisType: "completa", fieldEntryId: entry.id })} disabled={analyzeEntry.isPending} className="gap-1 flex-shrink-0">
                    {analyzeEntry.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Brain className="w-3 h-3" />}Analisar
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Resultados das analises</h2>
          {isLoading ? (
            <div className="space-y-4">{[1, 2].map(i => <div key={i} className="h-48 bg-muted rounded-xl animate-pulse" />)}</div>
          ) : !analyses?.length ? (
            <Card className="border-2 border-dashed border-border">
              <CardContent className="p-8 text-center">
                <Brain className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold text-foreground">Nenhuma analise realizada</p>
                <p className="text-sm text-muted-foreground">Selecione coletas acima para iniciar a analise com IA.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {analyses.map((analysis: { id: number; fieldEntryId: number | null; cycleId: number | null; projectId: number; analysisType: string; suggestedCodes: unknown; sentimentResult: unknown; entities: unknown; topics: unknown; wordFrequency: unknown; humanValidated: boolean | null; validationNotes?: string | null; createdAt: Date; updatedAt: Date }) => {
                const entry = entries?.find(e => e.id === analysis.fieldEntryId);
                const codes = Array.isArray(analysis.suggestedCodes) ? (analysis.suggestedCodes as Array<{ codigo?: string; descricao?: string }>) : [];
                const sentiment = analysis.sentimentResult as { predominante?: string } | null;
                const entitiesData = analysis.entities as Record<string, unknown> | null;
                const topicsData = Array.isArray(analysis.topics) ? (analysis.topics as Array<{ palavras_chave?: string[] }>) : [];
                const wordFreq = (analysis.wordFrequency && typeof analysis.wordFrequency === "object") ? analysis.wordFrequency as Record<string, number> : {};
                const topWords = Object.entries(wordFreq).sort((a, b) => b[1] - a[1]).slice(0, 8);

                return (
                  <Card key={analysis.id} className="border-2 border-border">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <CardTitle className="text-base">{entry?.locationName ?? `Coleta #${analysis.fieldEntryId}`}</CardTitle>
                          <p className="text-xs text-muted-foreground mt-1">{new Date(analysis.createdAt).toLocaleDateString("pt-BR")}</p>
                        </div>
                        <Badge className="bg-green-100 text-green-800 border-green-300 text-xs border">
                          <CheckCircle2 className="w-3 h-3 mr-1" />Analisado
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {sentiment?.predominante && (
                        <div className="flex items-center gap-2">
                          <Heart className="w-4 h-4 text-rose-500" />
                          <span className="text-sm font-medium text-foreground">Sentimento predominante:</span>
                          <Badge variant="outline" className="text-xs">{sentiment.predominante}</Badge>
                        </div>
                      )}
                      {codes.length > 0 && (
                        <div>
                          <div className="flex items-center gap-2 mb-2"><Tag className="w-4 h-4 text-purple-500" /><span className="text-sm font-medium text-foreground">Codigos tematicos sugeridos:</span></div>
                          <div className="flex flex-wrap gap-2">{codes.map((c, i) => <Badge key={i} className="bg-purple-100 text-purple-800 border-purple-300 border text-xs">{c.codigo ?? String(c)}</Badge>)}</div>
                        </div>
                      )}
                      {entitiesData && Object.keys(entitiesData).length > 0 && (
                        <div>
                          <div className="flex items-center gap-2 mb-2"><User className="w-4 h-4 text-blue-500" /><span className="text-sm font-medium text-foreground">Entidades identificadas:</span></div>
                          <div className="flex flex-wrap gap-2">{Object.entries(entitiesData).flatMap(([k, v]) => Array.isArray(v) ? (v as string[]).map((item, i) => <Badge key={`${k}-${i}`} variant="outline" className="text-xs">{item}</Badge>) : [])}</div>
                        </div>
                      )}
                      {topicsData.length > 0 && (
                        <div className="p-3 bg-muted/50 rounded-lg">
                          <p className="text-xs text-muted-foreground font-medium mb-2">Topicos identificados:</p>
                          <div className="flex flex-wrap gap-1">{topicsData.flatMap(t => t.palavras_chave ?? []).slice(0, 15).map((w, i) => <span key={i} className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">{w}</span>)}</div>
                        </div>
                      )}
                      {topWords.length > 0 && (
                        <div>
                          <div className="flex items-center gap-2 mb-2"><RefreshCw className="w-4 h-4 text-teal-500" /><span className="text-sm font-medium text-foreground">Palavras mais frequentes:</span></div>
                          <div className="flex flex-wrap gap-2">{topWords.map(([word, freq]) => <span key={word} className="text-xs bg-teal-100 text-teal-800 px-2 py-1 rounded-full font-medium">{word} ({freq})</span>)}</div>
                        </div>
                      )}
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                        <p className="text-xs text-amber-800">Os codigos e analises acima sao sugestoes da IA. A interpretacao final e responsabilidade do pesquisador popular e da equipe.</p>
                      </div>
                      {/* Validação humana */}
                      <ValidationPanel
                        analysisId={analysis.id}
                        validated={analysis.humanValidated ?? null}
                        onValidate={(id, v, notes) => validateAnalysis.mutate({ id, validated: v, notes })}
                      />
                      {analysis.validationNotes && (
                        <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg">
                          <p className="text-xs text-blue-800 font-medium">Nota do pesquisador:</p>
                          <p className="text-xs text-blue-700 mt-1">{analysis.validationNotes}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
