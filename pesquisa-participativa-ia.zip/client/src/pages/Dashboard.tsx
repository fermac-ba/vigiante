import PlatformLayout from "@/components/PlatformLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { FolderOpen, MapPin, BarChart3, Bell, Plus, ArrowRight, Clock, PlayCircle, Leaf } from "lucide-react";

const statusColors: Record<string, string> = {
  ativo: "bg-green-100 text-green-800 border-green-300",
  pausado: "bg-amber-100 text-amber-800 border-amber-300",
  concluido: "bg-gray-100 text-gray-600 border-gray-300",
};
const statusLabels: Record<string, string> = { ativo: "Ativo", pausado: "Pausado", concluido: "Concluido" };
const roleGreetings: Record<string, string> = {
  pesquisador_popular: "Ola, Pesquisador Popular!",
  facilitador: "Ola, Facilitador!",
  gestor: "Ola, Gestor!",
  admin: "Ola, Administrador!",
};

export default function Dashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { data: projects, isLoading } = trpc.projects.list.useQuery();
  const { data: unreadCount } = trpc.notifications.unreadCount.useQuery();
  const userRole = user?.role ?? "pesquisador_popular";
  const activeProjects = projects?.filter(p => p.status === "ativo") ?? [];
  const recentProjects = projects?.slice(0, 4) ?? [];

  return (
    <PlatformLayout>
      <div className="p-6 max-w-5xl mx-auto space-y-8">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">{roleGreetings[userRole] ?? "Bem-vindo!"}</h1>
            <p className="text-muted-foreground mt-1 text-lg">{user?.name ? `${user.name}, ` : ""}aqui esta um resumo da sua pesquisa participativa.</p>
          </div>
          {(userRole === "facilitador" || userRole === "gestor" || userRole === "admin") && (
            <Button onClick={() => navigate("/projetos")} className="gap-2 flex-shrink-0"><Plus className="w-4 h-4" />Novo Projeto</Button>
          )}
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Projetos no total", value: projects?.length ?? 0, icon: FolderOpen, color: "green" },
            { label: "Projetos ativos", value: activeProjects.length, icon: PlayCircle, color: "blue" },
            { label: "Notificacoes novas", value: unreadCount ?? 0, icon: Bell, color: "amber", onClick: () => navigate("/notificacoes") },
            { label: "Projetos concluidos", value: projects?.filter(p => p.status === "concluido").length ?? 0, icon: BarChart3, color: "purple" },
          ].map((card, i) => (
            <Card key={i} className={`border-2 border-${card.color}-200 bg-${card.color}-50/50 ${card.onClick ? "cursor-pointer hover:shadow-md transition-shadow" : ""}`} onClick={card.onClick}>
              <CardContent className="p-5">
                <div className={`w-10 h-10 rounded-xl bg-${card.color}-100 flex items-center justify-center mb-3`}>
                  <card.icon className={`w-5 h-5 text-${card.color}-600`} />
                </div>
                <p className={`text-3xl font-bold text-${card.color}-900`}>{card.value}</p>
                <p className={`text-sm text-${card.color}-700 font-medium mt-1`}>{card.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Acoes rapidas</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: "Coletar dados", desc: "Registrar narrativas em campo", icon: MapPin, iconBg: "bg-primary/10", iconColor: "text-primary", onClick: () => navigate("/projetos") },
              ...(["facilitador","gestor","admin"].includes(userRole) ? [{ label: "Ver analises", desc: "Analise de narrativas com IA", icon: BarChart3, iconBg: "bg-purple-100", iconColor: "text-purple-600", onClick: () => navigate("/projetos") }] : []),
              { label: "Notificacoes", desc: `${unreadCount ?? 0} novas mensagens`, icon: Bell, iconBg: "bg-amber-100", iconColor: "text-amber-600", onClick: () => navigate("/notificacoes") },
            ].map((action, i) => (
              <button key={i} onClick={action.onClick} className="flex items-center gap-4 p-5 bg-white border-2 border-border rounded-2xl hover:border-primary hover:shadow-md transition-all text-left group">
                <div className={`w-12 h-12 rounded-xl ${action.iconBg} flex items-center justify-center`}>
                  <action.icon className={`w-6 h-6 ${action.iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground">{action.label}</p>
                  <p className="text-sm text-muted-foreground">{action.desc}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-foreground">Projetos recentes</h2>
            <Button variant="ghost" onClick={() => navigate("/projetos")} className="gap-1 text-primary">Ver todos <ArrowRight className="w-4 h-4" /></Button>
          </div>
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{[1,2].map(i => <div key={i} className="h-32 bg-muted rounded-2xl animate-pulse" />)}</div>
          ) : recentProjects.length === 0 ? (
            <Card className="border-2 border-dashed border-border">
              <CardContent className="p-10 text-center">
                <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4"><Leaf className="w-8 h-8 text-muted-foreground" /></div>
                <p className="text-lg font-semibold text-foreground mb-2">Nenhum projeto ainda</p>
                <p className="text-muted-foreground mb-4">Crie seu primeiro projeto de pesquisa participativa.</p>
                {(["facilitador","gestor","admin"].includes(userRole)) && (
                  <Button onClick={() => navigate("/projetos")} className="gap-2"><Plus className="w-4 h-4" />Criar projeto</Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {recentProjects.map(project => (
                <button key={project.id} onClick={() => navigate(`/projetos/${project.id}`)} className="text-left p-5 bg-white border-2 border-border rounded-2xl hover:border-primary hover:shadow-md transition-all group">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-primary transition-colors">{project.title}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full border font-medium flex-shrink-0 ${statusColors[project.status]}`}>{statusLabels[project.status]}</span>
                  </div>
                  {project.territory && <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2"><MapPin className="w-3 h-3" /><span>{project.territory}</span></div>}
                  {project.description && <p className="text-sm text-muted-foreground line-clamp-2">{project.description}</p>}
                  <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground"><Clock className="w-3 h-3" /><span>Criado em {new Date(project.createdAt).toLocaleDateString("pt-BR")}</span></div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
