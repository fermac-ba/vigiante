import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useParams } from "wouter";
import { useState, useRef } from "react";
import { FileText, Upload, Database, AlertCircle } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

export default function EpidemiologicalData() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [open, setOpen] = useState(false);
  const [datasetName, setDatasetName] = useState("");
  const [datasetType, setDatasetType] = useState<"epidemiologico"|"social"|"ambiental"|"outro">("epidemiologico");
  const [source, setSource] = useState("");
  const [referenceYear, setReferenceYear] = useState("");
  const [parsedData, setParsedData] = useState<{ records: Record<string, unknown>[]; columns: string[] } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();
  const { data: datasets, isLoading } = trpc.epidemiologicalData.listByProject.useQuery({ projectId });
  const importData = trpc.epidemiologicalData.import.useMutation({
    onSuccess: () => { utils.epidemiologicalData.listByProject.invalidate({ projectId }); setOpen(false); setDatasetName(""); setParsedData(null); notify.success("Dados importados com sucesso!"); },
    onError: () => notify.error("Erro ao importar dados."),
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string;
        if (file.name.endsWith(".json")) {
          const json = JSON.parse(text);
          const records = Array.isArray(json) ? json : [json];
          const columns = records.length > 0 ? Object.keys(records[0]) : [];
          setParsedData({ records, columns });
        } else {
          const lines = text.split("\n").filter(l => l.trim());
          const headers = lines[0].split(",").map(h => h.trim().replace(/"/g, ""));
          const records = lines.slice(1).map(line => {
            const vals = line.split(",").map(v => v.trim().replace(/"/g, ""));
            return Object.fromEntries(headers.map((h, i) => [h, vals[i] ?? ""]));
          });
          setParsedData({ records, columns: headers });
        }
        notify.success(`${parsedData?.records.length ?? "?"} registros carregados.`);
      } catch { notify.error("Erro ao processar arquivo. Verifique o formato CSV ou JSON."); }
    };
    reader.readAsText(file);
  };

  const typeLabels: Record<string, string> = { epidemiologico: "Epidemiologico", social: "Social", ambiental: "Ambiental", outro: "Outro" };
  const typeColors: Record<string, string> = { epidemiologico: "bg-red-100 text-red-800 border-red-300", social: "bg-blue-100 text-blue-800 border-blue-300", ambiental: "bg-green-100 text-green-800 border-green-300", outro: "bg-gray-100 text-gray-700 border-gray-300" };

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div><h1 className="text-3xl font-bold text-foreground">Dados Epidemiologicos</h1><p className="text-muted-foreground mt-1">Importe e integre dados epidemiologicos e indicadores sociais para convergencia com os dados coletados em campo.</p></div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button className="gap-2"><Upload className="w-4 h-4" />Importar dados</Button></DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>Importar conjunto de dados</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <div><Label className="font-semibold">Nome do conjunto *</Label><Input value={datasetName} onChange={e => setDatasetName(e.target.value)} placeholder="Ex: Indicadores de saude 2024" className="mt-1" /></div>
                <div><Label className="font-semibold">Tipo de dado</Label>
                  <select
                    value={datasetType}
                    onChange={e => setDatasetType(e.target.value as "epidemiologico"|"social"|"ambiental"|"outro")}
                    className="mt-1 w-full rounded-lg border-2 border-border bg-background px-3 py-2.5 text-base text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="epidemiologico">Epidemiologico</option>
                    <option value="social">Social</option>
                    <option value="ambiental">Ambiental</option>
                    <option value="outro">Outro</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="font-semibold">Fonte</Label><Input value={source} onChange={e => setSource(e.target.value)} placeholder="Ex: DATASUS, IBGE" className="mt-1" /></div>
                  <div><Label className="font-semibold">Ano de referencia</Label><Input value={referenceYear} onChange={e => setReferenceYear(e.target.value)} type="number" placeholder="2024" className="mt-1" /></div>
                </div>
                <div>
                  <Label className="font-semibold">Arquivo (CSV ou JSON)</Label>
                  <div className="mt-1 border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-primary transition-colors" onClick={() => fileRef.current?.click()}>
                    <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">{parsedData ? `${parsedData.records.length} registros carregados` : "Clique para selecionar arquivo CSV ou JSON"}</p>
                    <input ref={fileRef} type="file" accept=".csv,.json" className="hidden" onChange={handleFileChange} />
                  </div>
                </div>
                {parsedData && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-800">
                    <p className="font-medium">{parsedData.records.length} registros com {parsedData.columns.length} colunas</p>
                    <p className="text-xs mt-1">Colunas: {parsedData.columns.slice(0, 5).join(", ")}{parsedData.columns.length > 5 ? "..." : ""}</p>
                  </div>
                )}
                <Button className="w-full py-5" disabled={!datasetName || !parsedData || importData.isPending} onClick={() => importData.mutate({ projectId, datasetName, datasetType, source, referenceYear: referenceYear ? parseInt(referenceYear) : undefined, records: parsedData!.records, columns: parsedData!.columns })}>{importData.isPending ? "Importando..." : "Importar dados"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Conjuntos de dados importados</h2>
          {isLoading ? <div className="space-y-3">{[1,2].map(i => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}</div>
          : !datasets?.length ? (
            <Card className="border-2 border-dashed border-border"><CardContent className="p-8 text-center"><Database className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-semibold text-foreground">Nenhum dado importado</p><p className="text-sm text-muted-foreground">Importe dados epidemiologicos do DATASUS, IBGE ou outras fontes para enriquecer a analise.</p></CardContent></Card>
          ) : (
            <div className="space-y-3">
              {datasets.map(ds => (
                <Card key={ds.id} className="border-2 border-border">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground text-base">{ds.datasetName}</p>
                        <div className="flex items-center gap-3 mt-2 flex-wrap">
                          <span className={"text-xs px-2 py-1 rounded-full border font-medium " + typeColors[ds.datasetType]}>{typeLabels[ds.datasetType]}</span>
                          {ds.source && <span className="text-xs text-muted-foreground">Fonte: {ds.source}</span>}
                          {ds.referenceYear && <span className="text-xs text-muted-foreground">Ano: {ds.referenceYear}</span>}
                          <span className="text-xs text-muted-foreground">{ds.totalRecords ?? 0} registros</span>
                        </div>
                      </div>
                      <FileText className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
