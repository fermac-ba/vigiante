import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useParams } from "wouter";
import { useState } from "react";
import { Target, Plus, Users, ArrowRight, Clock } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

export default function ActionPlans() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [objective, setObjective] = useState("");
  const [context, setContext] = useState("");
  const utils = trpc.useUtils();
  const { data: plans, isLoading } = trpc.actionPlans.listByProject.useQuery({ projectId });
  const createPlan = trpc.actionPlans.create.useMutation({
    onSuccess: () => { utils.actionPlans.listByProject.invalidate({ projectId }); setOpen(false); setTitle(""); setObjective(""); setContext(""); notify.success("Plano de incidencia criado!"); },
    onError: () => notify.error("Erro ao criar plano."),
  });

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div><h1 className="text-3xl font-bold text-foreground">Incidencia Politica</h1><p className="text-muted-foreground mt-1">Elabore planos de acao comunitaria, mapeie atores e defina estrategias de incidencia politica baseadas nos diagnosticos.</p></div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" />Novo plano</Button></DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>Criar plano de incidencia</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <div><Label className="font-semibold">Titulo do plano *</Label><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Plano de Acesso a Saude Mental" className="mt-1" /></div>
                <div><Label className="font-semibold">Contexto / Problema identificado</Label><Textarea value={context} onChange={e => setContext(e.target.value)} placeholder="Descreva o problema central identificado na pesquisa e o contexto territorial..." className="mt-1" rows={3} /></div>
                <div><Label className="font-semibold">Objetivo de mudanca</Label><Textarea value={objective} onChange={e => setObjective(e.target.value)} placeholder="O que queremos transformar?" className="mt-1" rows={2} /></div>
                <Button className="w-full py-5" disabled={!title || createPlan.isPending} onClick={() => createPlan.mutate({ projectId, title, objective, context })}>{createPlan.isPending ? "Criando..." : "Criar plano"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Planos de incidencia</h2>
          {isLoading ? <div className="space-y-3">{[1,2].map(i => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}</div>
          : !plans?.length ? (
            <Card className="border-2 border-dashed border-border"><CardContent className="p-8 text-center"><Target className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-semibold text-foreground">Nenhum plano criado</p><p className="text-sm text-muted-foreground">Crie planos de incidencia politica baseados nos diagnosticos participativos.</p></CardContent></Card>
          ) : (
            <div className="space-y-4">
              {plans.map(plan => (
                <Card key={plan.id} className="border-2 border-border hover:border-primary transition-colors">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <h3 className="font-bold text-foreground text-lg">{plan.title}</h3>
                      <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(plan.createdAt).toLocaleDateString("pt-BR")}</span>
                    </div>
                    {plan.context && <div className="mb-2"><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Contexto</p><p className="text-sm text-foreground">{plan.context}</p></div>}
                    {plan.objective && <div className="mb-2"><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Objetivo</p><p className="text-sm text-foreground">{plan.objective}</p></div>}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
