import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useParams } from "wouter";
import { useState, useCallback } from "react";
import { Mic, Clock, CheckCircle2, AlertCircle, Edit3, Save, Play, Loader2 } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

const statusColors: Record<string, string> = {
  pendente: "bg-gray-100 text-gray-700 border-gray-300",
  processando: "bg-blue-100 text-blue-700 border-blue-300",
  concluido: "bg-green-100 text-green-700 border-green-300",
  erro: "bg-red-100 text-red-700 border-red-300",
};
const statusLabels: Record<string, string> = { pendente: "Pendente", processando: "Processando", concluido: "Concluido", erro: "Erro" };

export default function Transcriptions() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState("");
  const utils = trpc.useUtils();
  const { data: entries } = trpc.fieldEntries.listByProject.useQuery({ projectId });
  const [transcriptionMap, setTranscriptionMap] = useState<Record<number, {id: number; fieldEntryId: number; rawText: string | null; reviewedText: string | null; status: string; createdAt: Date}>>({});
  const transcribeAudio = trpc.transcriptions.transcribe.useMutation({
    onSuccess: (data, vars) => {
      utils.transcriptions.getByEntry.invalidate({ fieldEntryId: vars.fieldEntryId });
      notify.success("Transcricao concluida!");
    },
    onError: (e) => notify.error(`Erro: ${e.message}`),
  });
  const reviewTranscription = trpc.transcriptions.review.useMutation({
    onSuccess: () => { setEditingId(null); notify.success("Revisao salva!"); },
    onError: () => notify.error("Erro ao salvar revisao."),
  });
  const transcriptions = Object.values(transcriptionMap);
  const isLoading = false;

  const entriesWithAudio = entries?.filter(e => e.audioUrl) ?? [];

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Transcricoes de Audio</h1>
          <p className="text-muted-foreground mt-1">Transcreva automaticamente os audios coletados em campo usando Whisper. Revise e corrija o texto gerado.</p>
        </div>

        {entriesWithAudio.length > 0 && (
          <Card className="border-2 border-blue-200 bg-blue-50/50">
            <CardHeader><CardTitle className="text-lg text-blue-900">Audios disponiveis para transcricao</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {entriesWithAudio.map(entry => {
                const hasTranscription = transcriptions?.some(t => t.fieldEntryId === entry.id);
                const transcription = transcriptions?.find(t => t.fieldEntryId === entry.id);
                return (
                  <div key={entry.id} className="flex items-center gap-4 p-4 bg-white rounded-xl border border-blue-200">
                    <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0"><Mic className="w-5 h-5 text-blue-600" /></div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground">{entry.locationName ?? `Coleta #${entry.id}`}</p>
                      <p className="text-xs text-muted-foreground">{new Date(entry.createdAt).toLocaleDateString("pt-BR")}</p>
                    </div>
                    {hasTranscription ? (
                      <Badge className={`text-xs border ${statusColors[(transcription as {status: string} | undefined)?.status ?? "pendente"]}`}>{statusLabels[(transcription as {status: string} | undefined)?.status ?? "pendente"]}</Badge>
                    ) : (
                      <Button size="sm" onClick={() => transcribeAudio.mutate({ fieldEntryId: entry.id, audioUrl: entry.audioUrl! })} disabled={transcribeAudio.isPending} className="gap-2">
                        {transcribeAudio.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                        Transcrever
                      </Button>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Transcricoes realizadas</h2>
          {isLoading ? <div className="space-y-3">{[1,2].map(i => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}</div>
          : !transcriptions?.length ? (
            <Card className="border-2 border-dashed border-border"><CardContent className="p-8 text-center"><Mic className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-semibold text-foreground">Nenhuma transcricao ainda</p><p className="text-sm text-muted-foreground">Selecione um audio acima para iniciar a transcricao automatica.</p></CardContent></Card>
          ) : (
            <div className="space-y-4">
              {transcriptions.map(t => (
                <Card key={t.id} className="border-2 border-border">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div>
                        <p className="font-semibold text-foreground">Transcricao #{t.id}</p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1"><Clock className="w-3 h-3" /><span>{new Date(t.createdAt).toLocaleDateString("pt-BR")}</span></div>
                      </div>
                      <Badge className={`text-xs border ${statusColors[t.status]}`}>{statusLabels[t.status]}</Badge>
                    </div>
                    {t.status === "concluido" && (
                      <>
                        {editingId === t.id ? (
                          <div className="space-y-3">
                            <Textarea value={editText} onChange={e => setEditText(e.target.value)} rows={5} className="text-base" />
                            <div className="flex gap-2">
                              <Button size="sm" onClick={() => reviewTranscription.mutate({ id: t.id, reviewedText: editText })} className="gap-2"><Save className="w-4 h-4" />Salvar revisao</Button>
                              <Button size="sm" variant="outline" onClick={() => setEditingId(null)}>Cancelar</Button>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <div className="p-3 bg-muted/50 rounded-lg text-sm text-foreground leading-relaxed mb-3">{t.reviewedText ?? t.rawText}</div>
                            {t.reviewedText && <div className="flex items-center gap-1 text-xs text-green-700 mb-3"><CheckCircle2 className="w-3 h-3" />Revisado pelo pesquisador</div>}
                            <Button size="sm" variant="outline" onClick={() => { setEditingId(t.id); setEditText(t.reviewedText ?? t.rawText ?? ""); }} className="gap-2"><Edit3 className="w-4 h-4" />Revisar texto</Button>
                          </div>
                        )}
                      </>
                    )}
                    {t.status === "erro" && <div className="flex items-center gap-2 text-red-700 text-sm"><AlertCircle className="w-4 h-4" />Erro na transcricao. Tente novamente.</div>}
                    {t.status === "processando" && <div className="flex items-center gap-2 text-blue-700 text-sm"><Loader2 className="w-4 h-4 animate-spin" />Processando...</div>}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
