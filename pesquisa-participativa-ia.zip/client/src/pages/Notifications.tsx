import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, CheckCheck, Clock, Info, AlertCircle, CheckCircle2 } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

export default function Notifications() {
  const notify = useNotification();
  const utils = trpc.useUtils();
  const { data: notifications, isLoading } = trpc.notifications.list.useQuery();
  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: () => { utils.notifications.list.invalidate(); utils.notifications.unreadCount.invalidate(); },
  });
  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => { utils.notifications.list.invalidate(); utils.notifications.unreadCount.invalidate(); notify.success("Todas as notificacoes marcadas como lidas."); },
  });
  const unread = notifications?.filter(n => !n.read) ?? [];

  return (
    <PlatformLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold text-foreground">Notificacoes</h1><p className="text-muted-foreground mt-1">{unread.length} nao lidas</p></div>
          {unread.length > 0 && <Button variant="outline" onClick={() => markAllRead.mutate()} className="gap-2"><CheckCheck className="w-4 h-4" />Marcar todas como lidas</Button>}
        </div>
        {isLoading ? <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}</div>
        : !notifications?.length ? (
          <Card className="border-2 border-dashed border-border"><CardContent className="p-8 text-center"><Bell className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-semibold text-foreground">Nenhuma notificacao</p><p className="text-sm text-muted-foreground">Voce sera notificado sobre novos dados, ciclos concluidos e indicadores.</p></CardContent></Card>
        ) : (
          <div className="space-y-3">
            {notifications.map(n => (
              <div key={n.id} className={"flex items-start gap-4 p-4 rounded-xl border-2 transition-colors " + (n.read ? "bg-white border-border" : "bg-primary/5 border-primary/30")}>
                <div className={"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 " + (n.read ? "bg-muted" : "bg-primary/10")}>
                  <Bell className={"w-5 h-5 " + (n.read ? "text-muted-foreground" : "text-primary")} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground">{n.title}</p>
                  {n.message && <p className="text-sm text-muted-foreground mt-1">{n.message}</p>}
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2"><Clock className="w-3 h-3" /><span>{new Date(n.createdAt).toLocaleDateString("pt-BR")}</span></div>
                </div>
                {!n.read && (
                  <Button size="sm" variant="ghost" onClick={() => markRead.mutate({ id: n.id })} className="flex-shrink-0"><CheckCircle2 className="w-4 h-4" /></Button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </PlatformLayout>
  );
}
