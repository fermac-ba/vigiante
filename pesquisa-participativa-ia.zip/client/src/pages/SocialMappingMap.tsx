import { useState, useMemo } from "react";
import { useParams, useLocation } from "wouter";
import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapView } from "@/components/Map";
import { ArrowLeft, AlertTriangle, Shield, TrendingUp, MapPin, Filter, Layers } from "lucide-react";

const EIXO_COLORS: Record<number, string> = {
  1: "#E5243B", 2: "#DDA63A", 3: "#4C9F38", 4: "#C5192D", 5: "#FF3A21",
  6: "#26BDE2", 7: "#FCC30B", 8: "#A21942", 9: "#FD6925", 10: "#DD1367",
  11: "#FD9D24", 12: "#BF8B2E", 13: "#3F7E44", 14: "#0A97D9", 15: "#56C02B",
  16: "#00689D", 17: "#19486A",
};

const RISK_COLORS: Record<string, string> = {
  ameaca: "#EF4444",
  vulnerabilidade: "#F59E0B",
  resiliencia: "#22C55E",
};

const RISK_LABELS: Record<string, string> = {
  ameaca: "Ameaca",
  vulnerabilidade: "Vulnerabilidade",
  resiliencia: "Resiliencia",
};

export default function SocialMappingMap() {
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const [, navigate] = useLocation();

  const [filterRisk, setFilterRisk] = useState<string | null>(null);
  const [filterOds, setFilterOds] = useState<number | null>(null);
  const [selectedEntry, setSelectedEntry] = useState<number | null>(null);

  const { data: project } = trpc.projects.getById.useQuery({ id: projectId }, { enabled: !!projectId });
  const { data: mapData } = trpc.socialMapping.getProjectMapData.useQuery({ projectId }, { enabled: !!projectId });

  const filtered = useMemo(() => {
    if (!mapData) return [];
    return mapData.filter(({ entry, eixoData }) => {
      if (filterRisk && entry.riskClassification !== filterRisk) return false;
      if (filterOds && eixoData?.number !== filterOds) return false;
      return entry.latitude !== null && entry.longitude !== null;
    });
  }, [mapData, filterRisk, filterOds]);

  const odsInData = useMemo(() => {
    if (!mapData) return [];
    const seen = new Set<number>();
    const result: { number: number; title: string }[] = [];
    for (const { eixoData } of mapData) {
      if (eixoData && !seen.has(eixoData.number)) {
        seen.add(eixoData.number);
        result.push({ number: eixoData.number, title: eixoData.title });
      }
    }
    return result.sort((a, b) => a.number - b.number);
  }, [mapData]);

  const counts = useMemo(() => {
    const c = { ameaca: 0, vulnerabilidade: 0, resiliencia: 0, total: 0 };
    for (const { entry } of filtered) {
      c[entry.riskClassification as keyof typeof c] = (c[entry.riskClassification as keyof typeof c] as number) + 1;
      c.total += 1;
    }
    return c;
  }, [filtered]);

  const selectedEntryData = useMemo(() => {
    if (selectedEntry === null) return null;
    return mapData?.find(({ entry }) => entry.id === selectedEntry) ?? null;
  }, [selectedEntry, mapData]);

  return (
    <PlatformLayout projectId={projectId} projectName={project?.title}>
      <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-4">
        {/* Cabecalho */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate(`/projetos/${projectId}/cartografia`)} className="gap-1">
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Layers className="w-5 h-5 text-primary" />
              Mapa Agregado do Projeto
            </h1>
            <p className="text-sm text-muted-foreground">{project?.title} - todos os fatores georreferenciados</p>
          </div>
        </div>

        {/* Contadores */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="border shadow-sm">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-black text-foreground">{counts.total}</p>
              <p className="text-xs text-muted-foreground mt-0.5">Total de fatores</p>
            </CardContent>
          </Card>
          <Card className="border border-red-200 bg-red-50 shadow-sm">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-black text-red-700">{counts.ameaca}</p>
              <p className="text-xs text-red-600 mt-0.5">Ameacas</p>
            </CardContent>
          </Card>
          <Card className="border border-amber-200 bg-amber-50 shadow-sm">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-black text-amber-700">{counts.vulnerabilidade}</p>
              <p className="text-xs text-amber-600 mt-0.5">Vulnerabilidades</p>
            </CardContent>
          </Card>
          <Card className="border border-green-200 bg-green-50 shadow-sm">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-black text-green-700">{counts.resiliencia}</p>
              <p className="text-xs text-green-600 mt-0.5">Resiliencias</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Filtros */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="border shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-2">Tipo de Risco</p>
                  <div className="space-y-1.5">
                    {["ameaca", "vulnerabilidade", "resiliencia"].map(risk => (
                      <button
                        key={risk}
                        onClick={() => setFilterRisk(filterRisk === risk ? null : risk)}
                        className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold transition-all border ${filterRisk === risk
                          ? risk === "ameaca" ? "bg-red-100 border-red-400 text-red-800" : risk === "vulnerabilidade" ? "bg-amber-100 border-amber-400 text-amber-800" : "bg-green-100 border-green-400 text-green-800"
                          : "border-muted hover:bg-muted/50 text-muted-foreground"
                          }`}
                      >
                        {RISK_LABELS[risk]}
                      </button>
                    ))}
                  </div>
                </div>
                {odsInData.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground mb-2">ODS</p>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                      {odsInData.map(o => (
                        <button
                          key={o.number}
                          onClick={() => setFilterOds(filterOds === o.number ? null : o.number)}
                          className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold transition-all border flex items-center gap-2 ${filterOds === o.number ? "border-2 bg-muted" : "border-muted hover:bg-muted/50 text-muted-foreground"}`}
                          style={filterOds === o.number ? { borderColor: EIXO_COLORS[o.number] } : {}}
                        >
                          <span className="w-5 h-5 rounded flex items-center justify-center text-white text-xs font-black flex-shrink-0" style={{ backgroundColor: EIXO_COLORS[o.number] }}>{o.number}</span>
                          <span className="truncate">{o.title}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {(filterRisk || filterOds) && (
                  <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => { setFilterRisk(null); setFilterOds(null); }}>
                    Limpar filtros
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Detalhe do fator selecionado */}
            {selectedEntryData && (
              <Card className="border shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Fator Selecionado
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="text-sm font-bold text-foreground">{selectedEntryData.entry.factorName}</p>
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded flex items-center justify-center text-white text-xs font-black" style={{ backgroundColor: EIXO_COLORS[selectedEntryData.eixoData?.number ?? 1] }}>
                      {selectedEntryData.eixoData?.number}
                    </span>
                    <span className="text-xs text-muted-foreground">{selectedEntryData.eixoData?.title}</span>
                  </div>
                  <Badge className={`text-xs ${selectedEntryData.entry.riskClassification === "ameaca" ? "bg-red-100 text-red-700 border-red-300" : selectedEntryData.entry.riskClassification === "vulnerabilidade" ? "bg-amber-100 text-amber-700 border-amber-300" : "bg-green-100 text-green-700 border-green-300"}`}>
                    {RISK_LABELS[selectedEntryData.entry.riskClassification]}
                  </Badge>
                  <p className="text-xs text-muted-foreground">Importancia: {selectedEntryData.entry.importanceLevel}/10</p>
                  {selectedEntryData.entry.characterization && (
                    <p className="text-xs text-foreground line-clamp-3">{selectedEntryData.entry.characterization}</p>
                  )}
                  {selectedEntryData.entry.entryNotes && (
                    <p className="text-xs text-muted-foreground italic line-clamp-2">{selectedEntryData.entry.entryNotes}</p>
                  )}
                  {selectedEntryData.sessionData && (
                    <p className="text-xs text-muted-foreground">Sessao: {selectedEntryData.sessionData.territory}</p>
                  )}
                  <button onClick={() => setSelectedEntry(null)} className="text-xs text-primary hover:underline">Fechar</button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Mapa */}
          <div className="lg:col-span-3">
            <Card className="border shadow-sm">
              <CardContent className="p-0 overflow-hidden rounded-xl">
                <div className="h-[500px] md:h-[600px]">
                  {filtered.length === 0 && !mapData ? (
                    <div className="h-full flex items-center justify-center bg-muted/30">
                      <p className="text-sm text-muted-foreground">Carregando dados do mapa...</p>
                    </div>
                  ) : filtered.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center bg-muted/30 gap-2">
                      <MapPin className="w-8 h-8 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Nenhum fator georreferenciado com os filtros selecionados.</p>
                    </div>
                  ) : (
                    <MapView
                      onMapReady={(map) => {
                        const bounds = new google.maps.LatLngBounds();
                        filtered.forEach(({ entry, eixoData }) => {
                          if (entry.latitude === null || entry.longitude === null) return;
                          const pos = { lat: entry.latitude, lng: entry.longitude };
                          bounds.extend(pos);
                          const color = filterRisk ? RISK_COLORS[entry.riskClassification] : EIXO_COLORS[eixoData?.number ?? 1];
                          const marker = new google.maps.Marker({
                            position: pos,
                            map,
                            title: entry.factorName,
                            icon: {
                              path: google.maps.SymbolPath.CIRCLE,
                              scale: 10,
                              fillColor: color,
                              fillOpacity: 0.9,
                              strokeColor: "#ffffff",
                              strokeWeight: 2,
                            },
                          });
                          marker.addListener("click", () => setSelectedEntry(entry.id));
                        });
                        if (!bounds.isEmpty()) map.fitBounds(bounds);
                      }}
                    />
                  )}
                </div>
              </CardContent>
            </Card>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Clique em um marcador para ver os detalhes do fator. Cores por {filterRisk ? "tipo de risco" : "ODS"}.
            </p>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}
