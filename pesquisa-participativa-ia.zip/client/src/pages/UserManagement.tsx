import PlatformLayout from "@/components/PlatformLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import { Users, Shield, Clock } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

const roleLabels: Record<string, string> = { pesquisador_popular: "Pesquisador Popular", facilitador: "Facilitador", gestor: "Gestor", admin: "Administrador", user: "Usuario" };
const roleColors: Record<string, string> = { pesquisador_popular: "bg-blue-100 text-blue-800 border-blue-300", facilitador: "bg-amber-100 text-amber-800 border-amber-300", gestor: "bg-green-100 text-green-800 border-green-300", admin: "bg-purple-100 text-purple-800 border-purple-300", user: "bg-gray-100 text-gray-700 border-gray-300" };

export default function UserManagement() {
  const notify = useNotification();
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: users, isLoading } = trpc.users.list.useQuery();
  const updateRole = trpc.users.updateRole.useMutation({
    onSuccess: () => { utils.users.list.invalidate(); notify.success("Perfil atualizado!"); },
    onError: () => notify.error("Erro ao atualizar perfil."),
  });
  const userRole = user?.role ?? "user";
  if (!["gestor","admin"].includes(userRole)) return (
    <PlatformLayout><div className="p-6 text-center"><Shield className="w-12 h-12 text-muted-foreground mx-auto mb-3" /><p className="text-lg font-semibold">Acesso restrito</p><p className="text-muted-foreground">Apenas Gestores e Administradores podem gerenciar usuarios.</p></div></PlatformLayout>
  );
  return (
    <PlatformLayout>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div><h1 className="text-3xl font-bold text-foreground">Gerenciar Usuarios</h1><p className="text-muted-foreground mt-1">Gerencie os perfis de acesso dos membros da plataforma.</p></div>
        <Card className="border-2 border-amber-200 bg-amber-50/50">
          <CardContent className="p-4">
            <p className="text-sm text-amber-800 font-medium">Os perfis determinam as permissoes de acesso. Pesquisadores Populares coletam dados; Facilitadores coordenam e analisam; Gestores supervisionam e importam dados.</p>
          </CardContent>
        </Card>
        {isLoading ? <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}</div>
        : !users?.length ? (
          <Card className="border-2 border-dashed border-border"><CardContent className="p-8 text-center"><Users className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-semibold">Nenhum usuario cadastrado</p></CardContent></Card>
        ) : (
          <div className="space-y-3">
            {users.map(u => (
              <div key={u.id} className="flex items-center gap-4 p-4 bg-white border-2 border-border rounded-xl">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><span className="font-bold text-primary text-lg">{(u.name ?? "U").charAt(0).toUpperCase()}</span></div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground">{u.name ?? "Usuario"}</p>
                  {u.email && <p className="text-sm text-muted-foreground">{u.email}</p>}
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1"><Clock className="w-3 h-3" /><span>Desde {new Date(u.createdAt).toLocaleDateString("pt-BR")}</span></div>
                </div>
                <div className="flex-shrink-0">
                  <select
                    value={u.role}
                    onChange={e => {
                      const v = e.target.value;
                      if (["pesquisador_popular","facilitador","gestor","admin"].includes(v))
                        updateRole.mutate({ userId: u.id, role: v as "pesquisador_popular"|"facilitador"|"gestor" });
                    }}
                    className={"rounded-lg border-2 px-2 py-1.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-primary bg-background " + (roleColors[u.role] ?? "")}
                  >
                    <option value="pesquisador_popular">Pesquisador Popular</option>
                    <option value="facilitador">Facilitador</option>
                    <option value="gestor">Gestor</option>
                    {userRole === "admin" && <option value="admin">Administrador</option>}
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </PlatformLayout>
  );
}
