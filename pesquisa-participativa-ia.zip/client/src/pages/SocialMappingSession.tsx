import { useState, useMemo, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { MapView } from "@/components/Map";
import {
  Map, Plus, CheckCircle2, AlertTriangle, Shield, TrendingUp,
  ChevronRight, ChevronLeft, Globe, Target, Star, MapPin,
  Trash2, Brain, Loader2, ArrowLeft, Users, Calendar, Printer, MessageCircle, Send, X as XIcon
} from "lucide-react";
import { Streamdown } from "streamdown";
import { useNotification } from "@/contexts/NotificationContext";

// ─── Tipos ────────────────────────────────────────────────────────────────────
type Step = "eixo" | "fator" | "grupo_focal" | "risco" | "importancia" | "localizacao" | "confirmacao";

const STEPS: { id: Step; label: string; icon: React.ElementType }[] = [
  { id: "eixo", label: "Selecionar Eixo", icon: Globe },
  { id: "fator", label: "Selecionar Fator", icon: Target },
  { id: "grupo_focal", label: "Grupo Focal", icon: Users },
  { id: "risco", label: "Classificar Risco", icon: AlertTriangle },
  { id: "importancia", label: "Nivel de Importancia", icon: Star },
  { id: "localizacao", label: "Georreferenciar", icon: MapPin },
  { id: "confirmacao", label: "Confirmar", icon: CheckCircle2 },
];

const RISK_OPTIONS = [
  { value: "ameaca", label: "Ameaca", description: "Fator que representa perigo ou dano potencial ao territorio", icon: AlertTriangle, color: "border-red-400 bg-red-50 text-red-800", activeColor: "border-red-600 bg-red-100 ring-2 ring-red-400" },
  { value: "vulnerabilidade", label: "Vulnerabilidade", description: "Fator que fragiliza a capacidade de resposta do territorio", icon: Shield, color: "border-amber-400 bg-amber-50 text-amber-800", activeColor: "border-amber-600 bg-amber-100 ring-2 ring-amber-400" },
  { value: "resiliencia", label: "Resiliencia", description: "Fator que fortalece a capacidade de adaptacao e recuperacao", icon: TrendingUp, color: "border-green-400 bg-green-50 text-green-800", activeColor: "border-green-600 bg-green-100 ring-2 ring-green-400" },
];

const EIXO_COLORS: Record<number, string> = {
  1: "#1A6B4A", 2: "#2563EB", 3: "#7C3AED", 4: "#DC2626", 5: "#D97706", 6: "#0891B2",
};

export default function SocialMappingSession() {
  const notify = useNotification();
  const { id, sessionId } = useParams<{ id: string; sessionId: string }>();
  const projectId = parseInt(id ?? "0");
  const sessId = parseInt(sessionId ?? "0");
  const [, navigate] = useLocation();

  // Estado do formulario guiado
  const [step, setStep] = useState<Step>("eixo");
  const [selectedEixo, setSelectedEixo] = useState<number | null>(null);
  const [selectedFactor, setSelectedFactor] = useState<{ id: number; name: string; description?: string | null } | null>(null);
  const [characterization, setCharacterization] = useState("");
  const [riskClassification, setRiskClassification] = useState<"ameaca" | "vulnerabilidade" | "resiliencia" | null>(null);
  const [importanceLevel, setImportanceLevel] = useState<number>(5);
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [locationName, setLocationName] = useState("");
  const [aiAnalysis, setAiAnalysis] = useState("");
  const [analyzingSession, setAnalyzingSession] = useState(false);
  const [sessionAnalysis, setSessionAnalysis] = useState("");
  const [analysisReview, setAnalysisReview] = useState("");
  const [editingReview, setEditingReview] = useState(false);
  const [savingReview, setSavingReview] = useState(false);
  const [entryNotes, setEntryNotes] = useState("");
  const [showSummary, setShowSummary] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [confirmClose, setConfirmClose] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [editingNoteText, setEditingNoteText] = useState("");
  const [editingDate, setEditingDate] = useState(false);
  const [editDateValue, setEditDateValue] = useState("");
  const [commentingEntryId, setCommentingEntryId] = useState<number | null>(null);
  const [commentText, setCommentText] = useState("");
  const [expandedComments, setExpandedComments] = useState<Set<number>>(new Set());

  // Dados
  const { data: session, refetch: refetchSession } = trpc.socialMapping.getSession.useQuery({ id: sessId }, { enabled: !!sessId });
  // Inicializar análise LLM a partir do campo persistido na sessão
  useEffect(() => {
    if (session?.analysisText && !sessionAnalysis) {
      setSessionAnalysis(session.analysisText);
    }
  }, [session?.analysisText]);
  useEffect(() => {
    if (session?.analysisReview !== undefined && session?.analysisReview !== null) {
      setAnalysisReview(session.analysisReview);
    }
  }, [session?.analysisReview]);
  const { data: project } = trpc.projects.getById.useQuery({ id: projectId }, { enabled: !!projectId });
  const { data: eixosList } = trpc.eixos.list.useQuery();
  const { data: factors, isLoading: loadingFactors } = trpc.eixos.getFactores.useQuery(
    { eixoId: selectedEixo ?? 0 },
    { enabled: !!selectedEixo }
  );
  const { data: entries, refetch: refetchEntries } = trpc.socialMapping.listEntries.useQuery(
    { sessionId: sessId },
    { enabled: !!sessId }
  );
  const addCommentMutation = trpc.socialMapping.addEntryComment.useMutation({
    onSuccess: () => { setCommentText(""); setCommentingEntryId(null); refetchEntries(); },
    onError: () => notify.error("Erro ao adicionar comentário."),
  });
  const deleteCommentMutation = trpc.socialMapping.deleteEntryComment.useMutation({
    onSuccess: () => refetchEntries(),
    onError: () => notify.error("Erro ao remover comentário."),
  });

  const selectedEixoData = useMemo(() => eixosList?.find(e => e.id === selectedEixo), [eixosList, selectedEixo]);

  const createEntry = trpc.socialMapping.createEntry.useMutation({
    onSuccess: () => {
      notify.success("Fator registrado com sucesso!");
      refetchEntries();
      resetForm();
    },
    onError: () => notify.error("Erro ao registrar fator."),
  });

  const deleteEntry = trpc.socialMapping.deleteEntry.useMutation({
    onSuccess: () => { notify.success("Fator removido."); refetchEntries(); },
  });

  const updateSession = trpc.socialMapping.updateSession.useMutation({
    onSuccess: () => { notify.success("Sessao atualizada!"); refetchSession(); setEditingDate(false); },
    onError: () => notify.error("Erro ao atualizar sessao."),
  });
  const handleSaveDate = () => {
    if (!editDateValue) return;
    updateSession.mutate({ id: sessId, sessionDate: editDateValue });
  };
  const closeSessionMutation = trpc.socialMapping.closeSession.useMutation({
    onSuccess: () => { notify.success("Sessao encerrada com sucesso!"); refetchSession(); setShowSummary(true); },
    onError: () => notify.error("Erro ao encerrar sessao."),
  });
  const { data: sessionSummary, refetch: refetchSummary } = trpc.socialMapping.getSessionSummary.useQuery(
    { id: sessId },
    { enabled: showSummary && !!sessId }
  );
  const generatePdfMutation = trpc.socialMapping.generateSessionPdf.useMutation({
    onSuccess: (data) => {
      const bytes = Uint8Array.from(atob(data.pdfBase64), c => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
      setGeneratingPdf(false);
    },
    onError: () => { notify.error("Erro ao gerar relatorio PDF."); setGeneratingPdf(false); },
  });

  const updateEntryNotesMutation = trpc.socialMapping.updateEntryNotes.useMutation({
    onSuccess: () => { setEditingNoteId(null); setEditingNoteText(""); refetchSummary(); },
    onError: () => notify.error("Erro ao salvar observacao."),
  });
  const analyzeSessionMutation = trpc.socialMapping.analyzeSession.useMutation({
    onSuccess: (data) => { setSessionAnalysis(typeof data.analysis === "string" ? data.analysis : ""); setAnalyzingSession(false); },
    onError: () => { notify.error("Erro na analise."); setAnalyzingSession(false); },
  });
  const updateAnalysisReviewMutation = trpc.socialMapping.updateAnalysisReview.useMutation({
    onSuccess: () => {
      notify.success("Revisao editorial salva com sucesso.");
      setEditingReview(false);
      setSavingReview(false);
      refetchSession();
    },
    onError: () => { notify.error("Erro ao salvar revisao editorial."); setSavingReview(false); },
  });

  const resetForm = () => {
    setStep("eixo");
    setSelectedEixo(null);
    setSelectedFactor(null);
    setCharacterization("");
    setRiskClassification(null);
    setImportanceLevel(5);
    setLatitude(null);
    setLongitude(null);
    setLocationName("");
    setAiAnalysis("");
    setEntryNotes("");
  };

  const handleConfirm = () => {
    if (!selectedEixo || !selectedFactor || !riskClassification) return;
    createEntry.mutate({
      sessionId: sessId,
      projectId,
      eixoId: selectedEixo,
      factorId: selectedFactor.id,
      factorName: selectedFactor.name,
      characterization: characterization || undefined,
      riskClassification,
      importanceLevel,
      latitude: latitude ?? undefined,
      longitude: longitude ?? undefined,
      locationName: locationName || undefined,
      entryNotes: entryNotes || undefined,
    });
  };

  const handleMapClick = (lat: number, lng: number) => {
    setLatitude(lat);
    setLongitude(lng);
  };

  const handleAnalyzeSession = () => {
    setAnalyzingSession(true);
    analyzeSessionMutation.mutate({ sessionId: sessId });
  };

  const stepIndex = STEPS.findIndex(s => s.id === step);
  const canGoNext = () => {
    if (step === "eixo") return !!selectedEixo;
    if (step === "fator") return !!selectedFactor;
    if (step === "grupo_focal") return true;
    if (step === "risco") return !!riskClassification;
    if (step === "importancia") return importanceLevel >= 0 && importanceLevel <= 10;
    if (step === "localizacao") return true;
    return true;
  };

  const goNext = () => {
    const next = STEPS[stepIndex + 1];
    if (next) setStep(next.id);
  };
  const goPrev = () => {
    const prev = STEPS[stepIndex - 1];
    if (prev) setStep(prev.id);
  };

  return (
    <PlatformLayout projectId={projectId} projectName={project?.title}>
      <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
        {/* Cabecalho da sessao */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate(`/projetos/${projectId}/cartografia`)} className="gap-1">
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground">{session?.territory ?? "Carregando..."}</h1>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />Monitor: {session?.monitorName}</span>
              {editingDate ? (
                <span className="flex items-center gap-1">
                  <input
                    type="date"
                    className="text-xs border rounded px-1 py-0.5 bg-background text-foreground"
                    value={editDateValue}
                    max={new Date().toISOString().split("T")[0]}
                    onChange={e => setEditDateValue(e.target.value)}
                    autoFocus
                  />
                  <button className="text-xs text-primary font-semibold" onClick={handleSaveDate} disabled={updateSession.isPending}>Salvar</button>
                  <button className="text-xs text-muted-foreground" onClick={() => setEditingDate(false)}>Cancelar</button>
                </span>
              ) : (
                <span
                  className="flex items-center gap-1 cursor-pointer hover:text-primary transition-colors"
                  title="Clique para editar a data"
                  onClick={() => { setEditDateValue(session?.sessionDate ? new Date(session.sessionDate).toISOString().split("T")[0] : new Date().toISOString().split("T")[0]); setEditingDate(true); }}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  {session?.sessionDate ? new Date(session.sessionDate).toLocaleDateString("pt-BR") : "Definir data"}
                </span>
              )}
              <Badge className={session?.status === "concluida" ? "bg-green-100 text-green-800 border-green-300" : "bg-blue-100 text-blue-800 border-blue-300"}>
                {session?.status === "concluida" ? "Concluida" : "Em andamento"}
              </Badge>
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {session?.status !== "concluida" && (entries?.length ?? 0) > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setConfirmClose(true)}
                disabled={closeSessionMutation.isPending}
                className="gap-1 text-green-700 border-green-300 hover:bg-green-50"
              >
                {closeSessionMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                Encerrar Sessao
              </Button>
            )}
            {session?.status === "concluida" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => { setShowSummary(true); refetchSummary(); }}
                className="gap-1 text-green-700 border-green-300 hover:bg-green-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                Ver Resumo
              </Button>
            )}
            {(entries?.length ?? 0) > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(`/projetos/${projectId}/cartografia/${sessId}/imprimir`, "_blank")}
                className="gap-1 text-blue-700 border-blue-300 hover:bg-blue-50"
              >
                <Printer className="w-4 h-4" />
                Imprimir / PDF
              </Button>
            )}
            {(entries?.length ?? 0) > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleAnalyzeSession}
                disabled={analyzingSession}
                className="gap-1 text-purple-700 border-purple-300 hover:bg-purple-50"
              >
                {analyzingSession ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                Analisar com IA
              </Button>
            )}
          </div>
        </div>

        {/* Analise de IA da sessao */}
        {sessionAnalysis && (
          <Card className="border-purple-200 bg-purple-50">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2 text-purple-800">
                <Brain className="w-4 h-4" />
                Sintese Analitica da Sessao (IA)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Streamdown className="text-sm text-purple-900 prose prose-sm max-w-none">{sessionAnalysis}</Streamdown>
            </CardContent>
          </Card>
        )}
        {/* Revisao editorial da sintese LLM */}
        {sessionAnalysis && (
          <Card className="border-green-200 bg-green-50">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2 text-green-800">
                  <CheckCircle2 className="w-4 h-4" />
                  Revisao Editorial da Sintese
                </CardTitle>
                {!editingReview && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-xs border-green-300 text-green-700 hover:bg-green-100"
                    onClick={() => setEditingReview(true)}
                  >
                    {analysisReview ? "Editar revisao" : "Adicionar revisao"}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {editingReview ? (
                <div className="space-y-3">
                  <p className="text-xs text-green-700">
                    Registre concordancias, discordancias, complementacoes ou observacoes sobre a sintese gerada pela IA.
                    Este campo sera incluido no PDF e na impressao do relatorio.
                  </p>
                  <Textarea
                    value={analysisReview}
                    onChange={e => setAnalysisReview(e.target.value)}
                    placeholder="Ex: A sintese identifica corretamente as principais vulnerabilidades. Complemento: o fator X esta diretamente relacionado ao contexto historico de..."
                    rows={5}
                    className="bg-white border-green-300 focus:border-green-500 text-sm"
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="bg-green-700 hover:bg-green-800 text-white"
                      disabled={savingReview}
                      onClick={() => {
                        setSavingReview(true);
                        updateAnalysisReviewMutation.mutate({ sessionId: sessId, analysisReview });
                      }}
                    >
                      {savingReview ? <><Loader2 className="w-3 h-3 mr-1 animate-spin" />Salvando...</> : "Salvar revisao"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-green-300 text-green-700"
                      onClick={() => { setEditingReview(false); setAnalysisReview(session?.analysisReview ?? ""); }}
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              ) : analysisReview ? (
                <p className="text-sm text-green-900 whitespace-pre-wrap leading-relaxed">{analysisReview}</p>
              ) : (
                <p className="text-sm text-green-700 italic">
                  Nenhuma revisao editorial registrada. Clique em "Adicionar revisao" para complementar a sintese gerada pela IA.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Formulario guiado */}
          <div className="lg:col-span-3 space-y-4">
            {/* Indicador de progresso */}
            <div className="flex items-center gap-1 overflow-x-auto pb-2">
              {STEPS.map((s, i) => {
                const Icon = s.icon;
                const isActive = s.id === step;
                const isDone = i < stepIndex;
                return (
                  <div key={s.id} className="flex items-center gap-1 flex-shrink-0">
                    <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium transition-all ${isActive ? "bg-primary text-primary-foreground" : isDone ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"}`}>
                      <Icon className="w-3 h-3" />
                      <span className="hidden sm:inline">{s.label}</span>
                    </div>
                    {i < STEPS.length - 1 && <ChevronRight className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
                  </div>
                );
              })}
            </div>

            {/* Conteudo do passo */}
            <Card className="border shadow-sm">
              <CardContent className="p-5">
                {/* Passo 1: Selecionar ODS */}
                {step === "eixo" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Selecione o Eixo Tematico</h2>
                      <p className="text-sm text-muted-foreground">Escolha o Eixo Tematico Gerador da metodologia PICAPS relacionado ao tema a ser investigado neste territorio.</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {eixosList?.map(e => (
                        <button
                          key={e.id}
                          onClick={() => { setSelectedEixo(e.id); setSelectedFactor(null); }}
                          className={`p-3 rounded-xl border-2 text-left transition-all hover:scale-[1.01] ${selectedEixo === e.id ? "border-primary ring-2 ring-primary/30 shadow-md" : "border-muted hover:border-primary/40"}`}
                          style={selectedEixo === e.id ? { backgroundColor: EIXO_COLORS[e.number] + "18", borderColor: EIXO_COLORS[e.number] } : {}}
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-black flex-shrink-0" style={{ backgroundColor: EIXO_COLORS[e.number] }}>
                              {e.number}
                            </div>
                            <div>
                              <div className="text-xs font-bold leading-tight" style={{ color: EIXO_COLORS[e.number] }}>{e.iconEmoji} Eixo {e.number}</div>
                              <div className="text-xs text-foreground font-semibold leading-tight line-clamp-2">{e.title}</div>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                    {selectedEixoData && (
                      <div className="p-3 rounded-xl border" style={{ backgroundColor: EIXO_COLORS[selectedEixoData.number] + "15", borderColor: EIXO_COLORS[selectedEixoData.number] + "60" }}>
                        <p className="text-sm font-semibold" style={{ color: EIXO_COLORS[selectedEixoData.number] }}>{selectedEixoData.iconEmoji} Eixo {selectedEixoData.number} - {selectedEixoData.title}</p>
                        {selectedEixoData.contradicaoCentral && (
                          <p className="text-xs text-muted-foreground mt-1"><span className="font-semibold">Contradicao central:</span> {selectedEixoData.contradicaoCentral}</p>
                        )}
                        {selectedEixoData.focoPedagogico && (
                          <p className="text-xs text-muted-foreground mt-0.5"><span className="font-semibold">Foco pedagogico:</span> {selectedEixoData.focoPedagogico}</p>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Passo 2: Selecionar Fator */}
                {step === "fator" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Selecione o Fator</h2>
                      <p className="text-sm text-muted-foreground">Escolha o fator relacionado ao Eixo {selectedEixoData?.number} que sera investigado no grupo focal.</p>
                    </div>
                    {loadingFactors ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-primary" />
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                        {factors?.map(f => (
                          <button
                            key={f.id}
                            onClick={() => setSelectedFactor(f)}
                            className={`w-full text-left p-3.5 rounded-xl border-2 transition-all ${selectedFactor?.id === f.id ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "border-muted hover:border-primary/40 hover:bg-muted/50"}`}
                          >
                            <p className="font-semibold text-sm text-foreground">{f.name}</p>
                            {(f as any).description && <p className="text-xs text-muted-foreground mt-0.5">{(f as any).description}</p>}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Passo 3: Grupo Focal */}
                {step === "grupo_focal" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Grupo Focal - Caracterizacao</h2>
                      <p className="text-sm text-muted-foreground">Conduza o grupo focal com a sociedade civil para caracterizar a situacao do fator <strong>{selectedFactor?.name}</strong> neste territorio. Registre os principais elementos identificados.</p>
                    </div>
                    <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                      <p className="text-xs font-semibold text-blue-700 mb-1">Fator selecionado</p>
                      <p className="text-sm font-bold text-blue-900">{selectedFactor?.name}</p>
                      {selectedFactor?.description && <p className="text-xs text-blue-700 mt-0.5">{selectedFactor.description}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <Label className="font-semibold">Caracterizacao do fator no territorio</Label>
                      <Textarea
                        placeholder="Descreva como este fator se manifesta neste territorio. O que a comunidade identifica? Quais sao as principais situacoes observadas? Quem e afetado?"
                        value={characterization}
                        onChange={e => setCharacterization(e.target.value)}
                        rows={6}
                        className="text-sm"
                      />
                      <p className="text-xs text-muted-foreground">Registre as falas e percepcoes da comunidade durante o grupo focal.</p>
                    </div>
                  </div>
                )}

                {/* Passo 4: Classificar Risco */}
                {step === "risco" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Classificacao de Risco</h2>
                      <p className="text-sm text-muted-foreground">Com base na caracterizacao realizada, classifique como este fator se apresenta no territorio.</p>
                    </div>
                    <div className="space-y-3">
                      {RISK_OPTIONS.map(opt => {
                        const Icon = opt.icon;
                        const isSelected = riskClassification === opt.value;
                        return (
                          <button
                            key={opt.value}
                            onClick={() => setRiskClassification(opt.value as any)}
                            className={`w-full text-left p-4 rounded-xl border-2 transition-all ${isSelected ? opt.activeColor : opt.color + " hover:opacity-80"}`}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isSelected ? "bg-white/60" : "bg-white/40"}`}>
                                <Icon className="w-5 h-5" />
                              </div>
                              <div>
                                <p className="font-bold text-base">{opt.label}</p>
                                <p className="text-xs mt-0.5 opacity-80">{opt.description}</p>
                              </div>
                              {isSelected && <CheckCircle2 className="w-5 h-5 ml-auto flex-shrink-0" />}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Passo 5: Nivel de Importancia */}
                {step === "importancia" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Nivel de Importancia</h2>
                      <p className="text-sm text-muted-foreground">Em uma escala de 0 a 10, qual e a importancia deste cenario para o territorio?</p>
                    </div>
                    <div className="space-y-6">
                      <div className="text-center">
                        <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full text-4xl font-black border-4 ${importanceLevel >= 8 ? "border-red-400 bg-red-50 text-red-700" : importanceLevel >= 5 ? "border-amber-400 bg-amber-50 text-amber-700" : "border-green-400 bg-green-50 text-green-700"}`}>
                          {importanceLevel}
                        </div>
                        <p className="text-sm text-muted-foreground mt-2">
                          {importanceLevel >= 8 ? "Muito alta importancia" : importanceLevel >= 5 ? "Media importancia" : "Baixa importancia"}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <input
                          type="range"
                          min={0}
                          max={10}
                          step={1}
                          value={importanceLevel}
                          onChange={e => setImportanceLevel(parseInt(e.target.value))}
                          className="w-full accent-primary h-3 cursor-pointer"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground font-medium">
                          <span>0 - Sem importancia</span>
                          <span>5 - Media</span>
                          <span>10 - Maxima</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-11 gap-1">
                        {Array.from({ length: 11 }, (_, i) => (
                          <button
                            key={i}
                            onClick={() => setImportanceLevel(i)}
                            className={`h-8 rounded-lg text-xs font-bold transition-all ${importanceLevel === i ? "bg-primary text-primary-foreground scale-110 shadow-md" : "bg-muted hover:bg-muted/80 text-muted-foreground"}`}
                          >
                            {i}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Passo 6: Georreferenciar */}
                {step === "localizacao" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Georreferenciamento</h2>
                      <p className="text-sm text-muted-foreground">Marque no mapa a localizacao onde este fator foi identificado no territorio. Clique no mapa para definir o ponto.</p>
                    </div>
                    <div className="h-64 rounded-xl overflow-hidden border border-border">
                      <MapView
                        className="h-64"
                        initialCenter={{ lat: -15.7801, lng: -47.9292 }}
                        onMapReady={(map) => {
                          let markerEl: google.maps.marker.AdvancedMarkerElement | null = null;
                          map.addListener("click", (e: google.maps.MapMouseEvent) => {
                            if (e.latLng) {
                              const lat = e.latLng.lat();
                              const lng = e.latLng.lng();
                              handleMapClick(lat, lng);
                              if (markerEl) markerEl.map = null;
                              try {
                                markerEl = new google.maps.marker.AdvancedMarkerElement({ position: { lat, lng }, map, title: selectedFactor?.name ?? "Fator" });
                              } catch (_) {
                                new (google.maps as any).Marker({ position: { lat, lng }, map, title: selectedFactor?.name });
                              }
                            }
                          });
                        }}
                        onMapError={() => {
                          /* mapa indisponivel - usuario pode continuar sem georreferenciamento */
                        }}
                      />
                    </div>
                    {latitude && longitude && (
                      <div className="p-3 rounded-xl bg-green-50 border border-green-200 flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-green-600 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="text-xs font-semibold text-green-700">Ponto marcado</p>
                          <p className="text-xs text-green-600">Lat: {latitude.toFixed(6)}, Lng: {longitude.toFixed(6)}</p>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => { setLatitude(null); setLongitude(null); }} className="text-green-700 h-7 px-2">Remover</Button>
                      </div>
                    )}
                    <div className="space-y-1.5">
                      <Label className="font-semibold">Nome do local (opcional)</Label>
                      <Input
                        placeholder="Ex: Praca Central, Rua das Flores, Escola Municipal..."
                        value={locationName}
                        onChange={e => setLocationName(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {/* Passo 7: Confirmacao */}
                {step === "confirmacao" && (
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-lg font-bold text-foreground mb-1">Confirmar Registro</h2>
                      <p className="text-sm text-muted-foreground">Revise as informacoes antes de salvar o fator mapeado.</p>
                    </div>
                    <div className="space-y-3">
                      <div className="p-3 rounded-xl bg-muted/50 border">
                        <p className="text-xs font-semibold text-muted-foreground mb-1">Eixo Tematico</p>
                        <p className="font-bold text-foreground">{selectedEixoData?.iconEmoji} Eixo {selectedEixoData?.number} - {selectedEixoData?.title}</p>
                      </div>
                      <div className="p-3 rounded-xl bg-muted/50 border">
                        <p className="text-xs font-semibold text-muted-foreground mb-1">Fator</p>
                        <p className="font-bold text-foreground">{selectedFactor?.name}</p>
                      </div>
                      {characterization && (
                        <div className="p-3 rounded-xl bg-muted/50 border">
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Caracterizacao</p>
                          <p className="text-sm text-foreground line-clamp-3">{characterization}</p>
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-3">
                        <div className={`p-3 rounded-xl border ${riskClassification === "ameaca" ? "bg-red-50 border-red-200" : riskClassification === "vulnerabilidade" ? "bg-amber-50 border-amber-200" : "bg-green-50 border-green-200"}`}>
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Classificacao</p>
                          <p className={`font-bold capitalize ${riskClassification === "ameaca" ? "text-red-700" : riskClassification === "vulnerabilidade" ? "text-amber-700" : "text-green-700"}`}>{riskClassification}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Importancia</p>
                          <p className="font-bold text-blue-700">{importanceLevel}/10</p>
                        </div>
                      </div>
                      {latitude && longitude && (
                        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Localizacao</p>
                          <p className="text-sm text-emerald-700">{locationName || `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}`}</p>
                        </div>
                      )}
                      <div className="space-y-1.5">
                        <Label className="font-semibold text-sm">Observacoes do monitor (opcional)</Label>
                        <Textarea
                          placeholder="Registre observacoes adicionais sobre este fator: contexto do grupo focal, falas relevantes, situacoes especificas observadas..."
                          value={entryNotes}
                          onChange={e => setEntryNotes(e.target.value)}
                          rows={3}
                          className="text-sm"
                        />
                        <p className="text-xs text-muted-foreground">Estas observacoes serao incluidas no relatorio da sessao.</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Navegacao entre passos */}
                <div className="flex gap-2 mt-6 pt-4 border-t">
                  {stepIndex > 0 && (
                    <Button variant="outline" onClick={goPrev} className="gap-1">
                      <ChevronLeft className="w-4 h-4" />
                      Anterior
                    </Button>
                  )}
                  <div className="flex-1" />
                  {step !== "confirmacao" ? (
                    <Button onClick={goNext} disabled={!canGoNext()} className="gap-1 font-semibold">
                      Proximo
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  ) : (
                    <Button
                      onClick={handleConfirm}
                      disabled={createEntry.isPending}
                      className="gap-1 font-semibold bg-green-600 hover:bg-green-700"
                    >
                      {createEntry.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                      Salvar Fator
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Painel lateral: fatores registrados */}
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">Fatores Registrados</h2>
              <Badge variant="secondary" className="font-bold">{entries?.length ?? 0}</Badge>
            </div>
            {!entries?.length ? (
              <Card className="border-dashed border-2 border-muted">
                <CardContent className="py-8 text-center">
                  <Target className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Nenhum fator registrado ainda.</p>
                  <p className="text-xs text-muted-foreground mt-1">Complete o formulario ao lado para adicionar.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                {entries.map(({ entry, eixoData, factor }: any) => {
                  const risk = RISK_OPTIONS.find(r => r.value === entry.riskClassification);
                  const Icon = risk?.icon ?? AlertTriangle;
                  return (
                    <Card key={entry.id} className="border shadow-sm">
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 mb-1">
                              {eixoData?.iconEmoji && <span className="text-sm">{eixoData.iconEmoji}</span>}
                              <span className="text-xs font-bold text-muted-foreground">Eixo {eixoData?.number}</span>
                              <Badge className={`text-xs ${entry.riskClassification === "ameaca" ? "bg-red-100 text-red-700 border-red-300" : entry.riskClassification === "vulnerabilidade" ? "bg-amber-100 text-amber-700 border-amber-300" : "bg-green-100 text-green-700 border-green-300"}`}>
                                <Icon className="w-2.5 h-2.5 mr-0.5" />
                                {risk?.label}
                              </Badge>
                            </div>
                            <p className="text-sm font-semibold text-foreground truncate">{entry.factorName}</p>
                            {entry.characterization && (
                              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{entry.characterization}</p>
                            )}
                            <div className="flex items-center gap-2 mt-1.5">
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3 text-amber-500" />
                                <span className="text-xs font-bold text-foreground">{entry.importanceLevel}/10</span>
                              </div>
                              {entry.latitude && (
                                <div className="flex items-center gap-1">
                                  <MapPin className="w-3 h-3 text-emerald-500" />
                                  <span className="text-xs text-muted-foreground">Georreferenciado</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <button
                              onClick={() => {
                                const newSet = new Set(expandedComments);
                                if (newSet.has(entry.id)) { newSet.delete(entry.id); } else { newSet.add(entry.id); }
                                setExpandedComments(newSet);
                              }}
                              className="text-muted-foreground hover:text-primary transition-colors p-1 relative"
                              title="Comentários"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              {(entry as any).comments?.length > 0 && (
                                <span className="absolute -top-0.5 -right-0.5 bg-primary text-primary-foreground text-[9px] rounded-full w-3.5 h-3.5 flex items-center justify-center font-bold">
                                  {(entry as any).comments?.length}
                                </span>
                              )}
                            </button>
                            <button
                              onClick={() => deleteEntry.mutate({ id: entry.id })}
                              className="text-muted-foreground hover:text-red-500 transition-colors p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        {/* Painel de comentários */}
                        {expandedComments.has(entry.id) && (
                          <div className="mt-2 pt-2 border-t border-border/50 space-y-2">
                            {((entry as any).comments ?? []).map((c: any) => (
                              <div key={c.id} className="flex items-start gap-1.5 group">
                                <div className="flex-1 bg-muted/40 rounded-lg px-2 py-1.5">
                                  <div className="flex items-center justify-between mb-0.5">
                                    <span className="text-[10px] font-semibold text-primary">{c.authorName}</span>
                                    <span className="text-[10px] text-muted-foreground">{new Date(c.createdAt).toLocaleDateString("pt-BR")}</span>
                                  </div>
                                  <p className="text-xs text-foreground">{c.content}</p>
                                </div>
                                <button
                                  onClick={() => deleteCommentMutation.mutate({ commentId: c.id })}
                                  className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all p-0.5 mt-1 flex-shrink-0"
                                >
                                  <XIcon className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                            {commentingEntryId === entry.id ? (
                              <div className="flex gap-1.5">
                                <Textarea
                                  value={commentText}
                                  onChange={e => setCommentText(e.target.value)}
                                  placeholder="Adicionar comentário..."
                                  className="text-xs min-h-[60px] flex-1 resize-none"
                                  onKeyDown={e => {
                                    if (e.key === "Enter" && !e.shiftKey) {
                                      e.preventDefault();
                                      if (commentText.trim()) {
                                        addCommentMutation.mutate({ entryId: entry.id, sessionId: sessId, projectId, content: commentText.trim() });
                                      }
                                    }
                                  }}
                                />
                                <div className="flex flex-col gap-1">
                                  <button
                                    onClick={() => {
                                      if (commentText.trim()) {
                                        addCommentMutation.mutate({ entryId: entry.id, sessionId: sessId, projectId, content: commentText.trim() });
                                      }
                                    }}
                                    disabled={!commentText.trim() || addCommentMutation.isPending}
                                    className="bg-primary text-primary-foreground rounded-lg p-1.5 hover:bg-primary/90 disabled:opacity-50"
                                  >
                                    {addCommentMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                                  </button>
                                  <button
                                    onClick={() => { setCommentingEntryId(null); setCommentText(""); }}
                                    className="bg-muted text-muted-foreground rounded-lg p-1.5 hover:bg-muted/80"
                                  >
                                    <XIcon className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <button
                                onClick={() => setCommentingEntryId(entry.id)}
                                className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1 transition-colors"
                              >
                                <Plus className="w-3 h-3" />
                                Adicionar comentário
                              </button>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal de Confirmacao de Encerramento */}
      {confirmClose && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setConfirmClose(false)}>
          <div className="bg-background rounded-2xl shadow-2xl max-w-sm w-full" onClick={e => e.stopPropagation()}>
            <div className="p-6 space-y-4">
              <h2 className="text-lg font-bold text-foreground">Encerrar Sessao?</h2>
              <p className="text-sm text-muted-foreground">Ao encerrar a sessao, novos fatores nao poderao ser adicionados. Esta acao nao pode ser desfeita.</p>
              <p className="text-sm font-semibold text-foreground">{entries?.length ?? 0} fator{(entries?.length ?? 0) !== 1 ? "es" : ""} registrado{(entries?.length ?? 0) !== 1 ? "s" : ""} serao consolidados.</p>
              <div className="flex gap-2 pt-2">
                <Button
                  className="flex-1 gap-1"
                  onClick={() => { setConfirmClose(false); closeSessionMutation.mutate({ id: sessId }); }}
                  disabled={closeSessionMutation.isPending}
                >
                  {closeSessionMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Confirmar Encerramento
                </Button>
                <Button variant="outline" onClick={() => setConfirmClose(false)} className="flex-1">
                  Cancelar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Resumo da Sessao */}
      {showSummary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowSummary(false)}>
          <div className="bg-background rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="p-6 space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-foreground">Resumo da Sessao</h2>
                <button onClick={() => setShowSummary(false)} className="text-muted-foreground hover:text-foreground text-2xl leading-none">&times;</button>
              </div>
              {sessionSummary ? (
                <>
                  <div className="p-3 rounded-xl bg-muted/50 border space-y-1">
                    <p className="text-sm font-bold text-foreground">{sessionSummary.session?.territory ?? session?.territory}</p>
                    <p className="text-xs text-muted-foreground">Monitor: {sessionSummary.session?.monitorName ?? session?.monitorName}</p>
                    <p className="text-xs text-muted-foreground">Data: {sessionSummary.session?.sessionDate ? new Date(sessionSummary.session.sessionDate).toLocaleDateString("pt-BR") : ""}</p>
                    <p className="text-xs font-semibold text-green-700">Total de fatores: {sessionSummary.totalEntries}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-foreground mb-2">Distribuicao por Tipo de Risco</h3>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-center">
                        <p className="text-2xl font-black text-red-700">{sessionSummary.byRisk.ameaca ?? 0}</p>
                        <p className="text-xs font-semibold text-red-600 mt-0.5">Ameacas</p>
                      </div>
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-center">
                        <p className="text-2xl font-black text-amber-700">{sessionSummary.byRisk.vulnerabilidade ?? 0}</p>
                        <p className="text-xs font-semibold text-amber-600 mt-0.5">Vulnerabilidades</p>
                      </div>
                      <div className="p-3 rounded-xl bg-green-50 border border-green-200 text-center">
                        <p className="text-2xl font-black text-green-700">{sessionSummary.byRisk.resiliencia ?? 0}</p>
                        <p className="text-xs font-semibold text-green-600 mt-0.5">Resiliencias</p>
                      </div>
                    </div>
                  </div>
                  {sessionSummary.byEixo && sessionSummary.byEixo.length > 0 && (
                    <div>
                      <h3 className="text-sm font-bold text-foreground mb-2">Distribuicao por Eixo Tematico</h3>
                      <div className="space-y-1.5">
                        {sessionSummary.byEixo.map((o: any) => (
                          <div key={o.number} className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-black flex-shrink-0" style={{ backgroundColor: EIXO_COLORS[o.number] ?? "#666" }}>
                              {o.number}
                            </div>
                            <p className="text-xs text-foreground flex-1 truncate">{o.title}</p>
                            <span className="text-xs font-bold text-muted-foreground">{o.count} fator{o.count !== 1 ? "es" : ""}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {sessionSummary.entries && sessionSummary.entries.length > 0 && (
                    <div>
                      <h3 className="text-sm font-bold text-foreground mb-2">Fatores Registrados</h3>
                      <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                        {sessionSummary.entries.map(e => (
                          <div key={e.entry.id} className="p-2.5 rounded-lg border bg-muted/30 space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded flex items-center justify-center text-white text-xs font-black flex-shrink-0" style={{ backgroundColor: EIXO_COLORS[(e as any).eixoData?.number ?? 1] ?? "#666" }}>{(e as any).eixoData?.number ?? "?"}</span>
                              <p className="text-xs font-semibold text-foreground flex-1 truncate">{e.entry.factorName}</p>
                              <span className={`text-xs px-1.5 py-0.5 rounded font-semibold ${e.entry.riskClassification === "ameaca" ? "bg-red-100 text-red-700" : e.entry.riskClassification === "vulnerabilidade" ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"}`}>
                                {e.entry.riskClassification === "ameaca" ? "Ameaca" : e.entry.riskClassification === "vulnerabilidade" ? "Vulnerab." : "Resiliencia"}
                              </span>
                            </div>
                            {editingNoteId === e.entry.id ? (
                              <div className="pl-7 space-y-1">
                                <Textarea
                                  value={editingNoteText}
                                  onChange={ev => setEditingNoteText(ev.target.value)}
                                  placeholder="Observacao sobre este fator..."
                                  className="text-xs min-h-[56px] resize-none"
                                  rows={2}
                                />
                                <div className="flex gap-1">
                                  <Button
                                    size="sm"
                                    className="h-6 text-xs px-2"
                                    onClick={() => updateEntryNotesMutation.mutate({ id: e.entry.id, entryNotes: editingNoteText || null })}
                                    disabled={updateEntryNotesMutation.isPending}
                                  >
                                    {updateEntryNotesMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : "Salvar"}
                                  </Button>
                                  <Button size="sm" variant="outline" className="h-6 text-xs px-2" onClick={() => { setEditingNoteId(null); setEditingNoteText(""); }}>Cancelar</Button>
                                </div>
                              </div>
                            ) : (
                              <div className="pl-7 flex items-start gap-1">
                                {e.entry.entryNotes ? (
                                  <p className="text-xs text-muted-foreground italic flex-1">{e.entry.entryNotes}</p>
                                ) : (
                                  <p className="text-xs text-muted-foreground/50 italic flex-1">Sem observacoes</p>
                                )}
                                <button
                                  className="text-xs text-primary underline flex-shrink-0 hover:no-underline"
                                  onClick={() => { setEditingNoteId(e.entry.id); setEditingNoteText(e.entry.entryNotes ?? ""); }}
                                >
                                  Editar
                                </button>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    <Button
                      className="flex-1 gap-1"
                      onClick={() => { window.open(`/projetos/${projectId}/cartografia/${sessId}/imprimir`, "_blank"); setShowSummary(false); }}
                    >
                      <Map className="w-4 h-4" />
                      Imprimir / PDF
                    </Button>
                    <Button variant="outline" onClick={() => setShowSummary(false)} className="flex-1">
                      Fechar
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </PlatformLayout>
  );
}
