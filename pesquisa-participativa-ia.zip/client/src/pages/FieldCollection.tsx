import PlatformLayout from "@/components/PlatformLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useParams } from "wouter";
import { useState, useEffect, useRef, useCallback } from "react";
import { MapPin, Mic, Send, WifiOff, CheckCircle2, Clock, Square, AlertCircle, XCircle } from "lucide-react";

interface OfflineEntry {
  id: string;
  narrativeText: string;
  locationName?: string;
  lat?: number;
  lng?: number;
  timestamp: number;
  synced: boolean;
}

// Detecta o melhor formato de audio suportado pelo navegador
function getSupportedAudioMimeType(): string {
  if (typeof MediaRecorder === "undefined") return "";
  const types = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/ogg", "audio/mp4"];
  for (const type of types) {
    try {
      if (MediaRecorder.isTypeSupported(type)) return type;
    } catch (_) {}
  }
  return "";
}

// Componente de feedback in-tree (sem portal) para evitar conflito de DOM no Android
function StatusMessage({ type, text, onClose }: { type: "success" | "error" | "info"; text: string; onClose?: () => void }) {
  const colors = {
    success: "bg-green-50 border-green-300 text-green-800",
    error: "bg-red-50 border-red-300 text-red-800",
    info: "bg-blue-50 border-blue-200 text-blue-800",
  };
  const icons = {
    success: <CheckCircle2 className="w-4 h-4 flex-shrink-0" />,
    error: <XCircle className="w-4 h-4 flex-shrink-0" />,
    info: <AlertCircle className="w-4 h-4 flex-shrink-0" />,
  };
  return (
    <div className={`flex items-center gap-2 p-3 border-2 rounded-lg ${colors[type]}`}>
      {icons[type]}
      <p className="text-sm font-medium flex-1">{text}</p>
      {onClose && (
        <button onClick={onClose} className="ml-2 text-current opacity-60 hover:opacity-100 text-lg leading-none">&times;</button>
      )}
    </div>
  );
}

export default function FieldCollection() {
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");

  const [narrativeText, setNarrativeText] = useState("");
  const [locationName, setLocationName] = useState("");
  const [selectedCycleId, setSelectedCycleId] = useState<number | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [offlineQueue, setOfflineQueue] = useState<OfflineEntry[]>([]);

  // Mensagens de feedback in-tree (sem portal/toast)
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);
  const [recordingError, setRecordingError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const isMountedRef = useRef(true);
  const audioUrlRef = useRef<string | null>(null);

  const utils = trpc.useUtils();
  const { data: cycles } = trpc.cycles.listByProject.useQuery({ projectId });
  const { data: entries, isLoading } = trpc.fieldEntries.listByProject.useQuery({ projectId });
  const [isUploading, setIsUploading] = useState(false);
  const createEntry = trpc.fieldEntries.create.useMutation({
    onSuccess: () => {
      if (!isMountedRef.current) return;
      utils.fieldEntries.listByProject.invalidate({ projectId });
      setNarrativeText("");
      setLocation(null);
      setLocationName("");
      setAudioBlob(null);
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }
      setAudioUrl(null);
      setStatusMsg({ type: "success", text: "Coleta registrada com sucesso!" });
    },
    onError: () => {
      if (!isMountedRef.current) return;
      setStatusMsg({ type: "error", text: "Erro ao salvar. Verifique sua conexao." });
    },
  });

  // Cleanup no unmount
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        try { mediaRecorderRef.current.stop(); } catch (_) {}
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => { try { t.stop(); } catch (_) {} });
        streamRef.current = null;
      }
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const stored = localStorage.getItem(`offline_queue_${projectId}`);
    if (stored) {
      try { setOfflineQueue(JSON.parse(stored)); } catch (_) {}
    }
    const handleOnline = () => { if (isMountedRef.current) setIsOffline(false); };
    const handleOffline = () => { if (isMountedRef.current) setIsOffline(true); };
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [projectId]);

  useEffect(() => {
    if (cycles && cycles.length > 0 && !selectedCycleId) {
      setSelectedCycleId(cycles[0].id);
    }
  }, [cycles, selectedCycleId]);

  const saveOffline = useCallback(() => {
    const entry: OfflineEntry = {
      id: Date.now().toString(),
      narrativeText,
      locationName,
      lat: location?.lat,
      lng: location?.lng,
      timestamp: Date.now(),
      synced: false,
    };
    const newQueue = [...offlineQueue, entry];
    setOfflineQueue(newQueue);
    localStorage.setItem(`offline_queue_${projectId}`, JSON.stringify(newQueue));
    setNarrativeText("");
    setLocation(null);
    setLocationName("");
    setStatusMsg({ type: "success", text: "Coleta salva localmente. Sera sincronizada ao reconectar." });
  }, [narrativeText, locationName, location, offlineQueue, projectId]);

  const getLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setStatusMsg({ type: "error", text: "Geolocalizacao nao disponivel neste dispositivo." });
      return;
    }
    setStatusMsg({ type: "info", text: "Obtendo localizacao..." });
    navigator.geolocation.getCurrentPosition(
      pos => {
        if (!isMountedRef.current) return;
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setStatusMsg({ type: "success", text: `Localizacao capturada: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}` });
      },
      () => {
        if (!isMountedRef.current) return;
        setStatusMsg({ type: "error", text: "Nao foi possivel obter localizacao. Verifique as permissoes." });
      }
    );
  }, []);

  const startRecording = useCallback(async () => {
    setRecordingError(null);
    // Verificar suporte antes de pedir permissao
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setRecordingError("Gravacao de audio nao suportada neste navegador.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!isMountedRef.current) {
        stream.getTracks().forEach(t => t.stop());
        return;
      }
      streamRef.current = stream;
      const mimeType = getSupportedAudioMimeType();
      let recorder: MediaRecorder;
      try {
        recorder = mimeType
          ? new MediaRecorder(stream, { mimeType })
          : new MediaRecorder(stream);
      } catch (_) {
        // Fallback sem mimeType se o tipo nao for suportado
        recorder = new MediaRecorder(stream);
      }
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(t => { try { t.stop(); } catch (_) {} });
          streamRef.current = null;
        }
        if (!isMountedRef.current) return;
        if (chunksRef.current.length === 0) return;
        const finalType = recorder.mimeType || mimeType || "audio/webm";
        const blob = new Blob(chunksRef.current, { type: finalType });
        const url = URL.createObjectURL(blob);
        if (audioUrlRef.current) {
          URL.revokeObjectURL(audioUrlRef.current);
        }
        audioUrlRef.current = url;
        setAudioBlob(blob);
        setAudioUrl(url);
      };

      recorder.onerror = () => {
        if (!isMountedRef.current) return;
        setRecordingError("Erro durante a gravacao de audio.");
        setIsRecording(false);
      };

      recorder.start(250);
      mediaRecorderRef.current = recorder;
      if (isMountedRef.current) setIsRecording(true);
    } catch (err: unknown) {
      if (!isMountedRef.current) return;
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      if (msg.includes("Permission") || msg.includes("NotAllowed") || msg.includes("denied")) {
        setRecordingError("Permissao de microfone negada. Habilite nas configuracoes do navegador.");
      } else if (msg.includes("NotFound") || msg.includes("Requested device not found")) {
        setRecordingError("Microfone nao encontrado neste dispositivo.");
      } else {
        setRecordingError("Nao foi possivel acessar o microfone.");
      }
    }
  }, []);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      try { mediaRecorderRef.current.stop(); } catch (_) {}
    }
    if (isMountedRef.current) setIsRecording(false);
  }, []);

  const handleSubmit = useCallback(async () => {
    if (!narrativeText && !audioBlob) {
      setStatusMsg({ type: "error", text: "Informe uma narrativa ou grave um audio." });
      return;
    }
    if (!selectedCycleId) {
      setStatusMsg({ type: "error", text: "Selecione um ciclo de pesquisa." });
      return;
    }
    if (isOffline) { saveOffline(); return; }

    setStatusMsg({ type: "info", text: "Salvando coleta..." });

    let audioStorageUrl: string | undefined;
    if (audioBlob) {
      try {
        setIsUploading(true);
        const finalType = audioBlob.type || "audio/webm";
        const fileExt = finalType.includes("ogg") ? "ogg" : finalType.includes("mp4") ? "mp4" : "webm";
        const formData = new FormData();
        formData.append("file", audioBlob, `audio_${Date.now()}.${fileExt}`);
        const resp = await fetch("/api/upload", { method: "POST", body: formData, credentials: "include" });
        if (!resp.ok) {
          const err = await resp.json().catch(() => ({ error: `HTTP ${resp.status}` }));
          throw new Error(err.error ?? `Upload falhou: ${resp.status}`);
        }
        const result = await resp.json() as { url: string };
        audioStorageUrl = result.url;
      } catch (err: unknown) {
        if (isMountedRef.current) {
          const msg = err instanceof Error ? err.message : "Erro ao enviar o audio.";
          setStatusMsg({ type: "error", text: msg });
        }
        setIsUploading(false);
        return;
      } finally {
        setIsUploading(false);
      }
    }

    const entryType = audioStorageUrl ? "audio" : "narrativa";
    createEntry.mutate({
      projectId,
      cycleId: selectedCycleId,
      entryType,
      narrativeText: narrativeText || undefined,
      audioUrl: audioStorageUrl,
      latitude: location?.lat,
      longitude: location?.lng,
      locationName: locationName || undefined,
    });
  }, [narrativeText, audioBlob, selectedCycleId, isOffline, saveOffline, createEntry, projectId, location, locationName]);

  return (
    <PlatformLayout projectId={projectId}>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Coletar Dados em Campo</h1>
          <p className="text-muted-foreground mt-1">Registre narrativas, audios e a localizacao do territorio.</p>
        </div>

        {isOffline && (
          <div className="flex items-center gap-3 p-4 bg-amber-50 border-2 border-amber-300 rounded-xl">
            <WifiOff className="w-5 h-5 text-amber-600 flex-shrink-0" />
            <div>
              <p className="font-semibold text-amber-800">Modo offline ativo</p>
              <p className="text-sm text-amber-700">Suas coletas serao salvas localmente e sincronizadas ao reconectar.</p>
            </div>
          </div>
        )}

        {offlineQueue.filter(e => !e.synced).length > 0 && (
          <div className="flex items-center gap-3 p-4 bg-blue-50 border-2 border-blue-200 rounded-xl">
            <Clock className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <p className="text-sm text-blue-800 font-medium">
              {offlineQueue.filter(e => !e.synced).length} coleta(s) aguardando sincronizacao.
            </p>
          </div>
        )}

        {/* Mensagem de status in-tree (sem portal) */}
        {statusMsg && (
          <StatusMessage
            type={statusMsg.type}
            text={statusMsg.text}
            onClose={() => setStatusMsg(null)}
          />
        )}

        <Card className="border-2 border-border">
          <CardHeader><CardTitle className="text-xl">Nova coleta</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            {cycles && cycles.length > 0 && (
              <div>
                <Label className="text-base font-semibold" htmlFor="cycle-select">Ciclo de pesquisa *</Label>
                <select
                  id="cycle-select"
                  value={selectedCycleId?.toString() ?? ""}
                  onChange={e => setSelectedCycleId(parseInt(e.target.value))}
                  className="mt-1 w-full rounded-lg border-2 border-border bg-background px-3 py-3 text-base text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="" disabled>Selecione o ciclo</option>
                  {cycles.map(c => (
                    <option key={c.id} value={c.id.toString()}>{c.title}</option>
                  ))}
                </select>
              </div>
            )}
            {(!cycles || cycles.length === 0) && (
              <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <p className="text-sm text-amber-800">Crie um ciclo de pesquisa antes de coletar dados.</p>
              </div>
            )}

            <div>
              <Label className="text-base font-semibold">Narrativa / Relato</Label>
              <Textarea
                value={narrativeText}
                onChange={e => setNarrativeText(e.target.value)}
                placeholder="Escreva o relato, observacao ou narrativa coletada..."
                className="mt-1 text-base"
                rows={5}
              />
            </div>

            <div>
              <Label className="text-base font-semibold">Nome do local</Label>
              <Input
                value={locationName}
                onChange={e => setLocationName(e.target.value)}
                placeholder="Ex: Rua das Flores, Comunidade Esperanca"
                className="mt-1 text-base"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={getLocation}
                className="gap-2 py-5 text-base border-2"
              >
                <MapPin className="w-5 h-5 text-green-600" />
                {location ? `Lat: ${location.lat.toFixed(4)}` : "Capturar localizacao"}
              </Button>

              <Button
                type="button"
                variant="outline"
                onClick={isRecording ? stopRecording : startRecording}
                className={`gap-2 py-5 text-base border-2 ${isRecording ? "border-red-400 bg-red-50 text-red-700" : ""}`}
              >
                {isRecording
                  ? <><Square className="w-5 h-5" />Parar gravacao</>
                  : <><Mic className="w-5 h-5 text-blue-600" />Gravar audio</>
                }
              </Button>
            </div>

            {isRecording && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                <p className="text-sm font-medium text-red-700">Gravando audio... Clique em "Parar gravacao" quando terminar.</p>
              </div>
            )}

            {recordingError && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <XCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                <p className="text-sm text-red-700">{recordingError}</p>
                <button onClick={() => setRecordingError(null)} className="ml-auto text-red-400 hover:text-red-600 text-lg leading-none">&times;</button>
              </div>
            )}

            {audioUrl && !isRecording && (
              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
                <p className="text-sm font-medium text-blue-800 mb-2">Audio gravado:</p>
                <audio controls src={audioUrl} className="w-full" />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="mt-2 text-red-600 border-red-200 hover:bg-red-50"
                  onClick={() => {
                    if (audioUrlRef.current) {
                      URL.revokeObjectURL(audioUrlRef.current);
                      audioUrlRef.current = null;
                    }
                    setAudioBlob(null);
                    setAudioUrl(null);
                  }}
                >
                  Remover audio
                </Button>
              </div>
            )}

            <Button
              onClick={handleSubmit}
              disabled={createEntry.isPending || isUploading || (!cycles || cycles.length === 0) || isRecording}
              className="w-full py-6 text-lg font-semibold gap-2"
            >
              <Send className="w-5 h-5" />
              {isOffline ? "Salvar offline" : createEntry.isPending || isUploading ? "Salvando..." : "Registrar coleta"}
            </Button>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Coletas registradas</h2>
          {isLoading
            ? <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}</div>
            : !entries?.length
              ? (
                <Card className="border-2 border-dashed border-border">
                  <CardContent className="p-8 text-center">
                    <MapPin className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                    <p className="font-semibold text-foreground">Nenhuma coleta ainda</p>
                    <p className="text-sm text-muted-foreground">Registre sua primeira coleta de campo acima.</p>
                  </CardContent>
                </Card>
              )
              : (
                <div className="space-y-3">
                  {entries.map(entry => (
                    <div key={entry.id} className="p-4 bg-white border-2 border-border rounded-xl">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-foreground text-base">{entry.locationName ?? `Coleta #${entry.id}`}</p>
                          {entry.narrativeText && (
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{entry.narrativeText}</p>
                          )}
                          <div className="flex items-center gap-3 mt-2 flex-wrap">
                            {entry.latitude && (
                              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                                <MapPin className="w-3 h-3" />{Number(entry.latitude).toFixed(4)}, {Number(entry.longitude).toFixed(4)}
                              </span>
                            )}
                            {entry.audioUrl && (
                              <span className="flex items-center gap-1 text-xs text-blue-600">
                                <Mic className="w-3 h-3" />Audio
                              </span>
                            )}
                            <span className="text-xs text-muted-foreground">
                              {new Date(entry.createdAt).toLocaleDateString("pt-BR")}
                            </span>
                          </div>
                        </div>
                        <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                      </div>
                    </div>
                  ))}
                </div>
              )
          }
        </div>
      </div>
    </PlatformLayout>
  );
}
