import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { useEffect } from "react";
import { useLocation } from "wouter";
import {
  Users, MapPin, Mic, Brain, BarChart3, FileText,
  Target, Bell, ArrowRight, Leaf, HeartHandshake, Shield
} from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // Todos os hooks devem ser chamados antes de qualquer return condicional
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, navigate]);

  if (loading || isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
          <p className="text-muted-foreground font-medium">
            {loading ? "Carregando..." : "Redirecionando..."}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground leading-tight">PesquisaViva</h1>
              <p className="text-xs text-muted-foreground">Pesquisa Participativa em Saude</p>
            </div>
          </div>
          <a href={getLoginUrl()}>
            <Button size="lg" className="gap-2 text-base font-semibold">
              Entrar na plataforma
              <ArrowRight className="w-4 h-4" />
            </Button>
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 bg-gradient-to-br from-secondary via-background to-background">
        <div className="container">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-2 text-sm font-medium mb-6">
              <HeartHandshake className="w-4 h-4" />
              Plataforma de Pesquisa Comunitaria
            </div>
            <h2 className="text-5xl font-bold text-foreground leading-tight mb-6">
              Pesquisa participativa com o poder da inteligencia artificial
            </h2>
            <p className="text-xl text-muted-foreground leading-relaxed mb-8">
              Ferramenta integrada para coleta de dados em campo, analise de narrativas comunitarias,
              monitoramento participativo e elaboracao de planos de incidencia politica em saude.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href={getLoginUrl()}>
                <Button size="lg" className="gap-2 text-base font-semibold px-8 py-6">
                  Comecar agora
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Perfis */}
      <section className="py-16 bg-white">
        <div className="container">
          <h3 className="text-2xl font-bold text-center mb-12">Tres perfis, um objetivo comum</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-2 border-blue-200 bg-blue-50/50">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-2xl bg-blue-100 flex items-center justify-center mb-4">
                  <Users className="w-7 h-7 text-blue-600" />
                </div>
                <h4 className="text-lg font-bold text-blue-900 mb-2">Pesquisador Popular</h4>
                <p className="text-blue-700 text-sm leading-relaxed">
                  Coleta narrativas, registra fotos e audios em campo, visualiza analises e participa da validacao dos resultados.
                </p>
              </CardContent>
            </Card>
            <Card className="border-2 border-amber-200 bg-amber-50/50">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-2xl bg-amber-100 flex items-center justify-center mb-4">
                  <HeartHandshake className="w-7 h-7 text-amber-600" />
                </div>
                <h4 className="text-lg font-bold text-amber-900 mb-2">Facilitador</h4>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Coordena ciclos de pesquisa, aciona analises de IA, gerencia indicadores e elabora planos de incidencia politica.
                </p>
              </CardContent>
            </Card>
            <Card className="border-2 border-green-200 bg-green-50/50">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-2xl bg-green-100 flex items-center justify-center mb-4">
                  <Shield className="w-7 h-7 text-green-600" />
                </div>
                <h4 className="text-lg font-bold text-green-900 mb-2">Gestor</h4>
                <p className="text-green-700 text-sm leading-relaxed">
                  Supervisiona projetos, gerencia equipes, importa dados epidemiologicos e acompanha indicadores estrategicos.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Funcionalidades */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <h3 className="text-2xl font-bold text-center mb-12">Funcionalidades integradas</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: MapPin, label: "Coleta em campo com georreferenciamento", color: "text-green-600 bg-green-100" },
              { icon: Mic, label: "Transcricao automatica de audio (Whisper)", color: "text-blue-600 bg-blue-100" },
              { icon: Brain, label: "Analise de narrativas com IA", color: "text-purple-600 bg-purple-100" },
              { icon: BarChart3, label: "Dashboard de monitoramento participativo", color: "text-amber-600 bg-amber-100" },
              { icon: FileText, label: "Importacao de dados epidemiologicos", color: "text-red-600 bg-red-100" },
              { icon: Target, label: "Planos de incidencia politica", color: "text-indigo-600 bg-indigo-100" },
              { icon: Bell, label: "Notificacoes automaticas", color: "text-orange-600 bg-orange-100" },
              { icon: Users, label: "Funcionamento offline com sincronizacao", color: "text-teal-600 bg-teal-100" },
            ].map((item, i) => (
              <Card key={i} className="border border-border hover:shadow-md transition-shadow">
                <CardContent className="p-4 flex flex-col items-center text-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.color}`}>
                    <item.icon className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-medium text-foreground leading-tight">{item.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h3 className="text-3xl font-bold mb-4">Pronto para comecar?</h3>
          <p className="text-primary-foreground/80 text-lg mb-8 max-w-xl mx-auto">
            Acesse a plataforma e inicie seu projeto de pesquisa participativa em saude comunitaria.
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" variant="secondary" className="gap-2 text-base font-semibold px-8 py-6">
              Entrar na plataforma
              <ArrowRight className="w-5 h-5" />
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-foreground text-background/70 text-center text-sm">
        <p>PesquisaViva - Plataforma de Pesquisa Participativa em Saude Comunitaria</p>
        <p className="mt-1 text-background/50">Desenvolvida para pesquisadores populares, facilitadores e gestores em saude publica</p>
      </footer>
    </div>
  );
}
