import PlatformLayout from "@/components/PlatformLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useLocation, useParams } from "wouter";
import { useState } from "react";
import { MapPin, Mic, Brain, BarChart3, FileText, Target, Plus, ArrowRight, Clock, PlayCircle, AlertCircle } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

const cycleStatusColors: Record<string, string> = {
  planejamento: "bg-gray-100 text-gray-700 border-gray-300",
  coleta: "bg-blue-100 text-blue-700 border-blue-300",
  analise: "bg-purple-100 text-purple-700 border-purple-300",
  validacao: "bg-amber-100 text-amber-700 border-amber-300",
  concluido: "bg-green-100 text-green-700 border-green-300",
};
const cycleStatusLabels: Record<string, string> = { planejamento: "Planejamento", coleta: "Coleta", analise: "Analise", validacao: "Validacao", concluido: "Concluido" };

export default function ProjectDetail() {
  const notify = useNotification();
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [openCycle, setOpenCycle] = useState(false);
  const [cycleTitle, setCycleTitle] = useState("");
  const utils = trpc.useUtils();
  const { data: project } = trpc.projects.getById.useQuery({ id: projectId });
  const { data: cycles, isLoading: cyclesLoading } = trpc.cycles.listByProject.useQuery({ projectId });
  const { data: stats } = trpc.projects.getStats.useQuery({ projectId });
  const createCycle = trpc.cycles.create.useMutation({
    onSuccess: () => { utils.cycles.listByProject.invalidate({ projectId }); setOpenCycle(false); setCycleTitle(""); notify.success("Ciclo criado!"); },
    onError: () => notify.error("Erro ao criar ciclo."),
  });
  const userRole = user?.role ?? "pesquisador_popular";
  const canManage = ["facilitador","gestor","admin"].includes(userRole);
  const modules = [
    { label: "Coletar Dados", desc: "Registrar narrativas, fotos e audios", icon: MapPin, href: `/projetos/${projectId}/coleta`, color: "green" },
    { label: "Transcricoes", desc: "Transcrever e revisar audios", icon: Mic, href: `/projetos/${projectId}/transcricoes`, color: "blue" },
    ...(canManage ? [
      { label: "Analise com IA", desc: "Codigos tematicos e sentimentos", icon: Brain, href: `/projetos/${projectId}/analise`, color: "purple" },
    ] : []),
    { label: "Monitoramento", desc: "Indicadores de resultado", icon: BarChart3, href: `/projetos/${projectId}/monitoramento`, color: "amber" },
    ...(canManage ? [
      { label: "Dados Epidemiologicos", desc: "Importar dados de saude", icon: FileText, href: `/projetos/${projectId}/dados-epidemiologicos`, color: "red" },
      { label: "Incidencia Politica", desc: "Planos de acao comunitaria", icon: Target, href: `/projetos/${projectId}/incidencia`, color: "indigo" },
    ] : []),
  ];

  if (!project) return <PlatformLayout><div className="p-6 flex items-center justify-center min-h-64"><div className="w-8 h-8 rounded-full border-4 border-primary border-t-transparent animate-spin" /></div></PlatformLayout>;

  return (
    <PlatformLayout projectId={projectId} projectName={project.title}>
      <div className="p-6 max-w-5xl mx-auto space-y-8">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">{project.title}</h1>
            {project.territory && <div className="flex items-center gap-1 text-muted-foreground mt-1"><MapPin className="w-4 h-4" /><span>{project.territory}</span></div>}
            {project.description && <p className="text-muted-foreground mt-2 max-w-2xl">{project.description}</p>}
          </div>
          <Badge className={`text-sm px-3 py-1 border ${project.status === "ativo" ? "bg-green-100 text-green-800 border-green-300" : "bg-gray-100 text-gray-600 border-gray-300"}`}>
            {project.status === "ativo" ? "Ativo" : project.status === "pausado" ? "Pausado" : "Concluido"}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {[
            { label: "Coletas realizadas", value: stats?.totalEntries ?? 0, icon: MapPin, color: "green" },
            { label: "Ciclos de pesquisa", value: stats?.totalCycles ?? 0, icon: PlayCircle, color: "blue" },
            { label: "Indicadores", value: stats?.totalIndicators ?? 0, icon: BarChart3, color: "amber" },
          ].map((s, i) => (
            <Card key={i} className={`border-2 border-${s.color}-200 bg-${s.color}-50/50`}>
              <CardContent className="p-4 text-center">
                <div className={`w-10 h-10 rounded-xl bg-${s.color}-100 flex items-center justify-center mx-auto mb-2`}><s.icon className={`w-5 h-5 text-${s.color}-600`} /></div>
                <p className={`text-2xl font-bold text-${s.color}-900`}>{s.value}</p>
                <p className={`text-xs text-${s.color}-700 font-medium`}>{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Modulos do projeto</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {modules.map((mod, i) => (
              <button key={i} onClick={() => navigate(mod.href)} className="flex items-center gap-4 p-5 bg-white border-2 border-border rounded-2xl hover:border-primary hover:shadow-md transition-all text-left group">
                <div className={`w-12 h-12 rounded-xl bg-${mod.color}-100 flex items-center justify-center flex-shrink-0`}><mod.icon className={`w-6 h-6 text-${mod.color}-600`} /></div>
                <div className="flex-1 min-w-0"><p className="font-semibold text-foreground text-base">{mod.label}</p><p className="text-sm text-muted-foreground">{mod.desc}</p></div>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-foreground">Ciclos de pesquisa</h2>
            {canManage && (
              <Dialog open={openCycle} onOpenChange={setOpenCycle}>
                <DialogTrigger asChild><Button variant="outline" className="gap-2"><Plus className="w-4 h-4" />Novo ciclo</Button></DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader><DialogTitle>Criar ciclo de pesquisa</DialogTitle></DialogHeader>
                  <div className="space-y-4 pt-2">
                    <div><Label className="text-base font-semibold">Nome do ciclo *</Label><Input value={cycleTitle} onChange={e => setCycleTitle(e.target.value)} placeholder="Ex: Ciclo 1 - Diagnostico Inicial" className="mt-1 text-base" /></div>
                    <Button className="w-full text-base py-5" disabled={!cycleTitle || createCycle.isPending} onClick={() => createCycle.mutate({ projectId, title: cycleTitle })}>{createCycle.isPending ? "Criando..." : "Criar ciclo"}</Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
          {cyclesLoading ? <div className="space-y-3">{[1,2].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}</div>
          : !cycles?.length ? (
            <Card className="border-2 border-dashed border-border"><CardContent className="p-8 text-center"><AlertCircle className="w-10 h-10 text-muted-foreground mx-auto mb-3" /><p className="font-semibold text-foreground mb-1">Nenhum ciclo criado</p><p className="text-sm text-muted-foreground">Os ciclos organizam as etapas da pesquisa participativa.</p></CardContent></Card>
          ) : (
            <div className="space-y-3">
              {cycles.map(cycle => (
                <div key={cycle.id} className="flex items-center gap-4 p-4 bg-white border-2 border-border rounded-xl hover:border-primary transition-colors">
                  <div className="flex-1 min-w-0"><p className="font-semibold text-foreground">{cycle.title}</p>{cycle.description && <p className="text-sm text-muted-foreground truncate">{cycle.description}</p>}<div className="flex items-center gap-1 text-xs text-muted-foreground mt-1"><Clock className="w-3 h-3" /><span>{new Date(cycle.createdAt).toLocaleDateString("pt-BR")}</span></div></div>
                  <span className={`text-xs px-2 py-1 rounded-full border font-medium flex-shrink-0 ${cycleStatusColors[cycle.status]}`}>{cycleStatusLabels[cycle.status]}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}
