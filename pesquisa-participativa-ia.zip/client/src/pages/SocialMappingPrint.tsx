import { useEffect } from "react";
import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";

const RISK_LABELS: Record<string, string> = {
  ameaca: "Ameaça",
  vulnerabilidade: "Vulnerabilidade",
  resiliencia: "Resiliência",
};

const EIXO_COLORS: Record<number, string> = {
  1: "#E5243B", 2: "#DDA63A", 3: "#4C9F38", 4: "#C5192D", 5: "#FF3A21",
  6: "#26BDE2", 7: "#FCC30B", 8: "#A21942", 9: "#FD6925", 10: "#DD1367",
  11: "#FD9D24", 12: "#BF8B2E", 13: "#3F7E44", 14: "#0A97D9", 15: "#56C02B",
  16: "#00689D", 17: "#19486A",
};

export default function SocialMappingPrint() {
  const { id, sessionId } = useParams<{ id: string; sessionId: string }>();
  const sessId = parseInt(sessionId ?? "0");

  const { data: summary, isLoading } = trpc.socialMapping.getSessionSummary.useQuery(
    { id: sessId },
    { enabled: !!sessId }
  );

  useEffect(() => {
    if (!isLoading && summary && summary.totalEntries >= 0) {
      // Aguarda renderização completa antes de imprimir
      const timer = setTimeout(() => {
        window.print();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isLoading, summary]);

  if (isLoading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", fontFamily: "Arial, sans-serif" }}>
        <p>Preparando relatório para impressão...</p>
      </div>
    );
  }

  if (!summary || summary.totalEntries === 0 && !summary.session) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", fontFamily: "Arial, sans-serif" }}>
        <p>Sessão não encontrada.</p>
      </div>
    );
  }

  const { session, totalEntries, byRisk, byEixo, entries } = summary;

  return (
    <>
      <style>{`
        @media print {
          @page {
            size: A4;
            margin: 20mm 15mm;
          }
          body {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .no-print {
            display: none !important;
          }
          .page-break {
            page-break-before: always;
          }
          .avoid-break {
            page-break-inside: avoid;
          }
        }
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        body {
          font-family: Arial, Helvetica, sans-serif;
          font-size: 11pt;
          color: #1a1a1a;
          background: white;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          padding: 24px;
        }
        .header {
          border-bottom: 3px solid #1a5c2a;
          padding-bottom: 16px;
          margin-bottom: 20px;
        }
        .header h1 {
          font-size: 18pt;
          color: #1a5c2a;
          margin-bottom: 4px;
        }
        .header .subtitle {
          font-size: 10pt;
          color: #555;
        }
        .meta-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
          margin-bottom: 20px;
          padding: 12px;
          background: #f5f5f5;
          border-radius: 6px;
        }
        .meta-item label {
          font-size: 8pt;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .meta-item p {
          font-size: 11pt;
          font-weight: bold;
          color: #1a1a1a;
        }
        .section-title {
          font-size: 13pt;
          font-weight: bold;
          color: #1a5c2a;
          border-bottom: 1px solid #ccc;
          padding-bottom: 6px;
          margin: 20px 0 12px 0;
        }
        .risk-grid {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          gap: 10px;
          margin-bottom: 16px;
        }
        .risk-card {
          padding: 12px;
          border-radius: 6px;
          text-align: center;
        }
        .risk-card.ameaca { background: #fee2e2; border: 1px solid #fca5a5; }
        .risk-card.vulnerabilidade { background: #fef3c7; border: 1px solid #fcd34d; }
        .risk-card.resiliencia { background: #dcfce7; border: 1px solid #86efac; }
        .risk-card .count { font-size: 24pt; font-weight: 900; }
        .risk-card.ameaca .count { color: #b91c1c; }
        .risk-card.vulnerabilidade .count { color: #92400e; }
        .risk-card.resiliencia .count { color: #166534; }
        .risk-card .label { font-size: 9pt; font-weight: bold; color: #444; }
        .ods-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 16px;
          font-size: 10pt;
        }
        .ods-table th {
          background: #1a5c2a;
          color: white;
          padding: 6px 10px;
          text-align: left;
          font-size: 9pt;
        }
        .ods-table td {
          padding: 5px 10px;
          border-bottom: 1px solid #e5e5e5;
        }
        .ods-table tr:nth-child(even) td { background: #f9f9f9; }
        .ods-badge {
          display: inline-block;
          width: 22px;
          height: 22px;
          border-radius: 4px;
          color: white;
          font-weight: 900;
          font-size: 9pt;
          text-align: center;
          line-height: 22px;
          margin-right: 6px;
        }
        .factor-card {
          border: 1px solid #ddd;
          border-radius: 6px;
          padding: 10px 12px;
          margin-bottom: 8px;
          page-break-inside: avoid;
        }
        .factor-header {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 6px;
        }
        .factor-name {
          font-size: 11pt;
          font-weight: bold;
          flex: 1;
        }
        .risk-badge {
          font-size: 8pt;
          padding: 2px 8px;
          border-radius: 12px;
          font-weight: bold;
        }
        .risk-badge.ameaca { background: #fee2e2; color: #b91c1c; }
        .risk-badge.vulnerabilidade { background: #fef3c7; color: #92400e; }
        .risk-badge.resiliencia { background: #dcfce7; color: #166534; }
        .factor-meta {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 4px;
          font-size: 9pt;
          color: #555;
        }
        .factor-notes {
          margin-top: 6px;
          font-size: 9pt;
          color: #444;
          font-style: italic;
          border-top: 1px solid #eee;
          padding-top: 6px;
        }
        .print-btn {
          position: fixed;
          top: 16px;
          right: 16px;
          padding: 10px 20px;
          background: #1a5c2a;
          color: white;
          border: none;
          border-radius: 6px;
          font-size: 12pt;
          cursor: pointer;
          font-weight: bold;
        }
        .print-btn:hover { background: #145022; }
        .footer {
          margin-top: 24px;
          border-top: 1px solid #ccc;
          padding-top: 10px;
          font-size: 8pt;
          color: #888;
          text-align: center;
        }
      `}</style>

      <button className="no-print print-btn" onClick={() => window.print()}>
        Imprimir / Salvar PDF
      </button>

      <div className="container">
        <div className="header">
          <h1>Relatório de Cartografia Social</h1>
          <p className="subtitle">Plataforma PesquisaViva - Pesquisa Participativa em Saúde</p>
        </div>

        <div className="meta-grid">
          <div className="meta-item">
            <label>Território</label>
            <p>{session?.territory ?? "Não informado"}</p>
          </div>
          <div className="meta-item">
            <label>Monitor</label>
            <p>{session?.monitorName ?? "Não informado"}</p>
          </div>
          <div className="meta-item">
            <label>Data da Sessão</label>
            <p>{session?.sessionDate ? new Date(session.sessionDate).toLocaleDateString("pt-BR") : "Não informada"}</p>
          </div>
          <div className="meta-item">
            <label>Status</label>
            <p>{session?.status === "concluida" ? "Concluída" : "Em andamento"}</p>
          </div>
          {session?.closedAt && (
            <div className="meta-item">
              <label>Encerrada em</label>
              <p>{new Date(session.closedAt).toLocaleDateString("pt-BR")}</p>
            </div>
          )}
          <div className="meta-item">
            <label>Total de Fatores</label>
            <p>{totalEntries}</p>
          </div>
        </div>

        <h2 className="section-title">Distribuição por Tipo de Risco</h2>
        <div className="risk-grid">
          <div className="risk-card ameaca">
            <div className="count">{byRisk.ameaca ?? 0}</div>
            <div className="label">Ameaças</div>
          </div>
          <div className="risk-card vulnerabilidade">
            <div className="count">{byRisk.vulnerabilidade ?? 0}</div>
            <div className="label">Vulnerabilidades</div>
          </div>
          <div className="risk-card resiliencia">
            <div className="count">{byRisk.resiliencia ?? 0}</div>
            <div className="label">Resiliências</div>
          </div>
        </div>

        {byEixo.length > 0 && (
          <>
            <h2 className="section-title">Distribuição por ODS</h2>
            <table className="ods-table">
              <thead>
                <tr>
                  <th>ODS</th>
                  <th>Título</th>
                  <th style={{ textAlign: "center" }}>Registros</th>
                </tr>
              </thead>
              <tbody>
                {byEixo.map(o => (
                  <tr key={o.number}>
                    <td>
                      <span className="ods-badge" style={{ backgroundColor: EIXO_COLORS[o.number] ?? "#666" }}>
                        {o.number}
                      </span>
                    </td>
                    <td>{o.title}</td>
                    <td style={{ textAlign: "center", fontWeight: "bold" }}>{o.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        {session?.analysisText && (
          <>
            <h2 className="section-title">Síntese Analítica (IA)</h2>
            <div style={{ background: "#f0f4ff", borderLeft: "4px solid #4f46e5", padding: "12px 16px", marginBottom: "16px", borderRadius: "4px", fontSize: "10pt", lineHeight: "1.7", whiteSpace: "pre-wrap" }}>
              {session.analysisText}
            </div>
          </>
        )}
        {session?.analysisReview && (
          <>
            <h2 className="section-title">Revisão Editorial da Síntese</h2>
            <div style={{ background: "#f0fdf4", borderLeft: "4px solid #16a34a", padding: "12px 16px", marginBottom: "16px", borderRadius: "4px", fontSize: "10pt", lineHeight: "1.7", whiteSpace: "pre-wrap" }}>
              {session.analysisReview}
            </div>
          </>
        )}
        {entries.length > 0 && (
          <>
            <h2 className="section-title">Fatores Registrados</h2>
            {entries.map(({ entry, eixoData }) => (
              <div key={entry.id} className="factor-card avoid-break">
                <div className="factor-header">
                  {eixoData && (
                    <span className="ods-badge" style={{ backgroundColor: EIXO_COLORS[eixoData.number] ?? "#666" }}>
                      {eixoData.number}
                    </span>
                  )}
                  <span className="factor-name">{entry.factorName}</span>
                  <span className={`risk-badge ${entry.riskClassification}`}>
                    {RISK_LABELS[entry.riskClassification] ?? entry.riskClassification}
                  </span>
                </div>
                <div className="factor-meta">
                  {eixoData && <span>Eixo {eixoData.number} - {eixoData.title}</span>}
                  <span>Importância: {entry.importanceLevel}/10</span>
                  {entry.characterization && <span style={{ gridColumn: "1 / -1" }}>Caracterização: {entry.characterization}</span>}
                  {entry.latitude && entry.longitude && (
                    <span>Localização: {entry.latitude.toFixed(5)}, {entry.longitude.toFixed(5)}</span>
                  )}
                </div>
                {entry.entryNotes && (
                  <div className="factor-notes">
                    Observações: {entry.entryNotes}
                  </div>
                )}
              </div>
            ))}
          </>
        )}

        <div className="footer">
          Relatório gerado em {new Date().toLocaleString("pt-BR")} pela Plataforma PesquisaViva - Fiocruz Brasília / CoLaboratório CTIS
        </div>
      </div>
    </>
  );
}
