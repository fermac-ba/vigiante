import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { PortalProvider } from "./contexts/PortalContext";
import { NotificationProvider } from "./contexts/NotificationContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";
import ProjectDetail from "./pages/ProjectDetail";
import FieldCollection from "./pages/FieldCollection";
import Transcriptions from "./pages/Transcriptions";
import AiAnalysis from "./pages/AiAnalysis";
import Monitoring from "./pages/Monitoring";
import EpidemiologicalData from "./pages/EpidemiologicalData";
import ActionPlans from "./pages/ActionPlans";
import Notifications from "./pages/Notifications";
import UserManagement from "./pages/UserManagement";
import Report from "./pages/Report";
import SocialMapping from "./pages/SocialMapping";
import SocialMappingSession from "./pages/SocialMappingSession";
import SocialMappingMap from "./pages/SocialMappingMap";
import SocialMappingPrint from "./pages/SocialMappingPrint";
import TerritoryTimeline from "./pages/TerritoryTimeline";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/projetos" component={Projects} />
      <Route path="/projetos/:id" component={ProjectDetail} />
      <Route path="/projetos/:id/coleta" component={FieldCollection} />
      <Route path="/projetos/:id/transcricoes" component={Transcriptions} />
      <Route path="/projetos/:id/analise" component={AiAnalysis} />
      <Route path="/projetos/:id/monitoramento" component={Monitoring} />
      <Route path="/projetos/:id/dados-epidemiologicos" component={EpidemiologicalData} />
      <Route path="/projetos/:id/incidencia" component={ActionPlans} />
      <Route path="/projetos/:id/relatorio" component={Report} />
      <Route path="/projetos/:id/cartografia" component={SocialMapping} />
      <Route path="/projetos/:id/cartografia/:sessionId" component={SocialMappingSession} />
      <Route path="/projetos/:id/cartografia-mapa" component={SocialMappingMap} />
      <Route path="/projetos/:id/cartografia/:sessionId/imprimir" component={SocialMappingPrint} />
      <Route path="/projetos/:id/cartografia-territorio" component={TerritoryTimeline} />
      <Route path="/notificacoes" component={Notifications} />
      <Route path="/usuarios" component={UserManagement} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <PortalProvider>
          <NotificationProvider>
            <Router />
          </NotificationProvider>
        </PortalProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
