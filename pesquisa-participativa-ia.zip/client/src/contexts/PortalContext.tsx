import React, { createContext, useContext, useRef } from "react";

/**
 * PortalContext - Container DOM fixo para todos os portais Radix UI.
 *
 * PROBLEMA RAIZ: A versão anterior usava useState + useEffect para definir o
 * container, criando uma janela onde container === null na primeira renderizacao.
 * Nessa janela, container ?? undefined === undefined, e o Radix usa document.body
 * como fallback. No Android WebView com React 19 Concurrent Mode, isso causa
 * NotFoundError (removeChild) porque o React tenta remover nos DOM que o Radix
 * moveu para fora da arvore gerenciada durante o ciclo de commit.
 *
 * SOLUCAO: O container e criado de forma SINCRONA e imperativa antes de qualquer
 * renderizacao React, via singleton. O useRef com inicializacao lazy garante que
 * o container existe desde o primeiro render, sem janela de null.
 */

// Singleton criado sincronamente - nunca null apos a primeira chamada
let _portalContainer: HTMLElement | null = null;

function getPortalContainer(): HTMLElement {
  if (!_portalContainer) {
    const el = document.createElement("div");
    el.id = "radix-portal-root";
    el.setAttribute("data-radix-portal", "true");
    el.style.cssText =
      "position:fixed;top:0;left:0;width:0;height:0;z-index:9999;pointer-events:none;overflow:visible;";
    document.body.appendChild(el);
    _portalContainer = el;
  }
  return _portalContainer;
}

const PortalContext = createContext<HTMLElement | null>(null);

export function PortalProvider({ children }: { children: React.ReactNode }) {
  // Inicializacao lazy sincrona: o container existe desde o primeiro render
  const containerRef = useRef<HTMLElement | null>(null);
  if (containerRef.current === null) {
    containerRef.current = getPortalContainer();
  }

  return (
    <PortalContext.Provider value={containerRef.current}>
      {children}
    </PortalContext.Provider>
  );
}

export function usePortalContainer(): HTMLElement | null {
  return useContext(PortalContext);
}
