import React, { createContext, useContext, useState, useCallback, useRef } from "react";
import { CheckCircle, XCircle, Info, AlertTriangle, X } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * NotificationContext - Sistema de notificações in-tree sem portal e sem flushSync.
 *
 * Substitui o Sonner (que usa ReactDOM.flushSync dentro de setTimeout,
 * causando NotFoundError no Android WebView com React 19 Concurrent Mode).
 * As notificações são renderizadas dentro da árvore React gerenciada,
 * sem createPortal, sem document.body, sem flushSync.
 */

type NotificationType = "success" | "error" | "info" | "warning";

interface Notification {
  id: string;
  type: NotificationType;
  message: string;
  duration?: number;
}

interface NotificationContextValue {
  success: (message: string, duration?: number) => void;
  error: (message: string, duration?: number) => void;
  info: (message: string, duration?: number) => void;
  warning: (message: string, duration?: number) => void;
}

const NotificationContext = createContext<NotificationContextValue>({
  success: () => {},
  error: () => {},
  info: () => {},
  warning: () => {},
});

export function useNotification() {
  return useContext(NotificationContext);
}

const icons: Record<NotificationType, React.ReactNode> = {
  success: <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />,
  error: <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />,
  info: <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />,
  warning: <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />,
};

const styles: Record<NotificationType, string> = {
  success: "bg-green-50 border-green-200 text-green-900",
  error: "bg-red-50 border-red-200 text-red-900",
  info: "bg-blue-50 border-blue-200 text-blue-900",
  warning: "bg-amber-50 border-amber-200 text-amber-900",
};

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const counterRef = useRef(0);

  const dismiss = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const add = useCallback((type: NotificationType, message: string, duration = 4000) => {
    const id = `notif-${++counterRef.current}`;
    setNotifications(prev => [...prev, { id, type, message, duration }]);
    if (duration > 0) {
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== id));
      }, duration);
    }
  }, []);

  const value: NotificationContextValue = {
    success: (msg, dur) => add("success", msg, dur),
    error: (msg, dur) => add("error", msg, dur),
    info: (msg, dur) => add("info", msg, dur),
    warning: (msg, dur) => add("warning", msg, dur),
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
      {/* Notificações renderizadas dentro da árvore React - sem portal, sem flushSync */}
      {notifications.length > 0 && (
        <div
          className="fixed bottom-4 right-4 z-[9998] flex flex-col gap-2 max-w-sm w-full pointer-events-none"
          aria-live="polite"
          aria-atomic="false"
        >
          {notifications.map(n => (
            <div
              key={n.id}
              className={cn(
                "flex items-start gap-3 p-4 rounded-lg border shadow-lg pointer-events-auto",
                "animate-in slide-in-from-bottom-2 fade-in-0 duration-200",
                styles[n.type]
              )}
              role="alert"
            >
              {icons[n.type]}
              <p className="text-sm font-medium flex-1 leading-snug">{n.message}</p>
              <button
                onClick={() => dismiss(n.id)}
                className="flex-shrink-0 opacity-60 hover:opacity-100 transition-opacity"
                aria-label="Fechar notificação"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </NotificationContext.Provider>
  );
}
