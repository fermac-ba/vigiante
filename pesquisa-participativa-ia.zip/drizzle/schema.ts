import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  float,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

// ─── Users ───────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["pesquisador_popular", "facilitador", "gestor", "admin"]).default("pesquisador_popular").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Projects ────────────────────────────────────────────────────────────────
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  territory: varchar("territory", { length: 255 }),
  status: mysqlEnum("status", ["ativo", "pausado", "concluido"]).default("ativo").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

// ─── Project Members ─────────────────────────────────────────────────────────
export const projectMembers = mysqlTable("project_members", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["pesquisador_popular", "facilitador", "gestor"]).notNull(),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

// ─── Research Cycles ─────────────────────────────────────────────────────────
export const researchCycles = mysqlTable("research_cycles", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  status: mysqlEnum("status", ["planejamento", "coleta", "analise", "validacao", "concluido"]).default("planejamento").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ResearchCycle = typeof researchCycles.$inferSelect;
export type InsertResearchCycle = typeof researchCycles.$inferInsert;

// ─── Field Entries ────────────────────────────────────────────────────────────
export const fieldEntries = mysqlTable("field_entries", {
  id: int("id").autoincrement().primaryKey(),
  cycleId: int("cycleId").notNull(),
  projectId: int("projectId").notNull(),
  collectedBy: int("collectedBy").notNull(),
  entryType: mysqlEnum("entryType", ["narrativa", "audio", "foto", "misto"]).default("narrativa").notNull(),
  narrativeText: text("narrativeText"),
  audioUrl: varchar("audioUrl", { length: 1024 }),
  audioKey: varchar("audioKey", { length: 512 }),
  photoUrl: varchar("photoUrl", { length: 1024 }),
  photoKey: varchar("photoKey", { length: 512 }),
  latitude: float("latitude"),
  longitude: float("longitude"),
  geoPolygon: json("geoPolygon"),
  locationName: varchar("locationName", { length: 255 }),
  syncStatus: mysqlEnum("syncStatus", ["pendente", "sincronizado"]).default("sincronizado").notNull(),
  offlineId: varchar("offlineId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FieldEntry = typeof fieldEntries.$inferSelect;
export type InsertFieldEntry = typeof fieldEntries.$inferInsert;

// ─── Transcriptions ───────────────────────────────────────────────────────────
export const transcriptions = mysqlTable("transcriptions", {
  id: int("id").autoincrement().primaryKey(),
  fieldEntryId: int("fieldEntryId").notNull(),
  rawText: text("rawText"),
  reviewedText: text("reviewedText"),
  segments: json("segments"),
  language: varchar("language", { length: 10 }).default("pt"),
  status: mysqlEnum("status", ["pendente", "processando", "concluido", "revisado", "erro"]).default("pendente").notNull(),
  reviewedBy: int("reviewedBy"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Transcription = typeof transcriptions.$inferSelect;
export type InsertTranscription = typeof transcriptions.$inferInsert;

// ─── AI Analyses ──────────────────────────────────────────────────────────────
export const aiAnalyses = mysqlTable("ai_analyses", {
  id: int("id").autoincrement().primaryKey(),
  fieldEntryId: int("fieldEntryId"),
  cycleId: int("cycleId"),
  projectId: int("projectId").notNull(),
  analysisType: mysqlEnum("analysisType", ["codigos_tematicos", "sentimentos", "entidades", "topicos", "completa"]).notNull(),
  suggestedCodes: json("suggestedCodes"),
  sentimentResult: json("sentimentResult"),
  entities: json("entities"),
  topics: json("topics"),
  wordFrequency: json("wordFrequency"),
  humanValidated: boolean("humanValidated").default(false),
  validatedBy: int("validatedBy"),
  validatedAt: timestamp("validatedAt"),
  humanNotes: text("humanNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AiAnalysis = typeof aiAnalyses.$inferSelect;
export type InsertAiAnalysis = typeof aiAnalyses.$inferInsert;

// ─── Monitoring Indicators ────────────────────────────────────────────────────
export const monitoringIndicators = mysqlTable("monitoring_indicators", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  cycleId: int("cycleId"),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  indicatorType: mysqlEnum("indicatorType", ["resultado", "processo", "aprendizagem"]).notNull(),
  targetValue: float("targetValue"),
  currentValue: float("currentValue"),
  unit: varchar("unit", { length: 64 }),
  threshold: float("threshold"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MonitoringIndicator = typeof monitoringIndicators.$inferSelect;
export type InsertMonitoringIndicator = typeof monitoringIndicators.$inferInsert;

// ─── Epidemiological Data ─────────────────────────────────────────────────────
export const epidemiologicalData = mysqlTable("epidemiological_data", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  datasetName: varchar("datasetName", { length: 255 }).notNull(),
  datasetType: mysqlEnum("datasetType", ["epidemiologico", "social", "ambiental", "outro"]).default("epidemiologico").notNull(),
  source: varchar("source", { length: 255 }),
  referenceYear: int("referenceYear"),
  territory: varchar("territory", { length: 255 }),
  records: json("records"),
  columns: json("columns"),
  totalRecords: int("totalRecords").default(0),
  importedBy: int("importedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EpidemiologicalData = typeof epidemiologicalData.$inferSelect;
export type InsertEpidemiologicalData = typeof epidemiologicalData.$inferInsert;

// ─── Action Plans ─────────────────────────────────────────────────────────────
export const actionPlans = mysqlTable("action_plans", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  objective: text("objective"),
  context: text("context"),
  status: mysqlEnum("status", ["rascunho", "ativo", "concluido"]).default("rascunho").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ActionPlan = typeof actionPlans.$inferSelect;
export type InsertActionPlan = typeof actionPlans.$inferInsert;

// ─── Action Actors ────────────────────────────────────────────────────────────
export const actionActors = mysqlTable("action_actors", {
  id: int("id").autoincrement().primaryKey(),
  actionPlanId: int("actionPlanId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  role: varchar("role", { length: 255 }),
  actorType: mysqlEnum("actorType", ["gestor", "profissional", "comunidade", "academia", "midia", "outro"]).default("outro").notNull(),
  strategy: text("strategy"),
  contact: varchar("contact", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActionActor = typeof actionActors.$inferSelect;
export type InsertActionActor = typeof actionActors.$inferInsert;

// ─── Action Steps ─────────────────────────────────────────────────────────────
export const actionSteps = mysqlTable("action_steps", {
  id: int("id").autoincrement().primaryKey(),
  actionPlanId: int("actionPlanId").notNull(),
  description: text("description").notNull(),
  responsible: varchar("responsible", { length: 255 }),
  deadline: timestamp("deadline"),
  status: mysqlEnum("status", ["pendente", "em_andamento", "concluido"]).default("pendente").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ActionStep = typeof actionSteps.$inferSelect;
export type InsertActionStep = typeof actionSteps.$inferInsert;

// ─── Notifications ────────────────────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId"),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  notificationType: mysqlEnum("notificationType", ["nova_coleta", "ciclo_concluido", "limiar_atingido", "sistema"]).default("sistema").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Eixos Temáticos Geradores (Metodologia PICAPS / Fiocruz Brasília) ──────────
export const eixosTematicos = mysqlTable("eixos_tematicos", {
  id: int("id").autoincrement().primaryKey(),
  number: int("number").notNull().unique(),
  slug: varchar("slug", { length: 50 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  contradicaoCentral: text("contradicaoCentral"),
  focoPedagogico: varchar("focoPedagogico", { length: 512 }),
  color: varchar("color", { length: 20 }).notNull(),
  iconEmoji: varchar("iconEmoji", { length: 10 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EixoTematico = typeof eixosTematicos.$inferSelect;
export type InsertEixoTematico = typeof eixosTematicos.$inferInsert;

// ─── Eixos Fatores (Fatores/Temas Geradores por Eixo) ────────────────────────
export const eixosFatores = mysqlTable("eixos_fatores", {
  id: int("id").autoincrement().primaryKey(),
  eixoId: int("eixoId").notNull(),
  name: varchar("name", { length: 512 }).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EixoFator = typeof eixosFatores.$inferSelect;
export type InsertEixoFator = typeof eixosFatores.$inferInsert;

// ─── Social Mapping Sessions (Sessões de Cartografia Social) ─────────────────
export const socialMappingSessions = mysqlTable("social_mapping_sessions", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  cycleId: int("cycleId"),
  territory: varchar("territory", { length: 255 }).notNull(),
  monitorName: varchar("monitorName", { length: 255 }).notNull(),
  sessionDate: timestamp("sessionDate").defaultNow().notNull(),
  participants: int("participants").default(0),
  notes: text("notes"),
  status: mysqlEnum("status", ["em_andamento", "concluida"]).default("em_andamento").notNull(),
  closedAt: timestamp("closedAt"),
  analysisText: text("analysisText"),
  analysisReview: text("analysisReview"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SocialMappingSession = typeof socialMappingSessions.$inferSelect;
export type InsertSocialMappingSession = typeof socialMappingSessions.$inferInsert;

// ─── Social Mapping Entries (Registros de Fator Georreferenciado) ─────────────
export const socialMappingEntries = mysqlTable("social_mapping_entries", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  projectId: int("projectId").notNull(),
  eixoId: int("eixoId").notNull(),
  factorId: int("factorId").notNull(),
  factorName: varchar("factorName", { length: 255 }).notNull(),
  characterization: text("characterization"),
  riskClassification: mysqlEnum("riskClassification", ["ameaca", "resiliencia", "vulnerabilidade"]).notNull(),
  importanceLevel: int("importanceLevel").notNull(),
  latitude: float("latitude"),
  longitude: float("longitude"),
  locationName: varchar("locationName", { length: 255 }),
  geoPolygon: json("geoPolygon"),
  photoUrl: varchar("photoUrl", { length: 1024 }),
  photoKey: varchar("photoKey", { length: 512 }),
  audioUrl: varchar("audioUrl", { length: 1024 }),
  audioKey: varchar("audioKey", { length: 512 }),
  entryNotes: text("entryNotes"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SocialMappingEntry = typeof socialMappingEntries.$inferSelect;
export type InsertSocialMappingEntry = typeof socialMappingEntries.$inferInsert;

// ─── Social Mapping Entry Comments (Comentários Colaborativos por Fator) ──────
export const socialMappingEntryComments = mysqlTable("social_mapping_entry_comments", {
  id: int("id").autoincrement().primaryKey(),
  entryId: int("entryId").notNull(),
  sessionId: int("sessionId").notNull(),
  projectId: int("projectId").notNull(),
  authorId: int("authorId").notNull(),
  authorName: varchar("authorName", { length: 255 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type SocialMappingEntryComment = typeof socialMappingEntryComments.$inferSelect;
export type InsertSocialMappingEntryComment = typeof socialMappingEntryComments.$inferInsert;
