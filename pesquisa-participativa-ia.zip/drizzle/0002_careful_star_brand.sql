CREATE TABLE `ods` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`shortTitle` varchar(100) NOT NULL,
	`description` text,
	`color` varchar(20) NOT NULL,
	`iconEmoji` varchar(10),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ods_id` PRIMARY KEY(`id`),
	CONSTRAINT `ods_number_unique` UNIQUE(`number`)
);
--> statement-breakpoint
CREATE TABLE `ods_factors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`odsId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ods_factors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `social_mapping_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`projectId` int NOT NULL,
	`odsId` int NOT NULL,
	`factorId` int NOT NULL,
	`factorName` varchar(255) NOT NULL,
	`characterization` text,
	`riskClassification` enum('ameaca','resiliencia','vulnerabilidade') NOT NULL,
	`importanceLevel` int NOT NULL,
	`latitude` float,
	`longitude` float,
	`locationName` varchar(255),
	`geoPolygon` json,
	`photoUrl` varchar(1024),
	`photoKey` varchar(512),
	`audioUrl` varchar(1024),
	`audioKey` varchar(512),
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `social_mapping_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `social_mapping_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`cycleId` int,
	`territory` varchar(255) NOT NULL,
	`monitorName` varchar(255) NOT NULL,
	`sessionDate` timestamp NOT NULL DEFAULT (now()),
	`participants` int DEFAULT 0,
	`notes` text,
	`status` enum('em_andamento','concluida') NOT NULL DEFAULT 'em_andamento',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `social_mapping_sessions_id` PRIMARY KEY(`id`)
);
