ALTER TABLE `social_mapping_entries` ADD `entryNotes` text;--> statement-breakpoint
ALTER TABLE `social_mapping_sessions` ADD `closedAt` timestamp;