CREATE TABLE `social_mapping_entry_comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entryId` int NOT NULL,
	`sessionId` int NOT NULL,
	`projectId` int NOT NULL,
	`authorId` int NOT NULL,
	`authorName` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `social_mapping_entry_comments_id` PRIMARY KEY(`id`)
);
