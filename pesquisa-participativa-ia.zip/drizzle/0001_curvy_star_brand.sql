CREATE TABLE `action_actors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actionPlanId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`role` varchar(255),
	`actorType` enum('gestor','profissional','comunidade','academia','midia','outro') NOT NULL DEFAULT 'outro',
	`strategy` text,
	`contact` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `action_actors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `action_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`objective` text,
	`context` text,
	`status` enum('rascunho','ativo','concluido') NOT NULL DEFAULT 'rascunho',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `action_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `action_steps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actionPlanId` int NOT NULL,
	`description` text NOT NULL,
	`responsible` varchar(255),
	`deadline` timestamp,
	`status` enum('pendente','em_andamento','concluido') NOT NULL DEFAULT 'pendente',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `action_steps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ai_analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fieldEntryId` int,
	`cycleId` int,
	`projectId` int NOT NULL,
	`analysisType` enum('codigos_tematicos','sentimentos','entidades','topicos','completa') NOT NULL,
	`suggestedCodes` json,
	`sentimentResult` json,
	`entities` json,
	`topics` json,
	`wordFrequency` json,
	`humanValidated` boolean DEFAULT false,
	`validatedBy` int,
	`validatedAt` timestamp,
	`humanNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ai_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `epidemiological_data` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`datasetName` varchar(255) NOT NULL,
	`datasetType` enum('epidemiologico','social','ambiental','outro') NOT NULL DEFAULT 'epidemiologico',
	`source` varchar(255),
	`referenceYear` int,
	`territory` varchar(255),
	`records` json,
	`columns` json,
	`totalRecords` int DEFAULT 0,
	`importedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `epidemiological_data_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `field_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cycleId` int NOT NULL,
	`projectId` int NOT NULL,
	`collectedBy` int NOT NULL,
	`entryType` enum('narrativa','audio','foto','misto') NOT NULL DEFAULT 'narrativa',
	`narrativeText` text,
	`audioUrl` varchar(1024),
	`audioKey` varchar(512),
	`photoUrl` varchar(1024),
	`photoKey` varchar(512),
	`latitude` float,
	`longitude` float,
	`geoPolygon` json,
	`locationName` varchar(255),
	`syncStatus` enum('pendente','sincronizado') NOT NULL DEFAULT 'sincronizado',
	`offlineId` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `field_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `monitoring_indicators` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`cycleId` int,
	`name` varchar(255) NOT NULL,
	`description` text,
	`indicatorType` enum('resultado','processo','aprendizagem') NOT NULL,
	`targetValue` float,
	`currentValue` float,
	`unit` varchar(64),
	`threshold` float,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monitoring_indicators_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`projectId` int,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`notificationType` enum('nova_coleta','ciclo_concluido','limiar_atingido','sistema') NOT NULL DEFAULT 'sistema',
	`read` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `project_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('pesquisador_popular','facilitador','gestor') NOT NULL,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `project_members_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`territory` varchar(255),
	`status` enum('ativo','pausado','concluido') NOT NULL DEFAULT 'ativo',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `research_cycles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`startDate` timestamp,
	`endDate` timestamp,
	`status` enum('planejamento','coleta','analise','validacao','concluido') NOT NULL DEFAULT 'planejamento',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `research_cycles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transcriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fieldEntryId` int NOT NULL,
	`rawText` text,
	`reviewedText` text,
	`segments` json,
	`language` varchar(10) DEFAULT 'pt',
	`status` enum('pendente','processando','concluido','revisado','erro') NOT NULL DEFAULT 'pendente',
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transcriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('pesquisador_popular','facilitador','gestor','admin') NOT NULL DEFAULT 'pesquisador_popular';